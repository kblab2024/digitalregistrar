# `tnmhelper_data/` — the data layer

This directory holds **the source of truth** for the staging engine:
per-organ model definitions, rule tables, criteria descriptions, and
derivation rules. It is read at runtime by a `DataProvider` (filesystem
or zip) and shipped as a single zip bundle for installs on other
systems.

Although these files include `.py` model definitions, they are
conceptually **data** — declarative manifests of the per-organ schema
that the `tnmhelper` Python package consumes. They live here, not
inside the `tnmhelper/` package, so they can be bundled and shipped
independently of the code.

## Layout

```
tnmhelper_data/
├── models/                         per-organ Python source (data, despite the extension)
│   ├── ajcc8/
│   │   ├── __init__.py             (empty namespace marker)
│   │   ├── breast.py               MODEL = StagingModel(name="breast", edition=Edition.AJCC_8, ...)
│   │   ├── colon.py
│   │   └── ... (17 organs total)
│   └── ajcc9/
│       ├── __init__.py
│       ├── cervix.py
│       └── lung.py
├── ajcc8/                          per-(organ, edition) data triples
│   ├── breast/
│   │   ├── rules.csv               TNM rule table (header = MODEL.columns + ["Stage"])
│   │   ├── criteria.json           TNM category descriptions (reference doc, not loaded by engine)
│   │   └── derivation.json         observation → TNM rules
│   └── ... (17 organs)
└── ajcc9/
    ├── cervix/{rules.csv, criteria.json, derivation.json}
    └── lung/{rules.csv, criteria.json, derivation.json}
```

For each `(organ, edition)` you maintain **four files in two
directories**:

- `tnmhelper_data/models/<edition_slug>/<organ>.py`
- `tnmhelper_data/<edition_slug>/<organ>/{rules.csv, criteria.json, derivation.json}`

The parent directory name (`ajcc8`, `ajcc9`, ...) MUST equal
`MODEL.edition_slug` (the lowercased no-space form of
`MODEL.edition.value`). The discovery walker and the data provider
hard-fail otherwise.

## The `.py` model contract

A model module MUST:

1. Define a module-level constant `MODEL: StagingModel`.
2. Have a filename stem equal to `MODEL.name` (e.g.
   `ajcc8/breast.py` → `MODEL.name == "breast"`).
3. Live in a directory whose name equals `MODEL.edition_slug` (e.g.
   `MODEL.edition == Edition.AJCC_8` → parent dir `ajcc8`).
4. Not start its filename with an underscore (skipped by discovery).
5. Import shared types from `tnmhelper.backend._shared` (absolute
   import path; not `from .._shared` — the data tree is not inside the
   Python package).

A model module SHOULD:

- Define one `StrEnum` per TNM axis (T, N, M) and any organ-specific
  extras (Grade, ER/PR/HER2 via the shared `Biomarker` enum).
- Use `ALL_CAPS` enum member names (PEP 8). Preserve the
  case-sensitive AJCC literal in the `.value` string:
  `TIS = "Tis"`, `T1MI = "T1mi"`, `M1A = "M1a"`.
- Define a `NamedTuple` whose fields, in order, match the columns of
  the source CSV.
- Define its OWN enum classes (do NOT import from a sibling edition's
  module). AJCC editions can add, remove, or rename TNM categories.

A model module MUST NOT:

- Import from sibling model modules (forbidden; share via
  `tnmhelper.backend._shared` instead).
- Run module-level side effects (I/O, network, mutation of registries).
- Re-register a `(name, edition)` pair already present in
  `MODEL_REGISTRY` (raises at import).

## `StagingModel` fields

Defined in [`tnmhelper/backend/_shared.py`](../tnmhelper/backend/_shared.py).
Frozen dataclass.

| Field | Type | Meaning | Constraint |
|-------|------|---------|------------|
| `name` | `str` | Organ identifier | Equals module filename stem; lowercase by convention |
| `edition` | `Edition` | AJCC edition | Equals the parent directory in slug form |
| `category` | `str` | Body-system grouping for the GUI sidebar | Non-empty; SHOULD be in `KNOWN_CATEGORIES` |
| `state_cls` | `type[NamedTuple]` | The typed lookup key | Fields are all `StrEnum` subclasses |
| `columns` | `dict[str, type[StrEnum]]` | Per-column enum class | `tuple(columns) == state_cls._fields` |
| `examples` | `tuple[tuple[str, NamedTuple, str], ...]` | Smoke tests | Each entry is `(label, state, expected_stage)`; `tests/smoke.py` runs them |

`KNOWN_CATEGORIES`: `breast`, `thoracic`, `head_neck`, `gi`,
`hepatobiliary`, `gyn`, `urologic`.

## CSV contract — `rules.csv`

`tnmhelper_data/<edition_slug>/<organ>/rules.csv` MUST:

- Have a header row equal to `list(MODEL.columns) + ["Stage"]` in
  that exact order.
- Have one row per rule.
- Use enum literals (the `.value` of each `StrEnum` member) or the
  literal string `"ANY"` as a wildcard.
- Have a non-empty `Stage` cell on every row. `Stage` is a free
  string (e.g. `"IA"`, `"IIIB"`, `"IV"`).

Specificity (count of non-`ANY` cells) is the conflict-resolution
key. Two rules with the same specificity that map the same state to
different stages cause the lint to abort with `ConflictError`.

## `criteria.json` and `derivation.json`

`criteria.json` carries the TNM category descriptions (reference
material consumed by tooltips and the LM prompt-building code). Its
`edition` field MUST match `MODEL.edition.value`.

`derivation.json` declares observables and per-axis rules that map
observations to T/N/M literals. Schema details are in the [derive
module](../tnmhelper/backend/derive.py) docstring; see existing
files (e.g. `ajcc9/lung/derivation.json`) for the conventions.

## Worked example

`tnmhelper_data/models/ajcc9/lung.py` (trimmed):

```python
from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class LungT(StrEnum):
    TX = "TX"; T0 = "T0"; TIS = "Tis"
    T1MI = "T1mi"; T1 = "T1"; T1A = "T1a"; T1B = "T1b"; T1C = "T1c"
    T2 = "T2"; T2A = "T2a"; T2B = "T2b"
    T3 = "T3"; T4 = "T4"


class LungN(StrEnum):
    NX = "NX"; N0 = "N0"; N1 = "N1"
    N2 = "N2"; N2A = "N2a"; N2B = "N2b"; N3 = "N3"


class LungM(StrEnum):
    M0 = "M0"; M1 = "M1"; M1A = "M1a"; M1B = "M1b"; M1C = "M1c"
    M1C1 = "M1c1"; M1C2 = "M1c2"


class LungState(NamedTuple):
    T: LungT
    N: LungN
    M: LungM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


MODEL = StagingModel(
    name="lung",
    edition=Edition.AJCC_9,
    category="thoracic",
    state_cls=LungState,
    columns={"T": LungT, "N": LungN, "M": LungM,
             "Classification": Classification,
             "DescY": YesNo, "DescR": YesNo, "DescM": YesNo},
    examples=(
        ("T1a N0 M0 -> IA1",
         LungState(LungT.T1A, LungN.N0, LungM.M0,
                   Classification.CLINICAL, YesNo.NO, YesNo.NO, YesNo.NO),
         "IA1"),
    ),
)
```

The matching `tnmhelper_data/ajcc9/lung/rules.csv` header:

```csv
T,N,M,Classification,DescY,DescR,DescM,Stage
```

## Migration from the legacy four-tree layout

Earlier versions of this repo split the data into four parallel
trees: `data/`, `criteria/`, `derivations/`, `models/`. The current
layout co-locates the three per-organ data files in
`tnmhelper_data/<edition_slug>/<organ>/`, and moves the `.py` model
file to `tnmhelper_data/models/<edition_slug>/<organ>.py`. A maintainer
now touches **two directories** per organ (one code dir, one data
dir) instead of four. The count of files per organ is unchanged.

If you have a branch that still uses the legacy layout, see the
[migration plan](../C:/Users/cmuh/.claude/plans/now-its-time-to-agile-milner.md)
or just look at this directory for the current expected paths.

## Things that will fail loudly

- `MODEL.name != filename_stem` → `ValueError` from
  `tnmhelper/models/__init__.py`.
- `MODEL.edition_slug != parent_dirname` → `ValueError`.
- `MODEL.edition` not a known `Edition` value → `ValueError`.
- Duplicate `(name, edition)` across files → `ValueError`.
- `columns.keys()` not equal to `state_cls._fields` in order →
  `ValueError` from `StagingModel.__post_init__`.
- CSV header missing a required column or carrying extras →
  `ValueError` from `tnmhelper/backend/lint.py`.
- CSV cell with a value not in the column's `StrEnum` → `ValueError`
  naming the row.
- Missing `criteria.json`, or its `edition` field disagreeing with
  `MODEL.edition` → `FileNotFoundError` / `ValueError`.
- Equal-specificity rules disagreeing on `Stage` → `ConflictError`.
