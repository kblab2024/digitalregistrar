"""Oropharynx HPV-mediated (p16+) squamous cell carcinoma, AJCC 8.

Source: pdfsource/oropharynx_hpv.pdf. AJCC 8 defines a single stage
group table for HPV-mediated oropharyngeal SCC; the same rules apply
to cTNM, pTNM, and ypTNM. Every CSV rule therefore uses `ANY` for
Classification and descriptor columns.

Distinctive features vs the HPV-unrelated (p16-) tables:
  - T0 IS a valid leaf category here ("no primary identified") because
    diagnosis can be made from a nodal metastasis with HPV/p16+ status
    when the primary is occult. There is no TX in this chapter.
  - T has no Tis and no T4a/T4b subdivision; just T0/T1/T2/T3/T4.
  - N is simplified to NX/N0/N1/N2 (count-based, no ENE distinction
    and no subcategories).
  - Stage groups are I/II/III/IV only (no IVA/IVB/IVC split, and Stage
    IV is reserved for M1).

Stage rows summarized:
  - Stage I:   T0-T2 with N0-N1, M0
  - Stage II:  T0-T2 with N2, M0; or T3-T4 with N0-N1, M0
  - Stage III: T3-T4 with N2, M0
  - Stage IV:  any T, any N, M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class OropharynxHpvT(StrEnum):
    T0 = "T0"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class OropharynxHpvN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"


class OropharynxHpvM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class OropharynxHpvState(NamedTuple):
    T: OropharynxHpvT
    N: OropharynxHpvN
    M: OropharynxHpvM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="oropharynx_hpv",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=OropharynxHpvState,
    columns={
        "T": OropharynxHpvT,
        "N": OropharynxHpvN,
        "M": OropharynxHpvM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "T0 N1 M0 -- occult primary with positive nodes (Stage I, HPV-specific case)",
            OropharynxHpvState(OropharynxHpvT.T0, OropharynxHpvN.N1, OropharynxHpvM.M0,
                               P, NO, NO, NO),
            "I",
        ),
        (
            "T1 N0 M0 (Stage I)",
            OropharynxHpvState(OropharynxHpvT.T1, OropharynxHpvN.N0, OropharynxHpvM.M0,
                               C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N1 M0 (Stage I)",
            OropharynxHpvState(OropharynxHpvT.T2, OropharynxHpvN.N1, OropharynxHpvM.M0,
                               C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N2 M0 -- N2 with T0-T2 (Stage II)",
            OropharynxHpvState(OropharynxHpvT.T2, OropharynxHpvN.N2, OropharynxHpvM.M0,
                               P, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- T3-T4 with N0-N1 (Stage II)",
            OropharynxHpvState(OropharynxHpvT.T3, OropharynxHpvN.N0, OropharynxHpvM.M0,
                               C, NO, NO, NO),
            "II",
        ),
        (
            "T4 N1 M0 -- T3-T4 with N0-N1 (Stage II)",
            OropharynxHpvState(OropharynxHpvT.T4, OropharynxHpvN.N1, OropharynxHpvM.M0,
                               P, NO, NO, NO),
            "II",
        ),
        (
            "T3 N2 M0 (Stage III)",
            OropharynxHpvState(OropharynxHpvT.T3, OropharynxHpvN.N2, OropharynxHpvM.M0,
                               P, NO, NO, NO),
            "III",
        ),
        (
            "T4 N2 M0 (Stage III)",
            OropharynxHpvState(OropharynxHpvT.T4, OropharynxHpvN.N2, OropharynxHpvM.M0,
                               P, NO, NO, NO),
            "III",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IV)",
            OropharynxHpvState(OropharynxHpvT.T1, OropharynxHpvN.N0, OropharynxHpvM.M1,
                               C, NO, NO, NO),
            "IV",
        ),
        (
            "T4 N2 M1 -- M1 dominates (Stage IV)",
            OropharynxHpvState(OropharynxHpvT.T4, OropharynxHpvN.N2, OropharynxHpvM.M1,
                               P, NO, NO, NO),
            "IV",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored for HPV-mediated (still Stage I)",
            OropharynxHpvState(OropharynxHpvT.T2, OropharynxHpvN.N1, OropharynxHpvM.M0,
                               P, YES, YES, YES),
            "I",
        ),
        (
            "T1 NX M0 -- NX aliased to N0 in engine -> I",
            OropharynxHpvState(OropharynxHpvT.T1, OropharynxHpvN.NX, OropharynxHpvM.M0,
                               C, NO, NO, NO),
            "I",
        ),
    ),
)
