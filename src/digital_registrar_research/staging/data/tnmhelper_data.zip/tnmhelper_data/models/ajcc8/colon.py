"""Colon and Rectum AJCC 8 staging.

Source: pdfsource/colon.pdf. State shape parallels lung/stomach:

- Classification (c/p) and three descriptor flags (DescY/R/M) are
  carried for clinical record-keeping. The colon PDF defines a SINGLE
  stage group table that applies identically to cTNM, pTNM, and ypTNM,
  so every rule uses ANY for those fields.

N-family conventions used in the PDF stage table:
  - "N1" in a row means {N1, N1a, N1b} -- the parent and its
    nodal-count subcategories. N1c (tumor deposits without positive
    nodes) is semantically distinct and is always listed explicitly.
  - "N1, N1c" therefore expands to {N1, N1a, N1b, N1c}.
  - "N1-N2" expands to {N1, N1a, N1b, N1c, N2, N2a, N2b}.

T-family conventions in the PDF:
  - "T1-T2" / "T2-T3" / "T3, T4a" enumerate the literal categories named.
    T1, T2, T3 have no subcategories; only T4 splits into T4a/T4b.

Note on M0: per the PDF, M0 "is not assigned by pathologists" -- it is
a clinical-only category. The model does not enforce this; a state with
(Classification=p, M=M0) still resolves to the corresponding stage. The
constraint is left to clinical workflow / data-entry validation.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class ColonT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class ColonN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N1A = "N1a"
    N1B = "N1b"
    N1C = "N1c"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"


class ColonM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"


class ColonState(NamedTuple):
    T: ColonT
    N: ColonN
    M: ColonM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="colon",
    edition=Edition.AJCC_8,
    category="gi",
    state_cls=ColonState,
    columns={
        "T": ColonT,
        "N": ColonN,
        "M": ColonM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            ColonState(ColonT.TIS, ColonN.N0, ColonM.M0, C, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 (Stage I)",
            ColonState(ColonT.T1, ColonN.N0, ColonM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T3 N0 (Stage IIA)",
            ColonState(ColonT.T3, ColonN.N0, ColonM.M0, C, NO, NO, NO),
            "IIA",
        ),
        (
            "T4a N0 (Stage IIB)",
            ColonState(ColonT.T4A, ColonN.N0, ColonM.M0, C, NO, NO, NO),
            "IIB",
        ),
        (
            "T4b N0 (Stage IIC)",
            ColonState(ColonT.T4B, ColonN.N0, ColonM.M0, C, NO, NO, NO),
            "IIC",
        ),
        (
            "T1 N1a -- N1 family with T1 (Stage IIIA)",
            ColonState(ColonT.T1, ColonN.N1A, ColonM.M0, C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T2 N1c -- tumor deposits, T1-T2 path (Stage IIIA)",
            ColonState(ColonT.T2, ColonN.N1C, ColonM.M0, C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T1 N2a (Stage IIIA special case)",
            ColonState(ColonT.T1, ColonN.N2A, ColonM.M0, C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T3 N1b -- T3/T4a with N1 family (Stage IIIB)",
            ColonState(ColonT.T3, ColonN.N1B, ColonM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T3 N2a (Stage IIIB)",
            ColonState(ColonT.T3, ColonN.N2A, ColonM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T4a N2b (Stage IIIC)",
            ColonState(ColonT.T4A, ColonN.N2B, ColonM.M0, C, NO, NO, NO),
            "IIIC",
        ),
        (
            "T4b N2 -- T4b with N1-N2 range (Stage IIIC)",
            ColonState(ColonT.T4B, ColonN.N2, ColonM.M0, C, NO, NO, NO),
            "IIIC",
        ),
        (
            "M1a -- single site (Stage IVA)",
            ColonState(ColonT.T2, ColonN.N0, ColonM.M1A, C, NO, NO, NO),
            "IVA",
        ),
        (
            "M1b -- multi-site (Stage IVB)",
            ColonState(ColonT.T3, ColonN.N1, ColonM.M1B, C, NO, NO, NO),
            "IVB",
        ),
        (
            "M1c -- peritoneal (Stage IVC)",
            ColonState(ColonT.T4B, ColonN.N2B, ColonM.M1C, C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T1 N1a -- descriptors ignored for colon (still IIIA)",
            ColonState(ColonT.T1, ColonN.N1A, ColonM.M0, P, YES, NO, NO),
            "IIIA",
        ),
        (
            "unstageable: T3 with bare N2 (no subcategory specified)",
            ColonState(ColonT.T3, ColonN.N2, ColonM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
