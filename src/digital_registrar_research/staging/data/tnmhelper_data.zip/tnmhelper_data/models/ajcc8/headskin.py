"""Cutaneous squamous cell carcinoma of the head and neck, AJCC 8.

Source: pdfsource/_pages_headskinv8/p1-p4. AJCC 8 defines a single stage
group table for cutaneous H/N SCC that applies to cTNM and pTNM. The N
category leaves overlap conceptually between cN and pN (the PDF gives
slightly different prose for each) but the stage-group table is keyed by
the same N codes; this engine therefore treats them as a single axis.
Every rule in the CSV uses `ANY` for Classification and the three
descriptor columns -- the stage outcome does not depend on them. The
fields are still part of state for clinical record-keeping and to keep
the GUI/data-entry shape consistent across organs.

T leaf categories used by the stage table are TX, Tis, T1, T2, T3, T4a,
T4b. Bare `T4` is the parent grouping for T4a/T4b; per the PDF stage
table "T4 / Any N / M0 -> IV", T4 is also a valid stage-table key.

T criteria (AJCC 8):
  - TX:  primary tumor cannot be assessed
  - Tis: carcinoma in situ
  - T1:  <= 2 cm in greatest dimension
  - T2:  > 2 cm but <= 4 cm in greatest dimension
  - T3:  > 4 cm OR minor bone erosion OR perineural invasion OR deep
         invasion (DOI > 6 mm or beyond subcutaneous fat)
  - T4:  parent for T4a/T4b (gross cortical bone/marrow invasion,
         skull base invasion and/or skull base foramen involvement)
  - T4a: gross cortical bone / marrow invasion
  - T4b: skull base invasion and/or skull base foramen involvement

N criteria (AJCC 8, pN flavor):
  - NX, N0, N1
  - N2: single ipsi <= 3 cm ENE+, OR single ipsi > 3 and <= 6 cm ENE-,
        OR multi ipsi <= 6 cm ENE-, OR bi/contralateral <= 6 cm ENE-
  - N2a, N2b, N2c (sub-leaves of N2)
  - N3: any node > 6 cm ENE-, OR single ipsi > 3 cm ENE+,
        OR multiple/contralateral with ENE+
  - N3a: any node > 6 cm, ENE-
  - N3b: single ipsi > 3 cm ENE+; OR multiple any ENE+;
         OR single contralateral any size ENE+

M criteria: M0 (no distant metastasis), M1 (distant metastasis).

Stage table (the AJCC 8 PSG for cutaneous H/N SCC uses a flat IV, NOT
IVA/IVB/IVC):
  - 0:   Tis N0 M0
  - I:   T1 N0 M0
  - II:  T2 N0 M0
  - III: T3 N0 M0; T1-T3 N1 M0
  - IV:  T1-T3 N2 M0; any T N3 M0; T4 any N M0; any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class HeadSkinT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class HeadSkinN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class HeadSkinM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class HeadSkinState(NamedTuple):
    T: HeadSkinT
    N: HeadSkinN
    M: HeadSkinM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="headskin",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=HeadSkinState,
    columns={
        "T": HeadSkinT,
        "N": HeadSkinN,
        "M": HeadSkinM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            HeadSkinState(HeadSkinT.TIS, HeadSkinN.N0, HeadSkinM.M0,
                          C, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 (Stage I)",
            HeadSkinState(HeadSkinT.T1, HeadSkinN.N0, HeadSkinM.M0,
                          C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            HeadSkinState(HeadSkinT.T2, HeadSkinN.N0, HeadSkinM.M0,
                          C, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 (Stage III)",
            HeadSkinState(HeadSkinT.T3, HeadSkinN.N0, HeadSkinM.M0,
                          P, NO, NO, NO),
            "III",
        ),
        (
            "T1 N1 M0 -- N1 promotes to Stage III",
            HeadSkinState(HeadSkinT.T1, HeadSkinN.N1, HeadSkinM.M0,
                          P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N2b M0 -- N2 family with T1-T3 (Stage IV)",
            HeadSkinState(HeadSkinT.T2, HeadSkinN.N2B, HeadSkinM.M0,
                          P, NO, NO, NO),
            "IV",
        ),
        (
            "T1 N3a M0 -- any T with N3 family is Stage IV",
            HeadSkinState(HeadSkinT.T1, HeadSkinN.N3A, HeadSkinM.M0,
                          P, NO, NO, NO),
            "IV",
        ),
        (
            "T4a N0 M0 -- T4 family at any N is Stage IV",
            HeadSkinState(HeadSkinT.T4A, HeadSkinN.N0, HeadSkinM.M0,
                          P, NO, NO, NO),
            "IV",
        ),
        (
            "T4b N2 M0 -- T4b still Stage IV",
            HeadSkinState(HeadSkinT.T4B, HeadSkinN.N2, HeadSkinM.M0,
                          P, NO, NO, NO),
            "IV",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IV)",
            HeadSkinState(HeadSkinT.T1, HeadSkinN.N0, HeadSkinM.M1,
                          C, NO, NO, NO),
            "IV",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored (still III)",
            HeadSkinState(HeadSkinT.T2, HeadSkinN.N1, HeadSkinM.M0,
                          P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: TX has no stage-table entry",
            HeadSkinState(HeadSkinT.TX, HeadSkinN.N0, HeadSkinM.M0,
                          C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "T1 NX M0 -- NX aliased to N0 in engine -> I",
            HeadSkinState(HeadSkinT.T1, HeadSkinN.NX, HeadSkinM.M0,
                          C, NO, NO, NO),
            "I",
        ),
    ),
)
