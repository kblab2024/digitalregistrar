"""Liver (hepatocellular carcinoma), AJCC 8.

Source: pdfsource/liver.pdf. A single stage group table applies; cTNM
and pTNM use the same rules. Every CSV rule uses `ANY` for
Classification and descriptors.

T leaf categories used by the stage table: T1a, T1b, T2, T3, T4. Bare
T1 is the parent of T1a/T1b and is NOT a stage-table key; a state with
T=T1 returns UNSTAGEABLE. TX and T0 likewise have no stage entry.

Stage rows summarized:
  - IA:  T1a N0 M0
  - IB:  T1b N0 M0
  - II:  T2 N0 M0
  - IIIA: T3 N0 M0
  - IIIB: T4 N0 M0
  - IVA: any T with N1 M0
  - IVB: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class LiverT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class LiverN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class LiverM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class LiverState(NamedTuple):
    T: LiverT
    N: LiverN
    M: LiverM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="liver",
    edition=Edition.AJCC_8,
    category="hepatobiliary",
    state_cls=LiverState,
    columns={
        "T": LiverT,
        "N": LiverN,
        "M": LiverM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("T1a N0 M0 -- solitary <= 2 cm (IA)",
         LiverState(LiverT.T1A, LiverN.N0, LiverM.M0, C, NO, NO, NO), "IA"),
        ("T1b N0 M0 -- solitary > 2 cm no vascular invasion (IB)",
         LiverState(LiverT.T1B, LiverN.N0, LiverM.M0, P, NO, NO, NO), "IB"),
        ("T2 N0 M0 -- solitary > 2 cm with vascular invasion or multiple <= 5 cm (II)",
         LiverState(LiverT.T2, LiverN.N0, LiverM.M0, C, NO, NO, NO), "II"),
        ("T3 N0 M0 -- multiple with at least one > 5 cm (IIIA)",
         LiverState(LiverT.T3, LiverN.N0, LiverM.M0, P, NO, NO, NO), "IIIA"),
        ("T4 N0 M0 -- major vessel invasion or adjacent organs (IIIB)",
         LiverState(LiverT.T4, LiverN.N0, LiverM.M0, P, NO, NO, NO), "IIIB"),
        ("T2 N1 M0 -- any T with N1 (IVA)",
         LiverState(LiverT.T2, LiverN.N1, LiverM.M0, P, NO, NO, NO), "IVA"),
        ("any T any N M1 (IVB)",
         LiverState(LiverT.T1A, LiverN.N0, LiverM.M1, C, NO, NO, NO), "IVB"),
        ("unstageable: bare T1 has no stage entry",
         LiverState(LiverT.T1, LiverN.N0, LiverM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
        ("unstageable: TX",
         LiverState(LiverT.TX, LiverN.N0, LiverM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
