"""Stomach AJCC 8 staging.

Source: pdfsource/stomach.pdf. State carries AJCC fields beyond TNM:

- **Classification** (`c` / `p`): how the assessment was made.
  - `c` (Clinical)     -- pre-treatment, imaging/biopsy based
  - `p` (Pathological) -- based on the resected specimen
- **Descriptors**: AJCC prefix modifiers that compose with the
  classification. AJCC defines them as a SET, so each base descriptor
  is encoded as an independent Yes/No flag column: `DescY`, `DescR`,
  `DescM`. Multiple descriptors may apply simultaneously.
  - `y` -- assessment during or after neoadjuvant therapy
  - `r` -- recurrent tumor classification
  - `m` -- multiple synchronous primary tumors

Matching semantics (encoded directly in the rule CSV via `ANY`):
  - Classification=c                        -> cTNM table  (any DescY/DescR/DescM)
  - Classification=p AND DescY=No           -> pTNM table  (any DescR/DescM)
  - Classification=p AND DescY=Yes          -> ypTNM table (any DescR/DescM)

In other words, only the `y` descriptor switches behavior under `p`;
`r` and `m` are presentational/clinical context and don't currently
select a different stage table for stomach. If a source manual ever
defines stomach-specific rTNM or mTNM rules, add them as new rows
keyed by `DescR=Yes` / `DescM=Yes` without changing this file.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class StomachT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class StomachN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class StomachM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class StomachState(NamedTuple):
    T: StomachT
    N: StomachN
    M: StomachM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO

MODEL = StagingModel(
    name="stomach",
    edition=Edition.AJCC_8,
    category="gi",
    state_cls=StomachState,
    columns={
        "T": StomachT,
        "N": StomachN,
        "M": StomachM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "cTNM: in-situ disease (no descriptors)",
            StomachState(StomachT.TIS, StomachN.N0, StomachM.M0,
                         Classification.CLINICAL, NO, NO, NO),
            "0",
        ),
        (
            "cTNM: T1N0 with m descriptor present -- still cTNM Stage I",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M0,
                         Classification.CLINICAL, NO, NO, YES),
            "I",
        ),
        (
            "cTNM: T4b adjacent-structure (Stage IVA)",
            StomachState(StomachT.T4B, StomachN.N0, StomachM.M0,
                         Classification.CLINICAL, NO, NO, NO),
            "IVA",
        ),
        (
            "cTNM: distant metastasis (Stage IVB)",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M1,
                         Classification.CLINICAL, NO, NO, NO),
            "IVB",
        ),
        (
            "pTNM: T1N0 -- canonical p (no y, no r, no m)",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M0,
                         Classification.PATHOLOGICAL, NO, NO, NO),
            "IA",
        ),
        (
            "pTNM: T1N0 with r descriptor -- falls back to canonical pTNM",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M0,
                         Classification.PATHOLOGICAL, NO, YES, NO),
            "IA",
        ),
        (
            "pTNM: T4b N0 (Stage IIIA)",
            StomachState(StomachT.T4B, StomachN.N0, StomachM.M0,
                         Classification.PATHOLOGICAL, NO, NO, NO),
            "IIIA",
        ),
        (
            "pTNM: T2 N3a uses N3 subcategory",
            StomachState(StomachT.T2, StomachN.N3A, StomachM.M0,
                         Classification.PATHOLOGICAL, NO, NO, NO),
            "IIIA",
        ),
        (
            "ypTNM: T1N0 with y descriptor -- post-neoadjuvant pathological",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M0,
                         Classification.PATHOLOGICAL, YES, NO, NO),
            "I",
        ),
        (
            "ypTNM: T1N0 with y AND r -- still ypTNM (y dominates)",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M0,
                         Classification.PATHOLOGICAL, YES, YES, NO),
            "I",
        ),
        (
            "ypTNM: T4b N3 (Stage III)",
            StomachState(StomachT.T4B, StomachN.N3, StomachM.M0,
                         Classification.PATHOLOGICAL, YES, NO, NO),
            "III",
        ),
        (
            "ypTNM: distant metastasis (Stage IV, no IVB split)",
            StomachState(StomachT.T1, StomachN.N0, StomachM.M1,
                         Classification.PATHOLOGICAL, YES, NO, NO),
            "IV",
        ),
        (
            "unstageable: ypTNM has no Tis rule (PDF starts ypTNM at T1)",
            StomachState(StomachT.TIS, StomachN.N0, StomachM.M0,
                         Classification.PATHOLOGICAL, YES, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
