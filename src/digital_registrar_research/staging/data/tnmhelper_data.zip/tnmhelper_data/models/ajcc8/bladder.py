"""Urinary bladder, AJCC 8.

Source: pdfsource/bladderv8.pdf. Single stage group table; cTNM and pTNM
use the same rules.

T categories: TX, T0, Ta, Tis, T1, T2, T2a, T2b, T3, T3a, T3b, T4, T4a, T4b
  - Ta:  Non-invasive papillary carcinoma
  - Tis: Urothelial carcinoma in situ ("flat tumor")
  - T1:  Tumor invades lamina propria (subepithelial connective tissue)
  - T2:  Tumor invades muscularis propria (parent of T2a/T2b)
      T2a: Tumor invades superficial muscularis propria (inner half)
      T2b: Tumor invades deep muscularis propria (outer half)
  - T3:  Tumor invades perivesical soft tissue (parent of T3a/T3b)
      T3a: Microscopically
      T3b: Macroscopically (extravesical mass)
  - T4:  Extravesical tumor directly invades any of: prostatic stroma,
         seminal vesicles, uterus, vagina, pelvic wall, abdominal wall
         (parent of T4a/T4b)
      T4a: Prostatic stroma, seminal vesicles, uterus, vagina
      T4b: Pelvic wall, abdominal wall

N categories: NX, N0, N1, N2, N3
M categories: M0, M1, M1a (nodes beyond common iliacs), M1b (non-lymph node)

Stage rows from the PDF table:
  - 0a:   Ta  N0 M0
  - 0is:  Tis N0 M0
  - I:    T1  N0 M0
  - II:   T2a N0 M0
  - II:   T2b N0 M0
  - IIIA: T3a, T3b, T4a  N0 M0
  - IIIA: T1, T2, T3, T4a  N1 M0
  - IIIB: T1, T2, T3, T4a  N2/N3 M0
  - IVA:  T4b any N M0
  - IVA:  any T any N M1a
  - IVB:  any T any N M1b

Notes on parent T categories:
  - Bare T2 with N0 M0 has NO stage entry (use T2a/T2b). Returns UNSTAGEABLE.
  - Bare T3 with N0 M0 has NO stage entry (use T3a/T3b). Returns UNSTAGEABLE.
  - Bare T4 with N0 M0 has NO stage entry (use T4a/T4b). Returns UNSTAGEABLE.
  - Bare T2, T3 with N1+/M0 ARE staged (table literally says "T1, T2, T3, T4a").
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class BladderT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TA = "Ta"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T2A = "T2a"
    T2B = "T2b"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class BladderN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N3 = "N3"


class BladderM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"


class BladderState(NamedTuple):
    T: BladderT
    N: BladderN
    M: BladderM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="bladder",
    edition=Edition.AJCC_8,
    category="urologic",
    state_cls=BladderState,
    columns={
        "T": BladderT,
        "N": BladderN,
        "M": BladderM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("Ta N0 M0 -> 0a",
         BladderState(BladderT.TA, BladderN.N0, BladderM.M0, P, NO, NO, NO), "0a"),
        ("Tis N0 M0 -> 0is",
         BladderState(BladderT.TIS, BladderN.N0, BladderM.M0, P, NO, NO, NO), "0is"),
        ("T1 N0 M0 -> I",
         BladderState(BladderT.T1, BladderN.N0, BladderM.M0, P, NO, NO, NO), "I"),
        ("T2a N0 M0 -> II (superficial muscularis propria)",
         BladderState(BladderT.T2A, BladderN.N0, BladderM.M0, P, NO, NO, NO), "II"),
        ("T2b N0 M0 -> II (deep muscularis propria)",
         BladderState(BladderT.T2B, BladderN.N0, BladderM.M0, P, NO, NO, NO), "II"),
        ("T3a N0 M0 -> IIIA",
         BladderState(BladderT.T3A, BladderN.N0, BladderM.M0, P, NO, NO, NO), "IIIA"),
        ("T3b N0 M0 -> IIIA",
         BladderState(BladderT.T3B, BladderN.N0, BladderM.M0, P, NO, NO, NO), "IIIA"),
        ("T4a N0 M0 -> IIIA",
         BladderState(BladderT.T4A, BladderN.N0, BladderM.M0, P, NO, NO, NO), "IIIA"),
        ("T2 N1 M0 -> IIIA (bare T2 staged with N1)",
         BladderState(BladderT.T2, BladderN.N1, BladderM.M0, C, NO, NO, NO), "IIIA"),
        ("T3 N1 M0 -> IIIA",
         BladderState(BladderT.T3, BladderN.N1, BladderM.M0, C, NO, NO, NO), "IIIA"),
        ("T1 N2 M0 -> IIIB",
         BladderState(BladderT.T1, BladderN.N2, BladderM.M0, P, NO, NO, NO), "IIIB"),
        ("T4a N3 M0 -> IIIB",
         BladderState(BladderT.T4A, BladderN.N3, BladderM.M0, P, NO, NO, NO), "IIIB"),
        ("T4b N0 M0 -> IVA",
         BladderState(BladderT.T4B, BladderN.N0, BladderM.M0, P, NO, NO, NO), "IVA"),
        ("T4b N2 M0 -> IVA",
         BladderState(BladderT.T4B, BladderN.N2, BladderM.M0, P, NO, NO, NO), "IVA"),
        ("any T any N M1a -> IVA (mets beyond common iliacs)",
         BladderState(BladderT.T2A, BladderN.N0, BladderM.M1A, C, NO, NO, NO), "IVA"),
        ("any T any N M1b -> IVB (non-lymph node distant mets)",
         BladderState(BladderT.T3A, BladderN.N1, BladderM.M1B, C, NO, NO, NO), "IVB"),
        ("unstageable: bare T2 with N0 has no stage entry",
         BladderState(BladderT.T2, BladderN.N0, BladderM.M0, P, NO, NO, NO), "UNSTAGEABLE"),
        ("unstageable: bare T3 with N0 has no stage entry",
         BladderState(BladderT.T3, BladderN.N0, BladderM.M0, P, NO, NO, NO), "UNSTAGEABLE"),
        ("unstageable: bare T4 with N0 has no stage entry",
         BladderState(BladderT.T4, BladderN.N0, BladderM.M0, P, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
