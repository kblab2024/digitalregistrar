"""Hypopharynx squamous cell carcinoma, AJCC 8.

Source: pdfsource/hypopharynx.pdf. AJCC 8 covers p16-/HPV-unrelated
oropharynx and hypopharynx in the same chapter, sharing one N table
and one stage group table; the two sites differ only in their T
definitions. This module encodes the hypopharyngeal T axis; see
oropharynx_p16neg.py for the parallel oropharyngeal model.

A single stage group table applies identically to cTNM, pTNM, and
ypTNM; every CSV rule uses `ANY` for Classification and descriptor
columns.

T leaf categories: TX, Tis, T1, T2, T3, T4a, T4b. There is no bare T4
in this chapter -- T4 disease is always classified as T4a (moderately
advanced) or T4b (very advanced).

Stage rows summarized (identical to oral cavity and p16- oropharynx):
  - Stage 0:   Tis N0 M0
  - Stage I:   T1 N0 M0
  - Stage II:  T2 N0 M0
  - Stage III: T3 N0 M0; T1-T3 N1 M0
  - Stage IVA: T4a N0-N1 M0; T1-T4a N2-family M0
  - Stage IVB: any T N3-family M0; T4b any N M0
  - Stage IVC: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class HypopharynxT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4A = "T4a"
    T4B = "T4b"


class HypopharynxN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class HypopharynxM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class HypopharynxState(NamedTuple):
    T: HypopharynxT
    N: HypopharynxN
    M: HypopharynxM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="hypopharynx",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=HypopharynxState,
    columns={
        "T": HypopharynxT,
        "N": HypopharynxN,
        "M": HypopharynxM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            HypopharynxState(HypopharynxT.TIS, HypopharynxN.N0, HypopharynxM.M0,
                             P, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 -- single subsite or <= 2 cm (Stage I)",
            HypopharynxState(HypopharynxT.T1, HypopharynxN.N0, HypopharynxM.M0,
                             C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            HypopharynxState(HypopharynxT.T2, HypopharynxN.N0, HypopharynxM.M0,
                             P, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- fixation of hemilarynx (Stage III)",
            HypopharynxState(HypopharynxT.T3, HypopharynxN.N0, HypopharynxM.M0,
                             P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N1 M0 -- T1-T3 with N1 (Stage III)",
            HypopharynxState(HypopharynxT.T2, HypopharynxN.N1, HypopharynxM.M0,
                             P, NO, NO, NO),
            "III",
        ),
        (
            "T4a N0 M0 -- thyroid/cricoid cartilage invasion (Stage IVA)",
            HypopharynxState(HypopharynxT.T4A, HypopharynxN.N0, HypopharynxM.M0,
                             P, NO, NO, NO),
            "IVA",
        ),
        (
            "T2 N2b M0 -- T1-T4a with N2 family (Stage IVA)",
            HypopharynxState(HypopharynxT.T2, HypopharynxN.N2B, HypopharynxM.M0,
                             P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1 N3a M0 -- any T with N3 family (Stage IVB)",
            HypopharynxState(HypopharynxT.T1, HypopharynxN.N3A, HypopharynxM.M0,
                             P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N0 M0 -- prevertebral fascia / carotid encasement (Stage IVB)",
            HypopharynxState(HypopharynxT.T4B, HypopharynxN.N0, HypopharynxM.M0,
                             P, NO, NO, NO),
            "IVB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IVC)",
            HypopharynxState(HypopharynxT.T3, HypopharynxN.N2, HypopharynxM.M1,
                             C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored (still Stage III)",
            HypopharynxState(HypopharynxT.T2, HypopharynxN.N1, HypopharynxM.M0,
                             P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: TX has no stage-table entry",
            HypopharynxState(HypopharynxT.TX, HypopharynxN.N0, HypopharynxM.M0,
                             C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
