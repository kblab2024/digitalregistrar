"""Testis (testicular cancer), AJCC 8.

Source: pdfsource/_pages_testisv8/p1.png..p6.png.

AJCC 8 testis staging is unusual in two ways:

  1. T1-T3 cannot be assigned on clinical grounds -- a radical orchiectomy
     specimen is required. The clinical T (cT) categories defined by the
     manual are therefore restricted to cTX, cT0, cTis, and cT4 (scrotal
     invasion, which is clinically apparent). The pathological T (pT)
     categories pTX, pT0, pTis, pT1, pT1a, pT1b, pT2, pT3, pT4 carry the
     anatomic T-staging weight. This model uses the pT family as the
     canonical T values (since the stage tables are driven by pT).

  2. A fourth ``S`` axis -- serum tumor markers -- is required for stage
     grouping in addition to T, N, M. The five categories are SX, S0,
     S1, S2, S3 (S1/S2/S3 are graded bands of LDH, hCG, AFP).

Stage groups (from the pathological pTNM table on page 6):

  - 0:    Tis N0 M0 S0
  - I:    T1-T4 N0 M0 SX
  - IA:   pT1 N0 M0 S0
  - IB:   pT2/pT3/pT4 N0 M0 S0
  - IS:   any T N0 M0 S1/S2/S3
  - II:   any T N1-N3 M0 SX
  - IIA:  any T N1 M0 S0 or S1
  - IIB:  any T N2 M0 S0 or S1
  - IIC:  any T N3 M0 S0 or S1
  - III:  any T any N M1 SX
  - IIIA: any T any N M1a S0 or S1
  - IIIB: any T N1-N3 M0 S2 or any T any N M1a S2
  - IIIC: any T N1-N3 M0 S3 or any T any N M1a S3 or any T any N M1b any S

Classification, DescY, DescR, DescM are retained for parity with other
organ models but are not used by the rule lookup (all rules use ANY).
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class TestisT(StrEnum):
    """Primary tumor (pathological pT family per AJCC 8 testis)."""

    PTX = "pTX"
    PT0 = "pT0"
    PTIS = "pTis"
    PT1 = "pT1"
    PT1A = "pT1a"
    PT1B = "pT1b"
    PT2 = "pT2"
    PT3 = "pT3"
    PT4 = "pT4"


class TestisN(StrEnum):
    """Regional lymph node (pathological pN family)."""

    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N3 = "N3"


class TestisM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"


class TestisS(StrEnum):
    """Serum tumor markers (LDH, hCG, AFP)."""

    SX = "SX"
    S0 = "S0"
    S1 = "S1"
    S2 = "S2"
    S3 = "S3"


class TestisState(NamedTuple):
    T: TestisT
    N: TestisN
    M: TestisM
    S: TestisS
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


P = Classification.PATHOLOGICAL
C = Classification.CLINICAL
NO = YesNo.NO
YES = YesNo.YES


MODEL = StagingModel(
    name="testis",
    edition=Edition.AJCC_8,
    category="urologic",
    state_cls=TestisState,
    columns={
        "T": TestisT,
        "N": TestisN,
        "M": TestisM,
        "S": TestisS,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("pTis N0 M0 S0 -> 0",
         TestisState(TestisT.PTIS, TestisN.N0, TestisM.M0, TestisS.S0,
                     P, NO, NO, NO), "0"),
        ("pT1 N0 M0 SX -> I",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M0, TestisS.SX,
                     P, NO, NO, NO), "I"),
        ("pT1 N0 M0 S0 -> IA",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M0, TestisS.S0,
                     P, NO, NO, NO), "IA"),
        ("pT2 N0 M0 S0 -> IB",
         TestisState(TestisT.PT2, TestisN.N0, TestisM.M0, TestisS.S0,
                     P, NO, NO, NO), "IB"),
        ("pT4 N0 M0 S0 -> IB",
         TestisState(TestisT.PT4, TestisN.N0, TestisM.M0, TestisS.S0,
                     P, NO, NO, NO), "IB"),
        ("pT1 N0 M0 S1 -> IS (any T N0 M0 elevated S)",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M0, TestisS.S1,
                     P, NO, NO, NO), "IS"),
        ("pT3 N0 M0 S3 -> IS",
         TestisState(TestisT.PT3, TestisN.N0, TestisM.M0, TestisS.S3,
                     P, NO, NO, NO), "IS"),
        ("pT2 N1 M0 SX -> II",
         TestisState(TestisT.PT2, TestisN.N1, TestisM.M0, TestisS.SX,
                     P, NO, NO, NO), "II"),
        ("pT1 N1 M0 S0 -> IIA",
         TestisState(TestisT.PT1, TestisN.N1, TestisM.M0, TestisS.S0,
                     P, NO, NO, NO), "IIA"),
        ("pT2 N2 M0 S1 -> IIB",
         TestisState(TestisT.PT2, TestisN.N2, TestisM.M0, TestisS.S1,
                     P, NO, NO, NO), "IIB"),
        ("pT1 N3 M0 S0 -> IIC",
         TestisState(TestisT.PT1, TestisN.N3, TestisM.M0, TestisS.S0,
                     P, NO, NO, NO), "IIC"),
        ("pT1 N0 M1 SX -> III",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M1, TestisS.SX,
                     P, NO, NO, NO), "III"),
        ("pT1 N0 M1a S0 -> IIIA",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M1A, TestisS.S0,
                     P, NO, NO, NO), "IIIA"),
        ("pT1 N1 M0 S2 -> IIIB (N1-N3 M0 with S2)",
         TestisState(TestisT.PT1, TestisN.N1, TestisM.M0, TestisS.S2,
                     P, NO, NO, NO), "IIIB"),
        ("pT1 N0 M1a S2 -> IIIB (M1a with S2)",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M1A, TestisS.S2,
                     P, NO, NO, NO), "IIIB"),
        ("pT1 N2 M0 S3 -> IIIC (N1-N3 M0 with S3)",
         TestisState(TestisT.PT1, TestisN.N2, TestisM.M0, TestisS.S3,
                     P, NO, NO, NO), "IIIC"),
        ("pT1 N0 M1a S3 -> IIIC",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M1A, TestisS.S3,
                     P, NO, NO, NO), "IIIC"),
        ("pT1 N0 M1b any S -> IIIC",
         TestisState(TestisT.PT1, TestisN.N0, TestisM.M1B, TestisS.S0,
                     P, NO, NO, NO), "IIIC"),
    ),
)
