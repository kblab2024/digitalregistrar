"""Larynx (glottis) squamous cell carcinoma, AJCC 8.

Source: pdfsource/larynx.pdf. AJCC 8 defines distinct T tables for each
laryngeal subsite (supraglottis, glottis, subglottis) but shares the
N table (ENE-based head/neck N family) and the Stage 0/I/II/III/IVA/
IVB/IVC group table with the other p16- head/neck sites.

The glottic T axis adds T1a (one vocal cord) and T1b (both vocal cords)
subcategories that do not exist for the supraglottis/subglottis. In the
stage table T1, T1a, and T1b are interchangeable -- the CSV expands
every T1-family row into the three explicit literals so the engine can
match by literal equality.

A single stage group table applies identically to cTNM, pTNM, and
ypTNM; every CSV rule uses `ANY` for Classification and descriptor
columns.

T leaf categories: TX, Tis, T1, T1a, T1b, T2, T3, T4a, T4b.

Stage rows summarized (head/neck shared table; T1 family is interchangeable):
  - Stage 0:   Tis N0 M0
  - Stage I:   T1-family N0 M0
  - Stage II:  T2 N0 M0
  - Stage III: T3 N0 M0; T1-family/T2/T3 with N1 M0
  - Stage IVA: T4a N0-N1 M0; T1-family/T2/T3/T4a with N2-family M0
  - Stage IVB: any T N3-family M0; T4b any N M0
  - Stage IVC: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class LarynxGlottisT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4A = "T4a"
    T4B = "T4b"


class LarynxGlottisN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class LarynxGlottisM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class LarynxGlottisState(NamedTuple):
    T: LarynxGlottisT
    N: LarynxGlottisN
    M: LarynxGlottisM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="larynx_glottis",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=LarynxGlottisState,
    columns={
        "T": LarynxGlottisT,
        "N": LarynxGlottisN,
        "M": LarynxGlottisM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            LarynxGlottisState(LarynxGlottisT.TIS, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "0",
        ),
        (
            "T1a N0 M0 -- single vocal cord (Stage I)",
            LarynxGlottisState(LarynxGlottisT.T1A, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T1b N0 M0 -- both vocal cords (Stage I)",
            LarynxGlottisState(LarynxGlottisT.T1B, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T1 N0 M0 -- T1 parent literal (Stage I)",
            LarynxGlottisState(LarynxGlottisT.T1, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            LarynxGlottisState(LarynxGlottisT.T2, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- vocal cord fixation (Stage III)",
            LarynxGlottisState(LarynxGlottisT.T3, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T1a N1 M0 -- T1-family with N1 (Stage III)",
            LarynxGlottisState(LarynxGlottisT.T1A, LarynxGlottisN.N1,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T4a N1 M0 -- T4a with N0-N1 (Stage IVA)",
            LarynxGlottisState(LarynxGlottisT.T4A, LarynxGlottisN.N1,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1b N2b M0 -- T1-family with N2 family (Stage IVA)",
            LarynxGlottisState(LarynxGlottisT.T1B, LarynxGlottisN.N2B,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1 N3a M0 -- any T with N3 family (Stage IVB)",
            LarynxGlottisState(LarynxGlottisT.T1, LarynxGlottisN.N3A,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N0 M0 -- prevertebral / carotid encasement (Stage IVB)",
            LarynxGlottisState(LarynxGlottisT.T4B, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IVC)",
            LarynxGlottisState(LarynxGlottisT.T2, LarynxGlottisN.N1,
                               LarynxGlottisM.M1, C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored (still Stage III)",
            LarynxGlottisState(LarynxGlottisT.T2, LarynxGlottisN.N1,
                               LarynxGlottisM.M0, P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: TX has no stage-table entry",
            LarynxGlottisState(LarynxGlottisT.TX, LarynxGlottisN.N0,
                               LarynxGlottisM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
