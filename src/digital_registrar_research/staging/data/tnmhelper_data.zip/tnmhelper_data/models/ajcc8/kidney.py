"""Kidney, AJCC 8.

Source: pdfsource/kidneyv8.pdf. Single stage group table; cTNM and pTNM
use the same rules.

T categories: TX, T0, T1, T1a, T1b, T2, T2a, T2b, T3, T3a, T3b, T3c, T4
  - T1: <= 7 cm, limited to kidney (parent of T1a/T1b)
      T1a: <= 4 cm
      T1b: > 4 cm but <= 7 cm
  - T2: > 7 cm, limited to kidney (parent of T2a/T2b)
      T2a: > 7 cm but <= 10 cm
      T2b: > 10 cm
  - T3: extends into major veins/perinephric tissues but not adrenal/Gerota's
      T3a: renal vein/branches, pelvicalyceal, perirenal/renal sinus fat
      T3b: vena cava below diaphragm
      T3c: vena cava above diaphragm or wall of vena cava
  - T4: invades beyond Gerota's fascia (incl. ipsilateral adrenal)

N categories: NX, N0, N1
M categories: M0, M1

Stage rows:
  - I:   T1 N0 M0
  - II:  T2 N0 M0
  - III: T1 N1 M0; T2 N1 M0; T3 NX/N0/N1 M0
  - IV:  T4 any N M0; any T any N M1

Bare T1, T2, T3 ARE staged at the parent level (table uses T1, T2, T3
literally, not the subdivisions). T1a/T1b/T2a/T2b/T3a/T3b/T3c states
return UNSTAGEABLE unless mapped at parent — see CSV; we add explicit
rules so all leaf categories stage too.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class KidneyT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T2A = "T2a"
    T2B = "T2b"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T3C = "T3c"
    T4 = "T4"


class KidneyN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class KidneyM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class KidneyState(NamedTuple):
    T: KidneyT
    N: KidneyN
    M: KidneyM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="kidney",
    edition=Edition.AJCC_8,
    category="urologic",
    state_cls=KidneyState,
    columns={
        "T": KidneyT,
        "N": KidneyN,
        "M": KidneyM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("T1a N0 M0 -> I",
         KidneyState(KidneyT.T1A, KidneyN.N0, KidneyM.M0, P, NO, NO, NO), "I"),
        ("T1b N0 M0 -> I",
         KidneyState(KidneyT.T1B, KidneyN.N0, KidneyM.M0, P, NO, NO, NO), "I"),
        ("T2 N0 M0 -> II",
         KidneyState(KidneyT.T2, KidneyN.N0, KidneyM.M0, P, NO, NO, NO), "II"),
        ("T2a N0 M0 -> II",
         KidneyState(KidneyT.T2A, KidneyN.N0, KidneyM.M0, P, NO, NO, NO), "II"),
        ("T3 N0 M0 -> III",
         KidneyState(KidneyT.T3, KidneyN.N0, KidneyM.M0, P, NO, NO, NO), "III"),
        ("T3a NX M0 -> III (NX explicitly staged for T3)",
         KidneyState(KidneyT.T3A, KidneyN.NX, KidneyM.M0, P, NO, NO, NO), "III"),
        ("T1 N1 M0 -> III (any N1 with T1/T2/T3)",
         KidneyState(KidneyT.T1, KidneyN.N1, KidneyM.M0, C, NO, NO, NO), "III"),
        ("T2b N1 M0 -> III",
         KidneyState(KidneyT.T2B, KidneyN.N1, KidneyM.M0, P, NO, NO, NO), "III"),
        ("T4 N0 M0 -> IV",
         KidneyState(KidneyT.T4, KidneyN.N0, KidneyM.M0, P, NO, NO, NO), "IV"),
        ("T4 N1 M0 -> IV",
         KidneyState(KidneyT.T4, KidneyN.N1, KidneyM.M0, P, NO, NO, NO), "IV"),
        ("any T any N M1 -> IV",
         KidneyState(KidneyT.T1A, KidneyN.N0, KidneyM.M1, C, NO, NO, NO), "IV"),
        ("T3c N1 M1 -> IV",
         KidneyState(KidneyT.T3C, KidneyN.N1, KidneyM.M1, C, NO, NO, NO), "IV"),
    ),
)
