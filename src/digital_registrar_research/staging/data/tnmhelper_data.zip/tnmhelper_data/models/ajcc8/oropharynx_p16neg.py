"""Oropharynx HPV-unrelated (p16-) squamous cell carcinoma, AJCC 8.

Source: pdfsource/oropharynx_p16neg.pdf. AJCC 8 covers p16-/HPV-unrelated
oropharynx and hypopharynx in the same chapter, sharing one N table and
one stage group table; the two sites differ only in their T definitions.
This module encodes the oropharyngeal T axis; see hypopharynx.py for the
parallel hypopharyngeal model.

A single stage group table applies identically to cTNM, pTNM, and ypTNM;
every CSV rule uses `ANY` for Classification and descriptor columns.

T leaf categories: TX, Tis, T1, T2, T3, T4a, T4b. There is no bare T4
in this chapter -- T4 disease is always classified as T4a (moderately
advanced) or T4b (very advanced).

Stage rows summarized (identical to oral cavity AJCC 8):
  - Stage 0:   Tis N0 M0
  - Stage I:   T1 N0 M0
  - Stage II:  T2 N0 M0
  - Stage III: T3 N0 M0; T1-T3 N1 M0
  - Stage IVA: T4a N0-N1 M0; T1-T4a N2-family M0
  - Stage IVB: any T N3-family M0; T4b any N M0
  - Stage IVC: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class OropharynxP16NegT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4A = "T4a"
    T4B = "T4b"


class OropharynxP16NegN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class OropharynxP16NegM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class OropharynxP16NegState(NamedTuple):
    T: OropharynxP16NegT
    N: OropharynxP16NegN
    M: OropharynxP16NegM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="oropharynx_p16neg",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=OropharynxP16NegState,
    columns={
        "T": OropharynxP16NegT,
        "N": OropharynxP16NegN,
        "M": OropharynxP16NegM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            OropharynxP16NegState(OropharynxP16NegT.TIS, OropharynxP16NegN.N0,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 (Stage I)",
            OropharynxP16NegState(OropharynxP16NegT.T1, OropharynxP16NegN.N0,
                                  OropharynxP16NegM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            OropharynxP16NegState(OropharynxP16NegT.T2, OropharynxP16NegN.N0,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 (Stage III)",
            OropharynxP16NegState(OropharynxP16NegT.T3, OropharynxP16NegN.N0,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N1 M0 -- T1-T3 with N1 (Stage III)",
            OropharynxP16NegState(OropharynxP16NegT.T2, OropharynxP16NegN.N1,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T4a N1 M0 -- T4a with N0-N1 (Stage IVA)",
            OropharynxP16NegState(OropharynxP16NegT.T4A, OropharynxP16NegN.N1,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T3 N2c M0 -- T1-T4a with N2 family (Stage IVA)",
            OropharynxP16NegState(OropharynxP16NegT.T3, OropharynxP16NegN.N2C,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1 N3 M0 -- any T with N3 family (Stage IVB)",
            OropharynxP16NegState(OropharynxP16NegT.T1, OropharynxP16NegN.N3,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N0 M0 -- T4b at any N (Stage IVB)",
            OropharynxP16NegState(OropharynxP16NegT.T4B, OropharynxP16NegN.N0,
                                  OropharynxP16NegM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IVC)",
            OropharynxP16NegState(OropharynxP16NegT.T2, OropharynxP16NegN.N1,
                                  OropharynxP16NegM.M1, C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored (still Stage III)",
            OropharynxP16NegState(OropharynxP16NegT.T2, OropharynxP16NegN.N1,
                                  OropharynxP16NegM.M0, P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: TX has no stage-table entry",
            OropharynxP16NegState(OropharynxP16NegT.TX, OropharynxP16NegN.N0,
                                  OropharynxP16NegM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
