"""Oral cavity AJCC 8 staging.

Source: pdfsource/oral_cavity.pdf. AJCC 8 defines a single stage group
table for oral cavity that applies identically to cTNM, pTNM, and
ypTNM. Every rule in the CSV therefore uses `ANY` for Classification
and the three descriptor columns -- the stage outcome does not depend
on them. The fields are still part of state for clinical record-keeping
and to keep the GUI/data-entry shape consistent across organs.

T leaf categories used by the stage table are TX, Tis, T1, T2, T3, T4a,
T4b. Bare `T4` is the parent grouping for T4a/T4b and is NOT used as a
stage-table key; a state with T=T4 therefore returns UNSTAGEABLE.

N category conventions in the AJCC 8 oral cavity stage table:
  - "N1" / "N2" / "N3" in the table refer to those exact codes, but the
    N2 family (N2, N2a, N2b, N2c) and N3 family (N3, N3a, N3b) all map
    to the same row in the stage table. The CSV expands every such row
    into the explicit subcategory rules so the build pipeline can match
    by literal equality.

Stage rows summarized:
  - Stage 0:   Tis N0 M0
  - Stage I:   T1 N0 M0
  - Stage II:  T2 N0 M0
  - Stage III: T3 N0 M0; T1-T3 N1 M0
  - Stage IVA: T4a N0-N1 M0; T1-T4a N2-family M0
  - Stage IVB: any T N3-family M0; T4b any N M0
  - Stage IVC: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class OralCavityT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class OralCavityN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class OralCavityM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class OralCavityState(NamedTuple):
    T: OralCavityT
    N: OralCavityN
    M: OralCavityM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="oral_cavity",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=OralCavityState,
    columns={
        "T": OralCavityT,
        "N": OralCavityN,
        "M": OralCavityM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            OralCavityState(OralCavityT.TIS, OralCavityN.N0, OralCavityM.M0,
                            C, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 (Stage I)",
            OralCavityState(OralCavityT.T1, OralCavityN.N0, OralCavityM.M0,
                            C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            OralCavityState(OralCavityT.T2, OralCavityN.N0, OralCavityM.M0,
                            C, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 (Stage III)",
            OralCavityState(OralCavityT.T3, OralCavityN.N0, OralCavityM.M0,
                            C, NO, NO, NO),
            "III",
        ),
        (
            "T1 N1 M0 -- N1 promotes to Stage III",
            OralCavityState(OralCavityT.T1, OralCavityN.N1, OralCavityM.M0,
                            P, NO, NO, NO),
            "III",
        ),
        (
            "T4a N0 M0 (Stage IVA)",
            OralCavityState(OralCavityT.T4A, OralCavityN.N0, OralCavityM.M0,
                            P, NO, NO, NO),
            "IVA",
        ),
        (
            "T2 N2b M0 -- N2 family with T1-T4a (Stage IVA)",
            OralCavityState(OralCavityT.T2, OralCavityN.N2B, OralCavityM.M0,
                            P, NO, NO, NO),
            "IVA",
        ),
        (
            "T4a N2c M0 -- still Stage IVA",
            OralCavityState(OralCavityT.T4A, OralCavityN.N2C, OralCavityM.M0,
                            P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1 N3a M0 -- any T with N3 family promotes to Stage IVB",
            OralCavityState(OralCavityT.T1, OralCavityN.N3A, OralCavityM.M0,
                            P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N0 M0 -- T4b at any N is Stage IVB",
            OralCavityState(OralCavityT.T4B, OralCavityN.N0, OralCavityM.M0,
                            P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N3b M0 -- both T4b and N3-family rules say IVB",
            OralCavityState(OralCavityT.T4B, OralCavityN.N3B, OralCavityM.M0,
                            P, NO, NO, NO),
            "IVB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IVC)",
            OralCavityState(OralCavityT.T1, OralCavityN.N0, OralCavityM.M1,
                            C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored for oral cavity (still III)",
            OralCavityState(OralCavityT.T2, OralCavityN.N1, OralCavityM.M0,
                            P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: bare T4 is a parent grouping, not a leaf",
            OralCavityState(OralCavityT.T4, OralCavityN.N0, OralCavityM.M0,
                            C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "unstageable: TX has no stage-table entry",
            OralCavityState(OralCavityT.TX, OralCavityN.N0, OralCavityM.M0,
                            C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "T1 NX M0 -- NX aliased to N0 in engine -> I",
            OralCavityState(OralCavityT.T1, OralCavityN.NX, OralCavityM.M0,
                            C, NO, NO, NO),
            "I",
        ),
    ),
)
