"""Esophageal adenocarcinoma, AJCC 8.

Source: pdfsource/esophagus.pdf. Encodes the three AJCC 8 stage group
tables for esophageal adenocarcinoma:

  - Classification=c                 -> cTNM (Grade ignored)
  - Classification=p AND DescY=No    -> pTNM (Grade matters)
  - Classification=p AND DescY=Yes   -> ypTNM (Grade ignored)

T leaf categories in stage tables: Tis, T1, T1a, T1b, T2, T3, T4a, T4b.
T0 is a leaf in the ypTNM table only. TX and bare T4 are in the enum
for documentation but have no stage-table entry; states using them
resolve to UNSTAGEABLE.

Grade leaf categories: GX, G1, G2, G3 (Grade applies only to pTNM).

Notable features:
  - Adenocarcinoma pTNM has a unique Stage IC (T1 G3, T2 G1-G2).
  - ypTNM rolls T0 in with T1/T2 for Stage I; T0 has no role in cTNM
    or pTNM stage tables.
  - T4b, N3, and M1 always map to the same stage (IVA, IVA, IVB
    respectively) across all three tables; those rules use ANY for
    Classification/DescY.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class EsophagusAdenoT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class EsophagusAdenoN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N3 = "N3"


class EsophagusAdenoM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class EsophagusAdenoGrade(StrEnum):
    GX = "GX"
    G1 = "G1"
    G2 = "G2"
    G3 = "G3"


class EsophagusAdenoState(NamedTuple):
    T: EsophagusAdenoT
    N: EsophagusAdenoN
    M: EsophagusAdenoM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo
    Grade: EsophagusAdenoGrade


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL
GX = EsophagusAdenoGrade.GX
G1 = EsophagusAdenoGrade.G1
G2 = EsophagusAdenoGrade.G2
G3 = EsophagusAdenoGrade.G3

MODEL = StagingModel(
    name="esophagus_adeno",
    edition=Edition.AJCC_8,
    category="gi",
    state_cls=EsophagusAdenoState,
    columns={
        "T": EsophagusAdenoT,
        "N": EsophagusAdenoN,
        "M": EsophagusAdenoM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
        "Grade": EsophagusAdenoGrade,
    },
    examples=(
        # --- cTNM ---
        ("cTNM Tis N0 M0 (0)",
         EsophagusAdenoState(EsophagusAdenoT.TIS, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "0"),
        ("cTNM T1a N0 M0 (I)",
         EsophagusAdenoState(EsophagusAdenoT.T1A, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "I"),
        ("cTNM T1b N1 M0 -- T1 family with N1 (IIA)",
         EsophagusAdenoState(EsophagusAdenoT.T1B, EsophagusAdenoN.N1,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "IIA"),
        ("cTNM T2 N0 M0 (IIB)",
         EsophagusAdenoState(EsophagusAdenoT.T2, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "IIB"),
        ("cTNM T3 N0 M0 (III)",
         EsophagusAdenoState(EsophagusAdenoT.T3, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "III"),
        ("cTNM T4a N1 M0 -- T4a with N0-N1 (III)",
         EsophagusAdenoState(EsophagusAdenoT.T4A, EsophagusAdenoN.N1,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "III"),
        ("cTNM T3 N2 M0 -- T1-T4a with N2 (IVA)",
         EsophagusAdenoState(EsophagusAdenoT.T3, EsophagusAdenoN.N2,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "IVA"),
        ("cTNM T4b N0 M0 -- T4b any N (IVA)",
         EsophagusAdenoState(EsophagusAdenoT.T4B, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "IVA"),
        ("cTNM T1 N3 M0 -- any T with N3 (IVA)",
         EsophagusAdenoState(EsophagusAdenoT.T1, EsophagusAdenoN.N3,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "IVA"),
        ("cTNM T1 N0 M1 (IVB)",
         EsophagusAdenoState(EsophagusAdenoT.T1, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M1, C, NO, NO, NO, GX), "IVB"),
        # --- pTNM (Grade matters) ---
        ("pTNM Tis N0 M0 (0)",
         EsophagusAdenoState(EsophagusAdenoT.TIS, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, GX), "0"),
        ("pTNM T1a N0 M0 G1 (IA)",
         EsophagusAdenoState(EsophagusAdenoT.T1A, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G1), "IA"),
        ("pTNM T1a N0 M0 GX (IA)",
         EsophagusAdenoState(EsophagusAdenoT.T1A, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, GX), "IA"),
        ("pTNM T1a N0 M0 G2 (IB)",
         EsophagusAdenoState(EsophagusAdenoT.T1A, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G2), "IB"),
        ("pTNM T1b N0 M0 G1 (IB)",
         EsophagusAdenoState(EsophagusAdenoT.T1B, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G1), "IB"),
        ("pTNM T1a N0 M0 G3 -- T1 G3 special (IC)",
         EsophagusAdenoState(EsophagusAdenoT.T1A, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G3), "IC"),
        ("pTNM T2 N0 M0 G2 -- T2 G1-G2 (IC)",
         EsophagusAdenoState(EsophagusAdenoT.T2, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G2), "IC"),
        ("pTNM T2 N0 M0 G3 (IIA)",
         EsophagusAdenoState(EsophagusAdenoT.T2, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G3), "IIA"),
        ("pTNM T1 N1 M0 -- any G (IIB)",
         EsophagusAdenoState(EsophagusAdenoT.T1, EsophagusAdenoN.N1,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G2), "IIB"),
        ("pTNM T3 N0 M0 -- any G (IIB)",
         EsophagusAdenoState(EsophagusAdenoT.T3, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G3), "IIB"),
        ("pTNM T2 N1 M0 (IIIA)",
         EsophagusAdenoState(EsophagusAdenoT.T2, EsophagusAdenoN.N1,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G1), "IIIA"),
        ("pTNM T4a N0 M0 (IIIB)",
         EsophagusAdenoState(EsophagusAdenoT.T4A, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G2), "IIIB"),
        ("pTNM T4a N2 M0 (IVA)",
         EsophagusAdenoState(EsophagusAdenoT.T4A, EsophagusAdenoN.N2,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G2), "IVA"),
        ("pTNM T4b N0 M0 (IVA)",
         EsophagusAdenoState(EsophagusAdenoT.T4B, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, GX), "IVA"),
        ("pTNM any T any N M1 (IVB)",
         EsophagusAdenoState(EsophagusAdenoT.T1, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M1, P, NO, NO, NO, GX), "IVB"),
        # --- ypTNM ---
        ("ypTNM T0 N0 M0 -- T0 valid in ypTNM only (I)",
         EsophagusAdenoState(EsophagusAdenoT.T0, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, YES, NO, NO, GX), "I"),
        ("ypTNM T2 N0 M0 (I)",
         EsophagusAdenoState(EsophagusAdenoT.T2, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, YES, NO, NO, GX), "I"),
        ("ypTNM T3 N0 M0 (II)",
         EsophagusAdenoState(EsophagusAdenoT.T3, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, YES, NO, NO, GX), "II"),
        ("ypTNM T2 N1 M0 (IIIA)",
         EsophagusAdenoState(EsophagusAdenoT.T2, EsophagusAdenoN.N1,
                             EsophagusAdenoM.M0, P, YES, NO, NO, GX), "IIIA"),
        ("ypTNM T3 N1 M0 (IIIB)",
         EsophagusAdenoState(EsophagusAdenoT.T3, EsophagusAdenoN.N1,
                             EsophagusAdenoM.M0, P, YES, NO, NO, GX), "IIIB"),
        ("ypTNM T4a NX M0 -- special T4a NX (IVA)",
         EsophagusAdenoState(EsophagusAdenoT.T4A, EsophagusAdenoN.NX,
                             EsophagusAdenoM.M0, P, YES, NO, NO, GX), "IVA"),
        ("ypTNM any T any N M1 (IVB)",
         EsophagusAdenoState(EsophagusAdenoT.T1, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M1, P, YES, NO, NO, GX), "IVB"),
        # --- failures ---
        ("unstageable: bare T4 has no cTNM/pTNM/ypTNM entry",
         EsophagusAdenoState(EsophagusAdenoT.T4, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "UNSTAGEABLE"),
        ("unstageable: TX",
         EsophagusAdenoState(EsophagusAdenoT.TX, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, C, NO, NO, NO, GX), "UNSTAGEABLE"),
        ("unstageable: pTNM T1 N0 G1 -- T1 (bare) G1 not in stage table",
         EsophagusAdenoState(EsophagusAdenoT.T1, EsophagusAdenoN.N0,
                             EsophagusAdenoM.M0, P, NO, NO, NO, G1), "UNSTAGEABLE"),
    ),
)
