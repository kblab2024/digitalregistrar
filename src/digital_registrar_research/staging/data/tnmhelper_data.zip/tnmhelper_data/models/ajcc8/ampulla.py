"""Ampulla of Vater, AJCC 8.

Source: pdfsource/ampulla.pdf. Single stage group table; cTNM and pTNM
use the same rules. Every CSV rule uses `ANY` for Classification and
descriptors.

T leaf categories used by the stage table: Tis, T1a, T1b, T2, T3a, T3b,
T4. Bare T1 and T3 are parent categories and have NO stage-table entry;
states with T=T1 or T=T3 return UNSTAGEABLE.

Stage rows summarized:
  - 0:    Tis N0 M0
  - IA:   T1a N0 M0
  - IB:   T1b N0 M0; T2 N0 M0
  - IIA:  T3a N0 M0
  - IIB:  T3b N0 M0
  - IIIA: T1a/T1b/T2/T3a/T3b with N1, M0
  - IIIB: T4 any N M0; any T with N2 M0
  - IV:   any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class AmpullaT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T4 = "T4"


class AmpullaN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"


class AmpullaM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class AmpullaState(NamedTuple):
    T: AmpullaT
    N: AmpullaN
    M: AmpullaM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="ampulla",
    edition=Edition.AJCC_8,
    category="gi",
    state_cls=AmpullaState,
    columns={
        "T": AmpullaT,
        "N": AmpullaN,
        "M": AmpullaM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("Tis N0 M0 (Stage 0)",
         AmpullaState(AmpullaT.TIS, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "0"),
        ("T1a N0 M0 (Stage IA)",
         AmpullaState(AmpullaT.T1A, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "IA"),
        ("T1b N0 M0 (Stage IB)",
         AmpullaState(AmpullaT.T1B, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "IB"),
        ("T2 N0 M0 -- muscularis propria of duodenum (Stage IB)",
         AmpullaState(AmpullaT.T2, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "IB"),
        ("T3a N0 M0 -- pancreas <= 0.5 cm (Stage IIA)",
         AmpullaState(AmpullaT.T3A, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "IIA"),
        ("T3b N0 M0 -- pancreas > 0.5 cm (Stage IIB)",
         AmpullaState(AmpullaT.T3B, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "IIB"),
        ("T2 N1 M0 -- any subdivided T with N1 (Stage IIIA)",
         AmpullaState(AmpullaT.T2, AmpullaN.N1, AmpullaM.M0, P, NO, NO, NO), "IIIA"),
        ("T4 N0 M0 -- celiac axis / SMA / common hepatic artery (Stage IIIB)",
         AmpullaState(AmpullaT.T4, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "IIIB"),
        ("T1a N2 M0 -- any T with N2 (Stage IIIB)",
         AmpullaState(AmpullaT.T1A, AmpullaN.N2, AmpullaM.M0, P, NO, NO, NO), "IIIB"),
        ("any T any N M1 (Stage IV)",
         AmpullaState(AmpullaT.T2, AmpullaN.N1, AmpullaM.M1, C, NO, NO, NO), "IV"),
        ("unstageable: bare T1 has no stage entry",
         AmpullaState(AmpullaT.T1, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "UNSTAGEABLE"),
        ("unstageable: bare T3 has no stage entry",
         AmpullaState(AmpullaT.T3, AmpullaN.N0, AmpullaM.M0, P, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
