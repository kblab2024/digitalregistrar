"""Corpus uteri carcinoma and carcinosarcoma, AJCC 8.

Source: pdfsource/_pages_corpusv8/. Single stage table aligned with FIGO
(corpus uteri). cTNM and pTNM share rules. Every CSV rule uses `ANY` for
Classification and descriptors.

Notable rule patterns:
  - Stage Group Table per AJCC 8 corpus:
      T1   N0 M0 -> I
      T1a  N0 M0 -> IA
      T1b  N0 M0 -> IB
      T2   N0 M0 -> II
      T3   N0 M0 -> III
      T3a  N0 M0 -> IIIA
      T3b  N0 M0 -> IIIB
      T1-T3 + N1/N1mi/N1a   M0 -> IIIC1
      T1-T3 + N2/N2mi/N2a   M0 -> IIIC2
      T4   any N M0 -> IVA
      any T any N M1 -> IVB

  - N0(i+) is a defined category (ITCs <= 0.2 mm). It is not mentioned
    in the corpus stage-group table; rules.csv treats it as N0 for
    stage-group lookup (so T1a N0(i+) M0 -> IA, etc.).
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class CorpusT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T4 = "T4"


class CorpusN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N0IPLUS = "N0(i+)"
    N1 = "N1"
    N1MI = "N1mi"
    N1A = "N1a"
    N2 = "N2"
    N2MI = "N2mi"
    N2A = "N2a"


class CorpusM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class CorpusState(NamedTuple):
    T: CorpusT
    N: CorpusN
    M: CorpusM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="corpus",
    edition=Edition.AJCC_8,
    category="gyn",
    state_cls=CorpusState,
    columns={
        "T": CorpusT,
        "N": CorpusN,
        "M": CorpusM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("T1 N0 M0 -- tumor confined to corpus uteri (I)",
         CorpusState(CorpusT.T1, CorpusN.N0, CorpusM.M0, C, NO, NO, NO), "I"),
        ("T1a N0 M0 -- endometrium or <1/2 myometrium (IA)",
         CorpusState(CorpusT.T1A, CorpusN.N0, CorpusM.M0, P, NO, NO, NO), "IA"),
        ("T1b N0 M0 -- >=1/2 myometrium (IB)",
         CorpusState(CorpusT.T1B, CorpusN.N0, CorpusM.M0, P, NO, NO, NO), "IB"),
        ("T2 N0 M0 -- cervical stromal invasion (II)",
         CorpusState(CorpusT.T2, CorpusN.N0, CorpusM.M0, P, NO, NO, NO), "II"),
        ("T3a N0 M0 -- serosa/adnexa involved (IIIA)",
         CorpusState(CorpusT.T3A, CorpusN.N0, CorpusM.M0, P, NO, NO, NO), "IIIA"),
        ("T3b N0 M0 -- vaginal or parametrial involvement (IIIB)",
         CorpusState(CorpusT.T3B, CorpusN.N0, CorpusM.M0, P, NO, NO, NO), "IIIB"),
        ("T1a N1mi M0 -- micrometastasis in pelvic nodes (IIIC1)",
         CorpusState(CorpusT.T1A, CorpusN.N1MI, CorpusM.M0, P, NO, NO, NO), "IIIC1"),
        ("T2 N1a M0 -- pelvic node macrometastasis (IIIC1)",
         CorpusState(CorpusT.T2, CorpusN.N1A, CorpusM.M0, P, NO, NO, NO), "IIIC1"),
        ("T3a N2a M0 -- para-aortic node macrometastasis (IIIC2)",
         CorpusState(CorpusT.T3A, CorpusN.N2A, CorpusM.M0, P, NO, NO, NO), "IIIC2"),
        ("T4 N0 M0 -- bladder/bowel mucosa invasion (IVA)",
         CorpusState(CorpusT.T4, CorpusN.N0, CorpusM.M0, P, NO, NO, NO), "IVA"),
        ("T1 N0 M1 -- distant metastasis (IVB)",
         CorpusState(CorpusT.T1, CorpusN.N0, CorpusM.M1, C, NO, NO, NO), "IVB"),
        ("T1a N0(i+) M0 -- ITCs only treated as N0 (IA)",
         CorpusState(CorpusT.T1A, CorpusN.N0IPLUS, CorpusM.M0, P, NO, NO, NO), "IA"),
    ),
)
