"""Renal Pelvis and Ureter (upper tract urothelial carcinoma), AJCC 8.

Source: pdfsource/ureterv8.pdf. Single stage group table; cTNM and pTNM
use the same rules. Every CSV rule uses `ANY` for Classification and
descriptors.

T categories: TX, T0, Ta, Tis, T1, T2, T3, T4
  - Ta:  Papillary noninvasive carcinoma
  - Tis: Carcinoma in situ
  - T1:  Tumor invades subepithelial connective tissue
  - T2:  Tumor invades the muscularis
  - T3:  Renal pelvis: invades beyond muscularis into peripelvic fat or
         renal parenchyma. Ureter: invades beyond muscularis into
         periureteric fat.
  - T4:  Invades adjacent organs, or through the kidney into the
         perinephric fat.

N categories: NX, N0, N1, N2
  - N1: Metastasis <= 2 cm in greatest dimension, in a single node.
  - N2: Metastasis > 2 cm in a single node; or multiple nodes.

M categories: M0, M1

Stage rows:
  - 0a:  Ta N0 M0
  - 0is: Tis N0 M0
  - I:   T1 N0 M0
  - II:  T2 N0 M0
  - III: T3 N0 M0
  - IV:  T4 NX/N0 M0; any T N1 M0; any T N2 M0; any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class UreterT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TA = "Ta"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class UreterN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"


class UreterM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class UreterState(NamedTuple):
    T: UreterT
    N: UreterN
    M: UreterM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="ureter",
    edition=Edition.AJCC_8,
    category="urologic",
    state_cls=UreterState,
    columns={
        "T": UreterT,
        "N": UreterN,
        "M": UreterM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("Ta N0 M0 -> 0a",
         UreterState(UreterT.TA, UreterN.N0, UreterM.M0, P, NO, NO, NO), "0a"),
        ("Tis N0 M0 -> 0is",
         UreterState(UreterT.TIS, UreterN.N0, UreterM.M0, P, NO, NO, NO), "0is"),
        ("T1 N0 M0 -> I",
         UreterState(UreterT.T1, UreterN.N0, UreterM.M0, P, NO, NO, NO), "I"),
        ("T2 N0 M0 -> II",
         UreterState(UreterT.T2, UreterN.N0, UreterM.M0, P, NO, NO, NO), "II"),
        ("T3 N0 M0 -> III",
         UreterState(UreterT.T3, UreterN.N0, UreterM.M0, P, NO, NO, NO), "III"),
        ("T4 N0 M0 -> IV",
         UreterState(UreterT.T4, UreterN.N0, UreterM.M0, P, NO, NO, NO), "IV"),
        ("T4 NX M0 -> IV (NX explicitly staged with T4)",
         UreterState(UreterT.T4, UreterN.NX, UreterM.M0, C, NO, NO, NO), "IV"),
        ("T1 N1 M0 -> IV (any T with N1)",
         UreterState(UreterT.T1, UreterN.N1, UreterM.M0, P, NO, NO, NO), "IV"),
        ("T2 N2 M0 -> IV (any T with N2)",
         UreterState(UreterT.T2, UreterN.N2, UreterM.M0, P, NO, NO, NO), "IV"),
        ("any T any N M1 -> IV",
         UreterState(UreterT.T3, UreterN.N1, UreterM.M1, C, NO, NO, NO), "IV"),
    ),
)
