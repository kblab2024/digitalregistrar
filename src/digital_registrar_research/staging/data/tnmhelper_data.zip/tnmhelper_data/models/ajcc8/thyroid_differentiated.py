"""Thyroid -- differentiated carcinoma (papillary, follicular, poorly
differentiated, Hurthle cell), AJCC 8.

Source: pdfsource/thyroidv8.pdf. The thyroid AJCC 8 manual covers two
histology buckets that share the SAME T/N/M criteria but use DIFFERENT
stage tables: (1) Differentiated carcinoma (this model) and (2)
Anaplastic carcinoma (separate model). Age at diagnosis is part of the
prognostic stage grouping for differentiated histology.

T categories: TX, T0, T1, T1a, T1b, T2, T3, T3a, T3b, T4, T4a, T4b.
N categories: NX, N0, N0a (positive cytology only), N0b (no evidence of
locoregional metastasis), N1, N1a (level VI/VII), N1b (lateral neck /
retropharyngeal).
M categories: M0, M1.

Differentiated stage table (AJCC 8, age at diagnosis dichotomized at 55):

  Age < 55 years
    Any T, Any N, M0 -> I
    Any T, Any N, M1 -> II

  Age >= 55 years
    T1 / T1a / T1b, N0/NX, M0 -> I
    T2,                N0/NX, M0 -> I
    T1 / T1a / T1b, N1,    M0 -> II
    T2,                N1,    M0 -> II
    T3a / T3b, Any N, M0 -> II
    T4a,       Any N, M0 -> III
    T4b,       Any N, M0 -> IVA
    Any T, Any N, M1   -> IVB

Bare T3 and T4 are parent codes with no stage-table row; they resolve to
UNSTAGEABLE. TX/T0 likewise have no stage-table row when age >= 55 and
M0 (UNSTAGEABLE), but ANY T with M1 resolves regardless of age.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class ThyroidDiffT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class ThyroidDiffN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N0A = "N0a"
    N0B = "N0b"
    N1 = "N1"
    N1A = "N1a"
    N1B = "N1b"


class ThyroidDiffM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class AgeAtDiagnosis(StrEnum):
    LT_55 = "<55"
    GTE_55 = ">=55"


class ThyroidDiffState(NamedTuple):
    T: ThyroidDiffT
    N: ThyroidDiffN
    M: ThyroidDiffM
    Age: AgeAtDiagnosis
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL
LT55 = AgeAtDiagnosis.LT_55
GTE55 = AgeAtDiagnosis.GTE_55


MODEL = StagingModel(
    name="thyroid_differentiated",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=ThyroidDiffState,
    columns={
        "T": ThyroidDiffT,
        "N": ThyroidDiffN,
        "M": ThyroidDiffM,
        "Age": AgeAtDiagnosis,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("age<55, T1 N0 M0 -> I",
         ThyroidDiffState(ThyroidDiffT.T1, ThyroidDiffN.N0, ThyroidDiffM.M0,
                          LT55, P, NO, NO, NO), "I"),
        ("age<55, T4b N1b M0 -> I (age dominates under 55)",
         ThyroidDiffState(ThyroidDiffT.T4B, ThyroidDiffN.N1B, ThyroidDiffM.M0,
                          LT55, P, NO, NO, NO), "I"),
        ("age<55, T2 N1a M1 -> II (M1 under 55)",
         ThyroidDiffState(ThyroidDiffT.T2, ThyroidDiffN.N1A, ThyroidDiffM.M1,
                          LT55, C, NO, NO, NO), "II"),
        ("age>=55, T1a N0 M0 -> I",
         ThyroidDiffState(ThyroidDiffT.T1A, ThyroidDiffN.N0, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "I"),
        ("age>=55, T2 NX M0 -> I",
         ThyroidDiffState(ThyroidDiffT.T2, ThyroidDiffN.NX, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "I"),
        ("age>=55, T1b N1a M0 -> II",
         ThyroidDiffState(ThyroidDiffT.T1B, ThyroidDiffN.N1A, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "II"),
        ("age>=55, T2 N1b M0 -> II",
         ThyroidDiffState(ThyroidDiffT.T2, ThyroidDiffN.N1B, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "II"),
        ("age>=55, T3a N0 M0 -> II",
         ThyroidDiffState(ThyroidDiffT.T3A, ThyroidDiffN.N0, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "II"),
        ("age>=55, T3b N1b M0 -> II",
         ThyroidDiffState(ThyroidDiffT.T3B, ThyroidDiffN.N1B, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "II"),
        ("age>=55, T4a N0 M0 -> III",
         ThyroidDiffState(ThyroidDiffT.T4A, ThyroidDiffN.N0, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "III"),
        ("age>=55, T4a N1b M0 -> III",
         ThyroidDiffState(ThyroidDiffT.T4A, ThyroidDiffN.N1B, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "III"),
        ("age>=55, T4b N0 M0 -> IVA",
         ThyroidDiffState(ThyroidDiffT.T4B, ThyroidDiffN.N0, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "IVA"),
        ("age>=55, T4b Any N M0 -> IVA",
         ThyroidDiffState(ThyroidDiffT.T4B, ThyroidDiffN.N1A, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "IVA"),
        ("age>=55, T2 N0 M1 -> IVB",
         ThyroidDiffState(ThyroidDiffT.T2, ThyroidDiffN.N0, ThyroidDiffM.M1,
                          GTE55, C, NO, NO, NO), "IVB"),
        ("age>=55, T4b N1b M1 -> IVB (M1 dominates)",
         ThyroidDiffState(ThyroidDiffT.T4B, ThyroidDiffN.N1B, ThyroidDiffM.M1,
                          GTE55, C, NO, NO, NO), "IVB"),
        ("unstageable: age>=55, bare T3 has no stage row",
         ThyroidDiffState(ThyroidDiffT.T3, ThyroidDiffN.N0, ThyroidDiffM.M0,
                          GTE55, P, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
