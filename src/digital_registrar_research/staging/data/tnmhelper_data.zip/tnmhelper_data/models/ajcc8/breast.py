"""Breast AJCC 8 staging.

Source: pdfsource/breast.pdf. The breast manual defines THREE distinct
stage group tables; this model encodes all three, keyed by the
Classification axis:

- Classification=a  -> Anatomic stage group       (TNM only; biomarkers/grade ignored)
- Classification=c  -> Clinical Prognostic group  (TNM + Grade + HER2/ER/PR)
- Classification=p  -> Pathological Prognostic    (TNM + Grade + HER2/ER/PR)

Descriptor flags (DescY/DescR/DescM) are carried for record-keeping
parity with colon/lung/stomach; the AJCC breast stage tables do not
change based on descriptors, so every rule uses ANY for these three
columns.

Footnote expansion (used when transcribing the clinical/pathologic
tables into CSV rows):
  - T1*   -> {T1, T1mi, T1a, T1b, T1c}   ("T1 includes T1mi")
  - N1**  -> {N1, N1a, N1b, N1c}          (N1 family, NOT N1mi -- N1mi
                                           appears in its own rows in the
                                           IA tier)
  - N1*** -> {N1, N1a, N1b, N1c}          (same expansion as N1**; the
                                           manual uses different asterisk
                                           counts as visual disambiguation)
  - N2    -> {N2, N2a, N2b}                (every clinical/pathologic row
                                           that writes "N2" applies to any
                                           N2 subcategory)
  - N3    -> {N3, N3a, N3b, N3c}           (same intent as N2)

Anatomic table parent categories likewise expand: T1 -> {T1,T1mi,T1a,T1b,T1c},
T4 -> {T4,T4a,T4b,T4c,T4d}, N1 -> {N1,N1a,N1b,N1c} (no N1mi), N2 ->
{N2,N2a,N2b}, N3 -> {N3,N3a,N3b,N3c}. "Any T" stays as ANY.

Known gaps:
- The Oncotype DX < 11 exception in the Pathological table is not
  modeled (would require an extra axis on BreastState).
- HER2 Equivocal is NOT auto-coerced to Negative even though AJCC's
  Clinical Prognostic table calls for that treatment. The data-entry
  layer should map Equivocal -> Negative before querying; an
  Equivocal value here returns UNSTAGEABLE.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Biomarker, Classification, Edition, StagingModel, YesNo


class BreastT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1MI = "T1mi"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T1C = "T1c"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"
    T4C = "T4c"
    T4D = "T4d"


class BreastN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1MI = "N1mi"
    N1 = "N1"
    N1A = "N1a"
    N1B = "N1b"
    N1C = "N1c"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"
    N3C = "N3c"


class BreastM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class BreastGrade(StrEnum):
    GX = "GX"
    G1 = "G1"
    G2 = "G2"
    G3 = "G3"


class BreastState(NamedTuple):
    T: BreastT
    N: BreastN
    M: BreastM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo
    Grade: BreastGrade
    HER2: Biomarker
    ER: Biomarker
    PR: Biomarker


POS = Biomarker.POSITIVE
NEG = Biomarker.NEGATIVE
EQUIV = Biomarker.EQUIVOCAL
UNK = Biomarker.UNKNOWN
A = Classification.ANATOMIC
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL
NO = YesNo.NO
YES = YesNo.YES

MODEL = StagingModel(
    name="breast",
    edition=Edition.AJCC_8,
    category="breast",
    state_cls=BreastState,
    columns={
        "T": BreastT,
        "N": BreastN,
        "M": BreastM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
        "Grade": BreastGrade,
        "HER2": Biomarker,
        "ER": Biomarker,
        "PR": Biomarker,
    },
    examples=(
        (
            "anatomic: Tis N0 M0 -> Stage 0",
            BreastState(BreastT.TIS, BreastN.N0, BreastM.M0,
                        A, NO, NO, NO, BreastGrade.GX, UNK, UNK, UNK),
            "0",
        ),
        (
            "anatomic: T3 N0 M0 -> IIB",
            BreastState(BreastT.T3, BreastN.N0, BreastM.M0,
                        A, NO, NO, NO, BreastGrade.GX, UNK, UNK, UNK),
            "IIB",
        ),
        (
            "anatomic: T0 N1mi M0 -> IB",
            BreastState(BreastT.T0, BreastN.N1MI, BreastM.M0,
                        A, NO, NO, NO, BreastGrade.GX, UNK, UNK, UNK),
            "IB",
        ),
        (
            "clinical: T3 N0 M0 G3 HER2- ER+ PR- -> IIIA",
            BreastState(BreastT.T3, BreastN.N0, BreastM.M0,
                        C, NO, NO, NO, BreastGrade.G3, NEG, POS, NEG),
            "IIIA",
        ),
        (
            "clinical: T1 N0 M0 G1 hormone-positive HER2- -> IA",
            BreastState(BreastT.T1, BreastN.N0, BreastM.M0,
                        C, NO, NO, NO, BreastGrade.G1, NEG, POS, POS),
            "IA",
        ),
        (
            "pathologic: T3 N0 M0 G3 triple-negative -> IIIA",
            BreastState(BreastT.T3, BreastN.N0, BreastM.M0,
                        P, NO, NO, NO, BreastGrade.G3, NEG, NEG, NEG),
            "IIIA",
        ),
        (
            "pathologic: T2 N1 M0 G2 HER2- ER+ PR+ -> IB (downgrade vs anatomic IIB)",
            BreastState(BreastT.T2, BreastN.N1, BreastM.M0,
                        P, NO, NO, NO, BreastGrade.G2, NEG, POS, POS),
            "IB",
        ),
        (
            "M1 with r descriptor on, mixed biomarkers -> IV",
            BreastState(BreastT.T4D, BreastN.N3, BreastM.M1,
                        C, NO, YES, NO, BreastGrade.GX, POS, NEG, POS),
            "IV",
        ),
        (
            "unstageable: HER2 Equivocal not auto-coerced",
            BreastState(BreastT.T1, BreastN.N0, BreastM.M0,
                        C, NO, NO, NO, BreastGrade.G1, EQUIV, POS, POS),
            "UNSTAGEABLE",
        ),
        (
            "unstageable: clinical query with ER=Unknown",
            BreastState(BreastT.T1, BreastN.N0, BreastM.M0,
                        C, NO, NO, NO, BreastGrade.G1, POS, UNK, POS),
            "UNSTAGEABLE",
        ),
        (
            "clinical: T1c N2a M0 G2 HER2- ER+ PR+ -> IIA "
            "(N2a inherits the bare-N2 row)",
            BreastState(BreastT.T1C, BreastN.N2A, BreastM.M0,
                        C, NO, NO, NO, BreastGrade.G2, NEG, POS, POS),
            "IIA",
        ),
        (
            "pathologic: T1c N3c M0 G2 HER2- ER+ PR+ -> IIIA "
            "(N3c inherits the bare-N3 row)",
            BreastState(BreastT.T1C, BreastN.N3C, BreastM.M0,
                        P, NO, NO, NO, BreastGrade.G2, NEG, POS, POS),
            "IIIA",
        ),
    ),
)
