"""Intrahepatic Bile Ducts (intrahepatic cholangiocarcinoma), AJCC 8.

Source: pdfsource/cholangiov8.pdf. Single stage group table; cTNM and
pTNM use the same rules. Every CSV rule uses `ANY` for Classification
and descriptors.

T leaf categories used by the stage table include the T1a/T1b
subdivisions (parent T1 is NOT a stage-table key; T=T1 returns
UNSTAGEABLE). T2, T3, T4 are leaves.

Stage rows summarized:
  - 0:    Tis N0 M0
  - IA:   T1a N0 M0
  - IB:   T1b N0 M0
  - II:   T2 N0 M0
  - IIIA: T3 N0 M0
  - IIIB: T4 N0 M0, OR any T with N1 M0
  - IV:   any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class CholangioIntrahepaticT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class CholangioIntrahepaticN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class CholangioIntrahepaticM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class CholangioIntrahepaticState(NamedTuple):
    T: CholangioIntrahepaticT
    N: CholangioIntrahepaticN
    M: CholangioIntrahepaticM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="cholangio_intrahepatic",
    edition=Edition.AJCC_8,
    category="hepatobiliary",
    state_cls=CholangioIntrahepaticState,
    columns={
        "T": CholangioIntrahepaticT,
        "N": CholangioIntrahepaticN,
        "M": CholangioIntrahepaticM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("Tis N0 M0 (Stage 0)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.TIS, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, P, NO, NO, NO), "0"),
        ("T1a N0 M0 -- solitary <= 5 cm no vascular invasion (Stage IA)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T1A, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, P, NO, NO, NO), "IA"),
        ("T1b N0 M0 -- solitary > 5 cm no vascular invasion (Stage IB)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T1B, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, P, NO, NO, NO), "IB"),
        ("T2 N0 M0 -- solitary with vascular invasion or multiple tumors (Stage II)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T2, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, P, NO, NO, NO), "II"),
        ("T3 N0 M0 -- perforates visceral peritoneum (Stage IIIA)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T3, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, P, NO, NO, NO), "IIIA"),
        ("T4 N0 M0 -- invades local extrahepatic structures (Stage IIIB)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T4, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, P, NO, NO, NO), "IIIB"),
        ("T2 N1 M0 -- any T with N1 (Stage IIIB)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T2, CholangioIntrahepaticN.N1, CholangioIntrahepaticM.M0, P, NO, NO, NO), "IIIB"),
        ("any T any N M1 (Stage IV)",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T1A, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M1, C, NO, NO, NO), "IV"),
        ("unstageable: bare T1 has no stage entry",
         CholangioIntrahepaticState(CholangioIntrahepaticT.T1, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
        ("unstageable: TX",
         CholangioIntrahepaticState(CholangioIntrahepaticT.TX, CholangioIntrahepaticN.N0, CholangioIntrahepaticM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
