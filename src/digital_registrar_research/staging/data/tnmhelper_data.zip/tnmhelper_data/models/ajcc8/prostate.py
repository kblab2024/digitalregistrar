"""Prostate, AJCC 8.

Source: pdfsource/prostate.pdf. AJCC 8 combines clinical and pathological
T into a SINGLE unified stage table; the T value itself encodes whether
the row applies clinically or pathologically via the cT/pT prefix. This
model carries that convention by using a combined T enum with prefixed
literals (cTX, cT0, ..., cT4, pT2, pT3, pT3a, pT3b, pT4). The shared
Classification axis is kept for parity with other organ models but is
not used by rule matching (all rules use ANY for it).

Additional axes beyond TNM:
  - PSA: 3 bands -- "<10", "10-<20", ">=20"
  - GradeGroup: 1-5 (Gleason-based; source provides no GG-X band)

Notable rule patterns:
  - There is no pT1 (pathological T1) -- pT starts at pT2.
  - cT1 (parent) and cT2 (parent) are kept in the enum for documentation
    but the source stage table never references the bare cT1 or cT2
    parents; states using bare cT1/cT2 will resolve to UNSTAGEABLE.
    Use the cT1a/cT1b/cT1c or cT2a/cT2b/cT2c subdivisions instead.
  - GG=5 with N0 M0 -> IIIC regardless of T and PSA (overrides T-only
    stage assignment).
  - N1 (regardless of M) -> IVA when M=M0; M1/M1a/M1b/M1c always -> IVB.

Stage rows summarized (paraphrased from the source quick-reference):
  - I:    cT1a/b/c or cT2a with PSA<10, GG1, N0, M0; OR pT2 with PSA<10, GG1
  - IIA:  cT1a/b/c, cT2a, or pT2 with PSA 10-<20, GG1; OR cT2b/c with
          PSA<10 or 10-<20, GG1
  - IIB:  cT1a-c, cT2a-c, or pT2 with PSA<10 or 10-<20, GG2
  - IIC:  same T with PSA<10 or 10-<20, GG3 or GG4
  - IIIA: same T (cT1-cT2 family + pT2) with PSA>=20, GG1-4
  - IIIB: cT3 family / cT4 / pT3 family / pT4, any PSA, GG1-4, N0 M0
  - IIIC: any T with GG5, N0, M0
  - IVA:  any T with N1, M0
  - IVB:  any T any N with M1/M1a/M1b/M1c
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class ProstateT(StrEnum):
    CTX = "cTX"
    CT0 = "cT0"
    CT1 = "cT1"
    CT1A = "cT1a"
    CT1B = "cT1b"
    CT1C = "cT1c"
    CT2 = "cT2"
    CT2A = "cT2a"
    CT2B = "cT2b"
    CT2C = "cT2c"
    CT3 = "cT3"
    CT3A = "cT3a"
    CT3B = "cT3b"
    CT4 = "cT4"
    PT2 = "pT2"
    PT3 = "pT3"
    PT3A = "pT3a"
    PT3B = "pT3b"
    PT4 = "pT4"


class ProstateN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class ProstateM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"


class ProstatePSA(StrEnum):
    LT_10 = "<10"
    BTW_10_20 = "10-<20"
    GTE_20 = ">=20"


class ProstateGradeGroup(StrEnum):
    GG1 = "1"
    GG2 = "2"
    GG3 = "3"
    GG4 = "4"
    GG5 = "5"


class ProstateState(NamedTuple):
    T: ProstateT
    N: ProstateN
    M: ProstateM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo
    PSA: ProstatePSA
    GradeGroup: ProstateGradeGroup


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL
PSA_LT10 = ProstatePSA.LT_10
PSA_10_20 = ProstatePSA.BTW_10_20
PSA_GTE20 = ProstatePSA.GTE_20
GG1 = ProstateGradeGroup.GG1
GG2 = ProstateGradeGroup.GG2
GG3 = ProstateGradeGroup.GG3
GG4 = ProstateGradeGroup.GG4
GG5 = ProstateGradeGroup.GG5

MODEL = StagingModel(
    name="prostate",
    edition=Edition.AJCC_8,
    category="urologic",
    state_cls=ProstateState,
    columns={
        "T": ProstateT,
        "N": ProstateN,
        "M": ProstateM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
        "PSA": ProstatePSA,
        "GradeGroup": ProstateGradeGroup,
    },
    examples=(
        ("cT1a N0 M0 PSA<10 GG1 (I)",
         ProstateState(ProstateT.CT1A, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG1), "I"),
        ("pT2 N0 M0 PSA<10 GG1 (I)",
         ProstateState(ProstateT.PT2, ProstateN.N0, ProstateM.M0,
                       P, NO, NO, NO, PSA_LT10, GG1), "I"),
        ("cT2a N0 M0 PSA 10-<20 GG1 (IIA)",
         ProstateState(ProstateT.CT2A, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_10_20, GG1), "IIA"),
        ("cT2b N0 M0 PSA<10 GG1 (IIA)",
         ProstateState(ProstateT.CT2B, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG1), "IIA"),
        ("pT2 N0 M0 PSA<10 GG2 (IIB)",
         ProstateState(ProstateT.PT2, ProstateN.N0, ProstateM.M0,
                       P, NO, NO, NO, PSA_LT10, GG2), "IIB"),
        ("cT1c N0 M0 PSA 10-<20 GG3 (IIC)",
         ProstateState(ProstateT.CT1C, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_10_20, GG3), "IIC"),
        ("cT2c N0 M0 PSA<10 GG4 (IIC)",
         ProstateState(ProstateT.CT2C, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG4), "IIC"),
        ("pT2 N0 M0 PSA>=20 GG2 (IIIA)",
         ProstateState(ProstateT.PT2, ProstateN.N0, ProstateM.M0,
                       P, NO, NO, NO, PSA_GTE20, GG2), "IIIA"),
        ("cT3a N0 M0 PSA<10 GG2 -- T3 family (IIIB)",
         ProstateState(ProstateT.CT3A, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG2), "IIIB"),
        ("pT4 N0 M0 PSA>=20 GG4 -- T4 (IIIB)",
         ProstateState(ProstateT.PT4, ProstateN.N0, ProstateM.M0,
                       P, NO, NO, NO, PSA_GTE20, GG4), "IIIB"),
        ("cT1a N0 M0 PSA<10 GG5 -- GG5 dominates (IIIC)",
         ProstateState(ProstateT.CT1A, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG5), "IIIC"),
        ("cT4 N0 M0 PSA>=20 GG5 -- GG5 still wins over IIIB (IIIC)",
         ProstateState(ProstateT.CT4, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_GTE20, GG5), "IIIC"),
        ("cT2a N1 M0 -- node positive (IVA)",
         ProstateState(ProstateT.CT2A, ProstateN.N1, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG1), "IVA"),
        ("cT2a N0 M1b -- bone metastasis (IVB)",
         ProstateState(ProstateT.CT2A, ProstateN.N0, ProstateM.M1B,
                       C, NO, NO, NO, PSA_LT10, GG1), "IVB"),
        ("cT4 N1 M1c (IVB -- M1 dominates over N1)",
         ProstateState(ProstateT.CT4, ProstateN.N1, ProstateM.M1C,
                       C, NO, NO, NO, PSA_GTE20, GG5), "IVB"),
        ("unstageable: bare cT1 (parent) is not used by stage table",
         ProstateState(ProstateT.CT1, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG1), "UNSTAGEABLE"),
        ("unstageable: cTX",
         ProstateState(ProstateT.CTX, ProstateN.N0, ProstateM.M0,
                       C, NO, NO, NO, PSA_LT10, GG1), "UNSTAGEABLE"),
    ),
)
