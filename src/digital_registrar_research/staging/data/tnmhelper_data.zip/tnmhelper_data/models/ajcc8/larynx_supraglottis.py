"""Larynx (supraglottis) squamous cell carcinoma, AJCC 8.

Source: pdfsource/larynx.pdf. AJCC 8 defines distinct T tables for each
laryngeal subsite (supraglottis, glottis, subglottis) but shares the
N table (ENE-based head/neck N family) and the Stage 0/I/II/III/IVA/
IVB/IVC group table with the other p16- head/neck sites. This module
encodes the supraglottic T axis; see larynx_glottis.py and
larynx_subglottis.py for the parallel subsite models.

A single stage group table applies identically to cTNM, pTNM, and
ypTNM; every CSV rule uses `ANY` for Classification and descriptor
columns.

T leaf categories: TX, Tis, T1, T2, T3, T4a, T4b.

Stage rows summarized (head/neck shared table):
  - Stage 0:   Tis N0 M0
  - Stage I:   T1 N0 M0
  - Stage II:  T2 N0 M0
  - Stage III: T3 N0 M0; T1-T3 N1 M0
  - Stage IVA: T4a N0-N1 M0; T1-T4a N2-family M0
  - Stage IVB: any T N3-family M0; T4b any N M0
  - Stage IVC: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class LarynxSupraglottisT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4A = "T4a"
    T4B = "T4b"


class LarynxSupraglottisN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class LarynxSupraglottisM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class LarynxSupraglottisState(NamedTuple):
    T: LarynxSupraglottisT
    N: LarynxSupraglottisN
    M: LarynxSupraglottisM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="larynx_supraglottis",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=LarynxSupraglottisState,
    columns={
        "T": LarynxSupraglottisT,
        "N": LarynxSupraglottisN,
        "M": LarynxSupraglottisM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            LarynxSupraglottisState(LarynxSupraglottisT.TIS, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 -- limited to one subsite, normal mobility (Stage I)",
            LarynxSupraglottisState(LarynxSupraglottisT.T1, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            LarynxSupraglottisState(LarynxSupraglottisT.T2, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- vocal cord fixation (Stage III)",
            LarynxSupraglottisState(LarynxSupraglottisT.T3, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N1 M0 (Stage III)",
            LarynxSupraglottisState(LarynxSupraglottisT.T2, LarynxSupraglottisN.N1,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T4a N0 M0 -- through outer thyroid cartilage (Stage IVA)",
            LarynxSupraglottisState(LarynxSupraglottisT.T4A, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T3 N2c M0 -- T1-T4a with N2 family (Stage IVA)",
            LarynxSupraglottisState(LarynxSupraglottisT.T3, LarynxSupraglottisN.N2C,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1 N3a M0 -- any T with N3 family (Stage IVB)",
            LarynxSupraglottisState(LarynxSupraglottisT.T1, LarynxSupraglottisN.N3A,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N0 M0 -- prevertebral / carotid encasement (Stage IVB)",
            LarynxSupraglottisState(LarynxSupraglottisT.T4B, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IVC)",
            LarynxSupraglottisState(LarynxSupraglottisT.T2, LarynxSupraglottisN.N1,
                                    LarynxSupraglottisM.M1, C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored (still Stage III)",
            LarynxSupraglottisState(LarynxSupraglottisT.T2, LarynxSupraglottisN.N1,
                                    LarynxSupraglottisM.M0, P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: TX has no stage-table entry",
            LarynxSupraglottisState(LarynxSupraglottisT.TX, LarynxSupraglottisN.N0,
                                    LarynxSupraglottisM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
