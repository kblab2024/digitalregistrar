"""Pancreas (exocrine adenocarcinoma), AJCC 8.

Source: pdfsource/pancreas.pdf. Single stage group table; cTNM and
pTNM use the same rules. Every CSV rule uses `ANY` for Classification
and descriptors.

T leaf categories used by the stage table include both the parent T1
and the T1a/T1b/T1c subdivisions (all behave identically in the stage
table). T2, T3, T4 are leaves. The CSV expands the T1 family into
explicit literals.

Stage rows summarized:
  - 0:   Tis N0 M0
  - IA:  T1 family N0 M0
  - IB:  T2 N0 M0
  - IIA: T3 N0 M0
  - IIB: T1 family / T2 / T3 with N1 M0
  - III: any T1-T3 with N2 M0; T4 any N M0
  - IV:  any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class PancreasT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T1C = "T1c"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class PancreasN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"


class PancreasM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class PancreasState(NamedTuple):
    T: PancreasT
    N: PancreasN
    M: PancreasM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="pancreas",
    edition=Edition.AJCC_8,
    category="hepatobiliary",
    state_cls=PancreasState,
    columns={
        "T": PancreasT,
        "N": PancreasN,
        "M": PancreasM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("Tis N0 M0 (Stage 0)",
         PancreasState(PancreasT.TIS, PancreasN.N0, PancreasM.M0, P, NO, NO, NO), "0"),
        ("T1 N0 M0 -- parent T1 (Stage IA)",
         PancreasState(PancreasT.T1, PancreasN.N0, PancreasM.M0, P, NO, NO, NO), "IA"),
        ("T1c N0 M0 -- 1-2 cm (Stage IA)",
         PancreasState(PancreasT.T1C, PancreasN.N0, PancreasM.M0, P, NO, NO, NO), "IA"),
        ("T2 N0 M0 -- 2-4 cm (Stage IB)",
         PancreasState(PancreasT.T2, PancreasN.N0, PancreasM.M0, P, NO, NO, NO), "IB"),
        ("T3 N0 M0 -- > 4 cm (Stage IIA)",
         PancreasState(PancreasT.T3, PancreasN.N0, PancreasM.M0, P, NO, NO, NO), "IIA"),
        ("T1b N1 M0 -- T1 family with N1 (Stage IIB)",
         PancreasState(PancreasT.T1B, PancreasN.N1, PancreasM.M0, P, NO, NO, NO), "IIB"),
        ("T3 N1 M0 (Stage IIB)",
         PancreasState(PancreasT.T3, PancreasN.N1, PancreasM.M0, P, NO, NO, NO), "IIB"),
        ("T2 N2 M0 -- any T1-T3 with N2 (Stage III)",
         PancreasState(PancreasT.T2, PancreasN.N2, PancreasM.M0, P, NO, NO, NO), "III"),
        ("T4 N0 M0 -- celiac axis / SMA / common hepatic artery (Stage III)",
         PancreasState(PancreasT.T4, PancreasN.N0, PancreasM.M0, P, NO, NO, NO), "III"),
        ("T4 N2 M0 (Stage III)",
         PancreasState(PancreasT.T4, PancreasN.N2, PancreasM.M0, P, NO, NO, NO), "III"),
        ("any T any N M1 (Stage IV)",
         PancreasState(PancreasT.T2, PancreasN.N1, PancreasM.M1, C, NO, NO, NO), "IV"),
        ("unstageable: TX",
         PancreasState(PancreasT.TX, PancreasN.N0, PancreasM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
