"""Ovary / fallopian tube / primary peritoneal carcinoma, AJCC 8.

Source: pdfsource/ovary.pdf. Single stage table aligned with FIGO 2014.
cTNM and pTNM share rules. Every CSV rule uses `ANY` for Classification
and descriptors.

Notable rule patterns:
  - T3a/T3b/T3c with ANY N (and M0) -> IIIA2/IIIB/IIIC respectively
    (the source row says "T3a NX,N0,N1 M0 -> IIIA2"; expanded here to
    any N value, since the per-row stage is independent of N for
    T3a/T3b/T3c).
  - T1 family (T1, T1a, T1b, T1c, T1c1, T1c2, T1c3) and T2 family
    (T2, T2a, T2b) with N1/N1a/N1b -> IIIA1.
  - M1a -> IVA, M1b -> IVB; bare M1 -> IV (parent).
  - T1c subdivisions (T1c1/T1c2/T1c3) all roll up to IC in the stage
    table.

Stage rows summarized:
  - I/IA/IB/IC:     T1 family with N0 (subcategory determines exact stage)
  - II/IIA/IIB:     T2 family with N0
  - IIIA1:          T1 family or T2 family with N1 family
  - IIIA2/IIIB/IIIC: T3a/T3b/T3c with any N
  - IVA:            any T, any N, M1a
  - IVB:            any T, any N, M1b
  - IV:             any T, any N, M1 (parent, unspecified)
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class OvaryT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T1C = "T1c"
    T1C1 = "T1c1"
    T1C2 = "T1c2"
    T1C3 = "T1c3"
    T2 = "T2"
    T2A = "T2a"
    T2B = "T2b"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T3C = "T3c"


class OvaryN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N0_I_PLUS = "N0(i+)"
    N1 = "N1"
    N1A = "N1a"
    N1B = "N1b"


class OvaryM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"


class OvaryState(NamedTuple):
    T: OvaryT
    N: OvaryN
    M: OvaryM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="ovary",
    edition=Edition.AJCC_8,
    category="gyn",
    state_cls=OvaryState,
    columns={
        "T": OvaryT,
        "N": OvaryN,
        "M": OvaryM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("T1a N0 M0 -- one ovary capsule intact (IA)",
         OvaryState(OvaryT.T1A, OvaryN.N0, OvaryM.M0, C, NO, NO, NO), "IA"),
        ("T1c1 N0 M0 -- surgical spill (IC)",
         OvaryState(OvaryT.T1C1, OvaryN.N0, OvaryM.M0, P, NO, NO, NO), "IC"),
        ("T2a N0 M0 (IIA)",
         OvaryState(OvaryT.T2A, OvaryN.N0, OvaryM.M0, P, NO, NO, NO), "IIA"),
        ("T1 N1 M0 -- T1 family with N1 (IIIA1)",
         OvaryState(OvaryT.T1, OvaryN.N1, OvaryM.M0, P, NO, NO, NO), "IIIA1"),
        ("T2b N1a M0 -- T2 family with N1 family (IIIA1)",
         OvaryState(OvaryT.T2B, OvaryN.N1A, OvaryM.M0, P, NO, NO, NO), "IIIA1"),
        ("T3a NX M0 -- microscopic extrapelvic (IIIA2)",
         OvaryState(OvaryT.T3A, OvaryN.NX, OvaryM.M0, P, NO, NO, NO), "IIIA2"),
        ("T3a N1 M0 (IIIA2)",
         OvaryState(OvaryT.T3A, OvaryN.N1, OvaryM.M0, P, NO, NO, NO), "IIIA2"),
        ("T3b N0 M0 -- macroscopic <= 2 cm (IIIB)",
         OvaryState(OvaryT.T3B, OvaryN.N0, OvaryM.M0, P, NO, NO, NO), "IIIB"),
        ("T3c N1b M0 -- macroscopic > 2 cm (IIIC)",
         OvaryState(OvaryT.T3C, OvaryN.N1B, OvaryM.M0, P, NO, NO, NO), "IIIC"),
        ("T1 N0 M1a -- pleural effusion with positive cytology (IVA)",
         OvaryState(OvaryT.T1, OvaryN.N0, OvaryM.M1A, C, NO, NO, NO), "IVA"),
        ("T3c N1 M1b -- liver parenchymal mets (IVB)",
         OvaryState(OvaryT.T3C, OvaryN.N1, OvaryM.M1B, C, NO, NO, NO), "IVB"),
        ("T1 N0 M1 -- M1 parent (IV)",
         OvaryState(OvaryT.T1, OvaryN.N0, OvaryM.M1, C, NO, NO, NO), "IV"),
        ("unstageable: TX with N0 M0",
         OvaryState(OvaryT.TX, OvaryN.N0, OvaryM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
    ),
)
