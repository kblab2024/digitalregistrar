"""Larynx (subglottis) squamous cell carcinoma, AJCC 8.

Source: pdfsource/larynx.pdf. AJCC 8 defines distinct T tables for each
laryngeal subsite (supraglottis, glottis, subglottis) but shares the
N table (ENE-based head/neck N family) and the Stage 0/I/II/III/IVA/
IVB/IVC group table with the other p16- head/neck sites.

A single stage group table applies identically to cTNM, pTNM, and
ypTNM; every CSV rule uses `ANY` for Classification and descriptor
columns.

T leaf categories: TX, Tis, T1, T2, T3, T4a, T4b.

Stage rows summarized (head/neck shared table):
  - Stage 0:   Tis N0 M0
  - Stage I:   T1 N0 M0
  - Stage II:  T2 N0 M0
  - Stage III: T3 N0 M0; T1-T3 N1 M0
  - Stage IVA: T4a N0-N1 M0; T1-T4a N2-family M0
  - Stage IVB: any T N3-family M0; T4b any N M0
  - Stage IVC: any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class LarynxSubglottisT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4A = "T4a"
    T4B = "T4b"


class LarynxSubglottisN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N2C = "N2c"
    N3 = "N3"
    N3A = "N3a"
    N3B = "N3b"


class LarynxSubglottisM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class LarynxSubglottisState(NamedTuple):
    T: LarynxSubglottisT
    N: LarynxSubglottisN
    M: LarynxSubglottisM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="larynx_subglottis",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=LarynxSubglottisState,
    columns={
        "T": LarynxSubglottisT,
        "N": LarynxSubglottisN,
        "M": LarynxSubglottisM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            LarynxSubglottisState(LarynxSubglottisT.TIS, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 -- limited to subglottis (Stage I)",
            LarynxSubglottisState(LarynxSubglottisT.T1, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 -- extension to vocal cord(s) (Stage II)",
            LarynxSubglottisState(LarynxSubglottisT.T2, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- vocal cord fixation (Stage III)",
            LarynxSubglottisState(LarynxSubglottisT.T3, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N1 M0 (Stage III)",
            LarynxSubglottisState(LarynxSubglottisT.T2, LarynxSubglottisN.N1,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T4a N0 M0 -- cricoid/thyroid cartilage invasion (Stage IVA)",
            LarynxSubglottisState(LarynxSubglottisT.T4A, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T3 N2c M0 -- T1-T4a with N2 family (Stage IVA)",
            LarynxSubglottisState(LarynxSubglottisT.T3, LarynxSubglottisN.N2C,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "IVA",
        ),
        (
            "T1 N3a M0 -- any T with N3 family (Stage IVB)",
            LarynxSubglottisState(LarynxSubglottisT.T1, LarynxSubglottisN.N3A,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N0 M0 -- prevertebral / carotid encasement (Stage IVB)",
            LarynxSubglottisState(LarynxSubglottisT.T4B, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, P, NO, NO, NO),
            "IVB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IVC)",
            LarynxSubglottisState(LarynxSubglottisT.T2, LarynxSubglottisN.N1,
                                  LarynxSubglottisM.M1, C, NO, NO, NO),
            "IVC",
        ),
        (
            "ypTNM T2 N1 M0 -- descriptors ignored (still Stage III)",
            LarynxSubglottisState(LarynxSubglottisT.T2, LarynxSubglottisN.N1,
                                  LarynxSubglottisM.M0, P, YES, YES, YES),
            "III",
        ),
        (
            "unstageable: TX has no stage-table entry",
            LarynxSubglottisState(LarynxSubglottisT.TX, LarynxSubglottisN.N0,
                                  LarynxSubglottisM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
