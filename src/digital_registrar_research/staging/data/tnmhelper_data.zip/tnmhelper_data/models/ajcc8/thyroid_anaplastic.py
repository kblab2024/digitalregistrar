"""Thyroid Anaplastic Carcinoma, AJCC 8.

Source: pdfsource/_pages_thyroidv8/. AJCC 8 ships a combined Thyroid
Differentiated and Anaplastic Carcinoma quick reference that defines
shared T/N/M categories (p1-p2) but TWO separate stage group tables.
This module covers the anaplastic variant only (p5). The differentiated
variant lives in a sibling module.

Anaplastic thyroid carcinoma is uniformly Stage IV regardless of age:
all anaplastic disease is treated as advanced. There is no Stage I-III
for this histology.

T leaf categories: TX, T0, T1, T1a, T1b, T2, T3, T3a, T3b, T4, T4a, T4b.
Bare T1 and T3 are parent categories that ALSO appear explicitly in the
anaplastic stage table (the PDF lists "T1, T1a, T1b, T2, T3a" together
on the IVA/IVB rows, and "T4" together on the IVB row), so bare T1, T3,
and T4 ARE stageable here. T0 and TX are NOT in the stage table and
return UNSTAGEABLE.

N category conventions: N0a (cytologically/histologically confirmed
benign) and N0b (no radiologic/clinical evidence) both count as N0 for
stage-grouping purposes -- they share the IVA "N0 or NX" row. N1a / N1b
are subdivisions of N1 (level VI/VII vs lateral neck) and share the IVB
"N1" row.

Stage rows (anaplastic, all ages):
  - IVA: T1/T1a/T1b/T2/T3a with N0/N0a/N0b/NX and M0
  - IVB: T1/T1a/T1b/T2/T3a with N1/N1a/N1b and M0;
         T3b with any N and M0;
         T4/T4a/T4b with any N and M0
  - IVC: any T, any N, M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class ThyroidAnapT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class ThyroidAnapN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N0A = "N0a"
    N0B = "N0b"
    N1 = "N1"
    N1A = "N1a"
    N1B = "N1b"


class ThyroidAnapM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class ThyroidAnapState(NamedTuple):
    T: ThyroidAnapT
    N: ThyroidAnapN
    M: ThyroidAnapM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="thyroid_anaplastic",
    edition=Edition.AJCC_8,
    category="head_neck",
    state_cls=ThyroidAnapState,
    columns={
        "T": ThyroidAnapT,
        "N": ThyroidAnapN,
        "M": ThyroidAnapM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "T1 N0 M0 -- intrathyroidal, no nodes (Stage IVA)",
            ThyroidAnapState(ThyroidAnapT.T1, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "IVA",
        ),
        (
            "T1a N0 M0 -- <= 1 cm, no nodes (Stage IVA)",
            ThyroidAnapState(ThyroidAnapT.T1A, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             P, NO, NO, NO),
            "IVA",
        ),
        (
            "T2 NX M0 -- 2-4 cm, nodes not assessed (Stage IVA)",
            ThyroidAnapState(ThyroidAnapT.T2, ThyroidAnapN.NX, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "IVA",
        ),
        (
            "T3a N0b M0 -- > 4 cm intrathyroidal, radiologic N0 (Stage IVA)",
            ThyroidAnapState(ThyroidAnapT.T3A, ThyroidAnapN.N0B, ThyroidAnapM.M0,
                             P, NO, NO, NO),
            "IVA",
        ),
        (
            "T2 N1a M0 -- 2-4 cm with central-compartment node (Stage IVB)",
            ThyroidAnapState(ThyroidAnapT.T2, ThyroidAnapN.N1A, ThyroidAnapM.M0,
                             P, NO, NO, NO),
            "IVB",
        ),
        (
            "T3a N1b M0 -- > 4 cm intrathyroidal with lateral neck node (Stage IVB)",
            ThyroidAnapState(ThyroidAnapT.T3A, ThyroidAnapN.N1B, ThyroidAnapM.M0,
                             P, NO, NO, NO),
            "IVB",
        ),
        (
            "T3b N0 M0 -- gross ETE into strap muscles, any N is IVB",
            ThyroidAnapState(ThyroidAnapT.T3B, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             P, NO, NO, NO),
            "IVB",
        ),
        (
            "T3b N1b M0 -- strap-muscle ETE with lateral nodes (Stage IVB)",
            ThyroidAnapState(ThyroidAnapT.T3B, ThyroidAnapN.N1B, ThyroidAnapM.M0,
                             P, NO, NO, NO),
            "IVB",
        ),
        (
            "T4a N0 M0 -- gross ETE beyond strap muscles into soft tissue (Stage IVB)",
            ThyroidAnapState(ThyroidAnapT.T4A, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "IVB",
        ),
        (
            "T4b N1b M0 -- prevertebral/carotid encasement with nodes (Stage IVB)",
            ThyroidAnapState(ThyroidAnapT.T4B, ThyroidAnapN.N1B, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "IVB",
        ),
        (
            "T4 N0 M0 -- bare T4 (parent) is listed on the IVB row too",
            ThyroidAnapState(ThyroidAnapT.T4, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "IVB",
        ),
        (
            "Any T any N M1 -- distant metastasis (Stage IVC)",
            ThyroidAnapState(ThyroidAnapT.T1A, ThyroidAnapN.N0, ThyroidAnapM.M1,
                             C, NO, NO, NO),
            "IVC",
        ),
        (
            "T4b N1b M1 -- locally advanced with distant mets (Stage IVC)",
            ThyroidAnapState(ThyroidAnapT.T4B, ThyroidAnapN.N1B, ThyroidAnapM.M1,
                             C, NO, NO, NO),
            "IVC",
        ),
        (
            "unstageable: TX has no stage-table entry",
            ThyroidAnapState(ThyroidAnapT.TX, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "unstageable: T0 (no evidence of primary) not in anaplastic stage table",
            ThyroidAnapState(ThyroidAnapT.T0, ThyroidAnapN.N0, ThyroidAnapM.M0,
                             C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
