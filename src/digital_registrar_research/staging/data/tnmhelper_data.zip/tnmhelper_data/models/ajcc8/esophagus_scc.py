"""Esophageal squamous cell carcinoma, AJCC 8.

Source: pdfsource/esophagus.pdf. Encodes the three AJCC 8 stage group
tables for esophageal SCC:

  - Classification=c                 -> cTNM (Grade and Location ignored)
  - Classification=p AND DescY=No    -> pTNM (Grade matters; Location
                                       matters for T3 N0)
  - Classification=p AND DescY=Yes   -> ypTNM (Grade and Location ignored)

T leaf categories: Tis, T1, T1a, T1b, T2, T3, T4a, T4b. T0 valid in
ypTNM only. Bare T4 is a valid cTNM stage-table key ("T4 any N -> IVA")
but is NOT a leaf in pTNM/ypTNM (those use T4a/T4b only). TX is in the
enum for completeness; states using it return UNSTAGEABLE.

Grade leaves: GX, G1, G2, G3. Location leaves: X, Upper, Middle, Lower.

Notable patterns:
  - SCC pTNM T3 N0 stage assignment depends on BOTH Grade and Location:
      * G1-3 + Lower      -> IIA
      * G1, G2, G3 + Upper or Middle -> IIB
      * GX + any of Lower/Upper/Middle -> IIB
      * any G + Location=X (unknown) -> IIB
  - SCC pTNM T1a stage assignment depends on Grade:
      * G1 / GX -> IA
      * G2 / G3 -> IB
  - SCC pTNM T1b is IB regardless of Grade.
  - T4b, N3, and M1 always map to the same stage across all three
    tables and use ANY for Classification/DescY in rules.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class EsophagusSccT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class EsophagusSccN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N3 = "N3"


class EsophagusSccM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class EsophagusSccGrade(StrEnum):
    GX = "GX"
    G1 = "G1"
    G2 = "G2"
    G3 = "G3"


class EsophagusSccLocation(StrEnum):
    X = "X"
    UPPER = "Upper"
    MIDDLE = "Middle"
    LOWER = "Lower"


class EsophagusSccState(NamedTuple):
    T: EsophagusSccT
    N: EsophagusSccN
    M: EsophagusSccM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo
    Grade: EsophagusSccGrade
    Location: EsophagusSccLocation


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL
GX = EsophagusSccGrade.GX
G1 = EsophagusSccGrade.G1
G2 = EsophagusSccGrade.G2
G3 = EsophagusSccGrade.G3
LX = EsophagusSccLocation.X
LU = EsophagusSccLocation.UPPER
LM = EsophagusSccLocation.MIDDLE
LL = EsophagusSccLocation.LOWER

MODEL = StagingModel(
    name="esophagus_scc",
    edition=Edition.AJCC_8,
    category="gi",
    state_cls=EsophagusSccState,
    columns={
        "T": EsophagusSccT,
        "N": EsophagusSccN,
        "M": EsophagusSccM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
        "Grade": EsophagusSccGrade,
        "Location": EsophagusSccLocation,
    },
    examples=(
        # --- cTNM (Grade & Location ignored) ---
        ("cTNM Tis N0 M0 (0)",
         EsophagusSccState(EsophagusSccT.TIS, EsophagusSccN.N0, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "0"),
        ("cTNM T1a N1 M0 -- T1 family with N0-N1 (I)",
         EsophagusSccState(EsophagusSccT.T1A, EsophagusSccN.N1, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "I"),
        ("cTNM T2 N1 M0 (II)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N1, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "II"),
        ("cTNM T3 N0 M0 (II)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N0, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "II"),
        ("cTNM T3 N1 M0 (III)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N1, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "III"),
        ("cTNM T2 N2 M0 -- T1-T3 with N2 (III)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N2, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "III"),
        ("cTNM T4 N0 M0 -- bare T4 valid in cTNM (IVA)",
         EsophagusSccState(EsophagusSccT.T4, EsophagusSccN.N0, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "IVA"),
        ("cTNM T4a N2 M0 (IVA)",
         EsophagusSccState(EsophagusSccT.T4A, EsophagusSccN.N2, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "IVA"),
        ("cTNM T1 N3 M0 (IVA)",
         EsophagusSccState(EsophagusSccT.T1, EsophagusSccN.N3, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "IVA"),
        ("cTNM T1 N0 M1 (IVB)",
         EsophagusSccState(EsophagusSccT.T1, EsophagusSccN.N0, EsophagusSccM.M1,
                           C, NO, NO, NO, GX, LX), "IVB"),
        # --- pTNM (Grade matters; Location matters for T3 N0) ---
        ("pTNM Tis N0 M0 (0)",
         EsophagusSccState(EsophagusSccT.TIS, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LX), "0"),
        ("pTNM T1a N0 M0 G1 (IA)",
         EsophagusSccState(EsophagusSccT.T1A, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G1, LL), "IA"),
        ("pTNM T1a N0 M0 GX (IA)",
         EsophagusSccState(EsophagusSccT.T1A, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LL), "IA"),
        ("pTNM T1a N0 M0 G3 (IB)",
         EsophagusSccState(EsophagusSccT.T1A, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G3, LL), "IB"),
        ("pTNM T1b N0 M0 G2 (IB)",
         EsophagusSccState(EsophagusSccT.T1B, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G2, LM), "IB"),
        ("pTNM T2 N0 M0 G2 (IIA)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G2, LU), "IIA"),
        ("pTNM T2 N0 M0 G1 (IIB)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G1, LL), "IIB"),
        ("pTNM T3 N0 M0 G2 Lower (IIA)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G2, LL), "IIA"),
        ("pTNM T3 N0 M0 G2 Upper (IIB)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G2, LU), "IIB"),
        ("pTNM T3 N0 M0 GX Lower (IIB)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LL), "IIB"),
        ("pTNM T3 N0 M0 G1 X (IIB)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G1, LX), "IIB"),
        ("pTNM T1 N1 M0 -- any G IIB",
         EsophagusSccState(EsophagusSccT.T1, EsophagusSccN.N1, EsophagusSccM.M0,
                           P, NO, NO, NO, G1, LL), "IIB"),
        ("pTNM T2 N1 M0 (IIIA)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N1, EsophagusSccM.M0,
                           P, NO, NO, NO, G2, LM), "IIIA"),
        ("pTNM T4a N0 M0 (IIIB)",
         EsophagusSccState(EsophagusSccT.T4A, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LX), "IIIB"),
        ("pTNM T4a N2 M0 (IVA)",
         EsophagusSccState(EsophagusSccT.T4A, EsophagusSccN.N2, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LX), "IVA"),
        ("pTNM T4b N0 M0 (IVA)",
         EsophagusSccState(EsophagusSccT.T4B, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LX), "IVA"),
        ("pTNM T1 N3 M0 (IVA)",
         EsophagusSccState(EsophagusSccT.T1, EsophagusSccN.N3, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LX), "IVA"),
        ("pTNM T1 N0 M1 (IVB)",
         EsophagusSccState(EsophagusSccT.T1A, EsophagusSccN.N0, EsophagusSccM.M1,
                           P, NO, NO, NO, G1, LL), "IVB"),
        # --- ypTNM ---
        ("ypTNM T0 N0 M0 (I)",
         EsophagusSccState(EsophagusSccT.T0, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, YES, NO, NO, GX, LX), "I"),
        ("ypTNM T2 N0 M0 (I)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, YES, NO, NO, GX, LX), "I"),
        ("ypTNM T3 N0 M0 (II)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, YES, NO, NO, GX, LX), "II"),
        ("ypTNM T2 N1 M0 (IIIA)",
         EsophagusSccState(EsophagusSccT.T2, EsophagusSccN.N1, EsophagusSccM.M0,
                           P, YES, NO, NO, GX, LX), "IIIA"),
        ("ypTNM T3 N1 M0 (IIIB)",
         EsophagusSccState(EsophagusSccT.T3, EsophagusSccN.N1, EsophagusSccM.M0,
                           P, YES, NO, NO, GX, LX), "IIIB"),
        ("ypTNM T4a NX M0 -- T4a NX special case (IVA)",
         EsophagusSccState(EsophagusSccT.T4A, EsophagusSccN.NX, EsophagusSccM.M0,
                           P, YES, NO, NO, GX, LX), "IVA"),
        ("ypTNM any T any N M1 (IVB)",
         EsophagusSccState(EsophagusSccT.T1, EsophagusSccN.N0, EsophagusSccM.M1,
                           P, YES, NO, NO, GX, LX), "IVB"),
        # --- failures ---
        ("unstageable: pTNM bare T4 has no entry",
         EsophagusSccState(EsophagusSccT.T4, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, GX, LX), "UNSTAGEABLE"),
        ("unstageable: pTNM bare T1 N0 not in stage table",
         EsophagusSccState(EsophagusSccT.T1, EsophagusSccN.N0, EsophagusSccM.M0,
                           P, NO, NO, NO, G1, LL), "UNSTAGEABLE"),
        ("unstageable: TX",
         EsophagusSccState(EsophagusSccT.TX, EsophagusSccN.N0, EsophagusSccM.M0,
                           C, NO, NO, NO, GX, LX), "UNSTAGEABLE"),
    ),
)
