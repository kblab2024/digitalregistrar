# `models/` — staging-model contract

Each `*.py` file under `models/<edition_slug>/` (other than those
starting with `_`) is auto-discovered by
[models/__init__.py](__init__.py) and registered in `MODEL_REGISTRY`
if it exposes a module-level `MODEL` of type `StagingModel`. The
registry is keyed by the tuple `(MODEL.name, MODEL.edition)`. This
document is the exact contract a new model file must satisfy. It is
terse on purpose so an LLM can generate a new file from this spec
alone.

## Layout

```
models/
  _shared.py                        (shared types: Biomarker, Edition, StagingModel, ...)
  ajcc8/
    __init__.py                     (empty; marks edition as a subpackage)
    breast.py                       (MODEL = StagingModel(name="breast", edition=Edition.AJCC_8, ...))
    colon.py
    stomach.py
  ajcc9/
    __init__.py
    lung.py
```

The parent directory name (`ajcc8`, `ajcc9`) MUST equal
`MODEL.edition_slug` (the lowercased no-space form of
`MODEL.edition.value`). The discovery walker hard-fails otherwise.

## Contract

A model module MUST:

1. Define a module-level constant `MODEL: StagingModel`.
2. Have a filename stem equal to `MODEL.name` (e.g.
   `ajcc8/breast.py` → `MODEL.name == "breast"`).
3. Live in a directory whose name equals `MODEL.edition_slug` (e.g.
   `MODEL.edition == Edition.AJCC_8` → parent dir `ajcc8`).
4. Not start its filename with an underscore (skipped by discovery).

A model module SHOULD:

- Define one `StrEnum` per TNM axis (T, N, M) and any organ-specific
  extras (e.g. Grade, ER/PR/HER2 via the shared `Biomarker` enum).
- Use `ALL_CAPS` enum member names (PEP 8). Preserve the
  case-sensitive AJCC literal in the `.value` string:
  `TIS = "Tis"`, `T1MI = "T1mi"`, `M1A = "M1a"`. The value is what
  lands in CSV cells; the member name is just the Python attribute.
- Define a `NamedTuple` whose fields, in order, match the columns of
  the source CSV.
- Define its OWN enum classes (do NOT import from a sibling edition's
  module). AJCC editions can add, remove, or rename TNM categories,
  so the same `BreastT` name in `ajcc8/breast.py` and a future
  `ajcc9/breast.py` are independent classes.

A model module MUST NOT:

- Import from sibling model modules (`from ..ajcc8.breast import ...`
  is forbidden; share via `_shared.py` instead).
- Run module-level side effects (I/O, network, mutation of registries).
- Re-register a `(name, edition)` pair already present in
  `MODEL_REGISTRY` (raises at import).

## `StagingModel` fields

Defined in [_shared.py](_shared.py). Frozen dataclass.

| Field | Type | Meaning | Constraint |
|-------|------|---------|------------|
| `name` | `str` | Organ identifier | Equals module filename stem; lowercase by convention |
| `edition` | `Edition` | AJCC edition | Equals the parent directory in slug form; coerced from `str` in `__post_init__` |
| `category` | `str` | Body-system grouping for the GUI sidebar | Non-empty; SHOULD be in `KNOWN_CATEGORIES` (build_pipeline soft-warns otherwise) |
| `state_cls` | `type[NamedTuple]` | The typed lookup key | Fields are all `StrEnum` subclasses |
| `columns` | `dict[str, type[StrEnum]]` | Per-column enum class | `tuple(columns) == state_cls._fields` (asserted in `__post_init__`) |
| `examples` | `tuple[tuple[str, NamedTuple, str], ...]` | Optional smoke tests | Each entry is `(label, state, expected_stage)`; `main.py` runs them |

`KNOWN_CATEGORIES` (defined in `_shared.py`): `breast`, `thoracic`,
`head_neck`, `gi`, `hepatobiliary`, `gyn`, `urologic`. Add a new
category only when a new body system genuinely lacks a home; prefer
reusing an existing one to keep the GUI sidebar stable.

Derived (do not set explicitly):

| Property | Returns | Notes |
|----------|---------|-------|
| `edition_slug` | `str` | `"AJCC 8" -> "ajcc8"` |
| `csv_path` | `str` | `"ajcc8/breast_rules_human.csv"`, relative to `data/` root |

## CSV contract

`data/<edition_slug>/{name}_rules_human.csv` MUST:

- Have a header row equal to `list(MODEL.columns) + ["Stage"]` in
  that exact order.
- Have one row per rule.
- Use enum literals (the `.value` of each `StrEnum` member) or the
  literal string `"ANY"` as a wildcard. An empty CSV cell is valid
  only if the column's `StrEnum` declares `""` as a member value;
  otherwise the build aborts with the enum's "valid values" message.
- Have a non-empty `Stage` cell on every row. `Stage` is a free
  string (e.g. `"IA"`, `"IIIB"`, `"IV"`).

Specificity (count of non-`ANY` cells) is the conflict-resolution
key. Two rules with the same specificity that map the same state to
different stages cause `build_pipeline.py` to abort.

## Worked example

Full content of [ajcc9/lung.py](ajcc9/lung.py), trimmed:

```python
from enum import StrEnum
from typing import NamedTuple

from .._shared import Classification, Edition, StagingModel, YesNo


# Enum MEMBER NAMES are ALL_CAPS (PEP 8). The .value strings preserve the
# case-sensitive AJCC literal ("Tis", "T1mi", "M1a") — these are what land
# in CSV cells.
class LungT(StrEnum):
    TX = "TX"; T0 = "T0"; TIS = "Tis"
    T1MI = "T1mi"; T1 = "T1"; T1A = "T1a"; T1B = "T1b"; T1C = "T1c"
    T2 = "T2"; T2A = "T2a"; T2B = "T2b"
    T3 = "T3"; T4 = "T4"


class LungN(StrEnum):
    NX = "NX"; N0 = "N0"; N1 = "N1"
    N2 = "N2"; N2A = "N2a"; N2B = "N2b"; N3 = "N3"


class LungM(StrEnum):
    M0 = "M0"; M1 = "M1"; M1A = "M1a"; M1B = "M1b"; M1C = "M1c"
    M1C1 = "M1c1"; M1C2 = "M1c2"


class LungState(NamedTuple):    # field order MUST match MODEL.columns order
    T: LungT
    N: LungN
    M: LungM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


MODEL = StagingModel(
    name="lung",                                  # MUST equal filename stem
    edition=Edition.AJCC_9,                       # MUST match parent dir as slug
    state_cls=LungState,
    columns={"T": LungT, "N": LungN, "M": LungM,
             "Classification": Classification,
             "DescY": YesNo, "DescR": YesNo, "DescM": YesNo},
    examples=(
        ("T1a N0 M0 -> IA1",
         LungState(LungT.T1A, LungN.N0, LungM.M0,
                   Classification.CLINICAL, YesNo.NO, YesNo.NO, YesNo.NO),
         "IA1"),
    ),
)
```

The matching `data/ajcc9/lung_rules_human.csv` header:

```csv
T,N,M,Classification,DescY,DescR,DescM,Stage
```

## Observation → TNM derivation (`derivations/<edition>/<organ>.json`)

In addition to the model + CSV + criteria files, every registered
`(organ, edition)` SHOULD ship a derivations JSON declaring how to
compute T/N/M from clinical observations. See
[../derivations/README.md](../derivations/README.md) for the schema
and authoring guide. `build_pipeline.py` hard-fails if a derivation
file is missing for any registered model.

## Shared types

Use these from `_shared.py` instead of redefining:

- `Biomarker` (`Positive`, `Negative`, `Equivocal`, `Unknown`) — for any IHC/molecular axis.
- `YesNo` (`Yes`, `No`) — for descriptor flags.
- `Classification` (`a`/`c`/`p`) — anatomic / clinical / pathological.
- `Edition` (`"AJCC 7"`, `"AJCC 8"`, `"AJCC 9"`) — AJCC manual edition.
- `StagingModel` — the dataclass above.

## Things that will fail loudly at import or build

- `MODEL.name != filename_stem` → `ValueError` from `models/__init__.py`.
- `MODEL.edition_slug != parent_dirname` → `ValueError` from `models/__init__.py`.
- `MODEL.edition` is not a known `Edition` value → `ValueError` from `_post_init__`.
- Duplicate `(name, edition)` across files → `ValueError`.
- `columns.keys()` not equal to `state_cls._fields` in order → `ValueError` from `StagingModel.__post_init__`.
- CSV header missing a required column or carrying extras → `ValueError` from `build_pipeline.py`.
- CSV cell with a value not in the column's `StrEnum` → `ValueError` naming the row.
- Missing `criteria/<edition_slug>/<name>.json`, or its `edition` field disagreeing with `MODEL.edition` → `FileNotFoundError` / `ValueError` from `build_pipeline.py`.
- Equal-specificity rules disagreeing on `Stage` → `ConflictError` (raised by `build_pipeline.py` lint).
