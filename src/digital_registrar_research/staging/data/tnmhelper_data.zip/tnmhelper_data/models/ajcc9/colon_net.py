"""Neuroendocrine Tumors of the Colon and Rectum -- AJCC 9 staging.

Source: pdfsource/colonnetv9.pdf. State shape parallels lung/colon:

- **Classification** (`c` / `p`): how the assessment was made.
  - `c` (Clinical)     -- pre-treatment, imaging/biopsy based
  - `p` (Pathological) -- based on the resected specimen with microscopic
                          confirmation
- **Descriptors** (independent Yes/No flags): `DescY`, `DescR`, `DescM`.

For colorectal NET, the AJCC 9 PDF defines a SINGLE stage group table
applying identically to cTNM, pTNM, and ypTNM. Every rule in the CSV
therefore uses `ANY` for Classification and the three descriptor
columns.

T-family conventions used in the PDF stage table:
  - T1 in the stage table covers all T1-family members: T1, T1a, T1b
    (T1 is defined as <=2 cm; T1a is <=1 cm, T1b is >1 cm but <=2 cm).
  - T2/T3/T4 have no subcategories in colorectal NET.

N-family conventions:
  - Colorectal NET has only NX, N0, N1 -- no sub-letters.

M-family conventions (suffix only; the c/p prefix lives in
Classification):
  - cM0, cM1, cM1a/b/c and pM1, pM1a/b/c collapse to M0, M1, M1a, M1b,
    M1c here. M1a = liver-confined; M1b = extrahepatic only;
    M1c = both hepatic and extrahepatic.
  - The stage table's "M1" row covers the whole M1 family (M1, M1a,
    M1b, M1c) -- all map to Stage IV.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class ColonNetT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class ColonNetN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class ColonNetM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"


class ColonNetState(NamedTuple):
    T: ColonNetT
    N: ColonNetN
    M: ColonNetM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="colon_net",
    edition=Edition.AJCC_9,
    category="gi",
    state_cls=ColonNetState,
    columns={
        "T": ColonNetT,
        "N": ColonNetN,
        "M": ColonNetM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "T1 N0 M0 -- tumor <=2 cm, no nodes (Stage I)",
            ColonNetState(ColonNetT.T1, ColonNetN.N0, ColonNetM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T1a N0 M0 -- <=1 cm (Stage I)",
            ColonNetState(ColonNetT.T1A, ColonNetN.N0, ColonNetM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T1b NX M0 -- >1 cm but <=2 cm with NX (still Stage I)",
            ColonNetState(ColonNetT.T1B, ColonNetN.NX, ColonNetM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 -- muscularis propria or >2 cm (Stage IIA)",
            ColonNetState(ColonNetT.T2, ColonNetN.N0, ColonNetM.M0, C, NO, NO, NO),
            "IIA",
        ),
        (
            "T3 N0 M0 -- through muscularis propria into subserosa (Stage IIB)",
            ColonNetState(ColonNetT.T3, ColonNetN.N0, ColonNetM.M0, C, NO, NO, NO),
            "IIB",
        ),
        (
            "T4 N0 M0 -- visceral peritoneum or adjacent organs (Stage IIIA)",
            ColonNetState(ColonNetT.T4, ColonNetN.N0, ColonNetM.M0, C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T2 N1 M0 -- any T with regional nodes (Stage IIIB)",
            ColonNetState(ColonNetT.T2, ColonNetN.N1, ColonNetM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T1a N1 M0 -- T1 family with N1 (Stage IIIB)",
            ColonNetState(ColonNetT.T1A, ColonNetN.N1, ColonNetM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T3 N1 M1a -- liver-confined metastasis (Stage IV)",
            ColonNetState(ColonNetT.T3, ColonNetN.N1, ColonNetM.M1A, C, NO, NO, NO),
            "IV",
        ),
        (
            "M1b -- extrahepatic only (Stage IV)",
            ColonNetState(ColonNetT.T4, ColonNetN.N1, ColonNetM.M1B, C, NO, NO, NO),
            "IV",
        ),
        (
            "M1c -- both hepatic and extrahepatic (Stage IV)",
            ColonNetState(ColonNetT.T4, ColonNetN.N1, ColonNetM.M1C, C, NO, NO, NO),
            "IV",
        ),
        (
            "bare M1 -- still Stage IV (PDF: 'Any T Any N M1 -> IV')",
            ColonNetState(ColonNetT.T2, ColonNetN.N0, ColonNetM.M1, C, NO, NO, NO),
            "IV",
        ),
        (
            "pTNM T1 N0 -- same stage as cTNM (table is shared)",
            ColonNetState(ColonNetT.T1, ColonNetN.N0, ColonNetM.M0, P, NO, NO, NO),
            "I",
        ),
        (
            "ypTNM T2 N1 -- descriptors ignored (still IIIB)",
            ColonNetState(ColonNetT.T2, ColonNetN.N1, ColonNetM.M0, P, YES, NO, NO),
            "IIIB",
        ),
        (
            "unstageable: TX N0 M0 -- PDF does not stage TX with M0",
            ColonNetState(ColonNetT.TX, ColonNetN.N0, ColonNetM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "unstageable: T1 NX M1 still Stage IV (M1 dominates)",
            ColonNetState(ColonNetT.T1, ColonNetN.NX, ColonNetM.M1, C, NO, NO, NO),
            "IV",
        ),
    ),
)
