"""Salivary glands (major) AJCC 9 staging.

Source: pdfsource/_pages_salivaryv9/p1-p5.png (AJCC 9 Major Salivary
Gland Carcinoma Quick Reference).

State shape parallels lung/oral_cavity:

- **Classification** (`c` / `p`): how the assessment was made.
  - `c` (Clinical)     -- pre-treatment, imaging/biopsy based
  - `p` (Pathological) -- based on the resected specimen with microscopic
                          confirmation
- **Descriptors** (independent Yes/No flags): `DescY`, `DescR`, `DescM`.

For major salivary AJCC 9 the PDF defines a SINGLE stage group table
that applies identically to cTNM, pTNM, and ypTNM. Every rule in the
CSV therefore uses `ANY` for Classification and the three descriptor
columns -- the stage outcome does not depend on them. The fields are
still part of state for clinical record-keeping and to keep the
GUI/data-entry shape consistent across organs.

T categories (AJCC 9 simplification): TX, Tis, T1, T2, T3, T4, T4a,
T4b.
  - T1: tumor <= 2 cm without extraparenchymal extension
  - T2: > 2 cm but <= 4 cm without extraparenchymal extension
  - T3: > 4 cm and/or gross extraparenchymal extension
  - T4: parent category for T4a/T4b (invades adjacent or beyond)
  - T4a: invades skin / bone / cartilage / solid organ parenchyma /
         esophagus / trachea / named nerve
  - T4b: invades carotid encasement / skull base / spinal column /
         intracranial / orbital apex / prevertebral / mediastinal /
         masticator space

N categories (AJCC 9 simplified -- no N3; ENE folded into N1/N2):
  - NX: cannot be assessed
  - N0:  no involvement
  - N1:  1-3 nodes without ENE (clinical: "unequivocal imaging-detected
         and/or clinical extranodal extension" is the ENE criterion;
         pathological: "definitive pathological extranodal extension")
  - N2:  > 3 nodes, OR any node with ENE

M categories: M0 / M1 (the PDF lists cM0, cM1, pM1; the suffix-level
value stored here does not include the c/p prefix, which lives in
Classification).

Stage rows (from PDF p5):
  - 0:    Tis N0 M0
  - I:    T1  N0 M0
  - II:   T2  N0 M0
  - IIIA: T1-T2 N1 M0; T3-T4 N0 M0
  - IIIB: T1-T2 N2 M0; T3-T4 N1-N2 M0
  - IV:   Any T Any N M1

Bare T4 (parent grouping) is included in the "T3-T4" rows: the CSV
expands every T4-family literal so the build pipeline can match by
literal equality.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class SalivaryT(StrEnum):
    TX = "TX"
    TIS = "Tis"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class SalivaryN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"


class SalivaryM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class SalivaryState(NamedTuple):
    T: SalivaryT
    N: SalivaryN
    M: SalivaryM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="salivary",
    edition=Edition.AJCC_9,
    category="head_neck",
    state_cls=SalivaryState,
    columns={
        "T": SalivaryT,
        "N": SalivaryN,
        "M": SalivaryM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "in-situ disease (Stage 0)",
            SalivaryState(SalivaryT.TIS, SalivaryN.N0, SalivaryM.M0,
                          C, NO, NO, NO),
            "0",
        ),
        (
            "T1 N0 M0 (Stage I)",
            SalivaryState(SalivaryT.T1, SalivaryN.N0, SalivaryM.M0,
                          C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 (Stage II)",
            SalivaryState(SalivaryT.T2, SalivaryN.N0, SalivaryM.M0,
                          C, NO, NO, NO),
            "II",
        ),
        (
            "T1 N1 M0 -- T1-T2 with N1 (Stage IIIA)",
            SalivaryState(SalivaryT.T1, SalivaryN.N1, SalivaryM.M0,
                          P, NO, NO, NO),
            "IIIA",
        ),
        (
            "T3 N0 M0 -- T3-T4 with N0 (Stage IIIA)",
            SalivaryState(SalivaryT.T3, SalivaryN.N0, SalivaryM.M0,
                          C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T4a N0 M0 -- T3-T4 with N0 (Stage IIIA)",
            SalivaryState(SalivaryT.T4A, SalivaryN.N0, SalivaryM.M0,
                          P, NO, NO, NO),
            "IIIA",
        ),
        (
            "T2 N2 M0 -- T1-T2 with N2 (Stage IIIB)",
            SalivaryState(SalivaryT.T2, SalivaryN.N2, SalivaryM.M0,
                          P, NO, NO, NO),
            "IIIB",
        ),
        (
            "T3 N1 M0 -- T3-T4 with N1-N2 (Stage IIIB)",
            SalivaryState(SalivaryT.T3, SalivaryN.N1, SalivaryM.M0,
                          C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T4b N2 M0 -- T3-T4 with N1-N2 (Stage IIIB)",
            SalivaryState(SalivaryT.T4B, SalivaryN.N2, SalivaryM.M0,
                          P, NO, NO, NO),
            "IIIB",
        ),
        (
            "T4 N1 M0 -- bare T4 still in the T3-T4 row (Stage IIIB)",
            SalivaryState(SalivaryT.T4, SalivaryN.N1, SalivaryM.M0,
                          C, NO, NO, NO),
            "IIIB",
        ),
        (
            "any T any N M1 -- distant metastasis (Stage IV)",
            SalivaryState(SalivaryT.T2, SalivaryN.N1, SalivaryM.M1,
                          C, NO, NO, NO),
            "IV",
        ),
        (
            "ypTNM T2 N0 M0 -- descriptors ignored for salivary (still II)",
            SalivaryState(SalivaryT.T2, SalivaryN.N0, SalivaryM.M0,
                          P, YES, YES, YES),
            "II",
        ),
        (
            "unstageable: TX with N0 M0 has no stage-table entry",
            SalivaryState(SalivaryT.TX, SalivaryN.N0, SalivaryM.M0,
                          C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "T1 NX M0 -- NX aliased to N0 in engine -> I",
            SalivaryState(SalivaryT.T1, SalivaryN.NX, SalivaryM.M0,
                          C, NO, NO, NO),
            "I",
        ),
    ),
)
