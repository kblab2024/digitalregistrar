"""Gastric Neuroendocrine Tumors (NET), AJCC 9.

Source: pdfsource/stomachnetv9.pdf. Single stage table; the AJCC 9
manual does not distinguish cTNM, pTNM, or ypTNM stage groupings for
gastric NET, so every CSV rule uses `ANY` for Classification and
descriptors.

T family (depth of invasion + size):
  - TX  -- cannot be assessed
  - T0  -- no evidence
  - T1  -- mucosa or submucosa AND <= 1 cm
  - T2  -- muscularis propria OR > 1 cm
  - T3  -- through muscularis propria into subserosa (no serosa)
  - T4  -- visceral peritoneum (serosa) or adjacent organs

N family:
  - NX, N0, N1 (any regional lymph node involvement)

M family (cM/pM split with substages a/b/c):
  - M0
  - cM1 / cM1a / cM1b / cM1c
  - pM1 / pM1a / pM1b / pM1c
    a = liver-only, b = >= 1 extrahepatic site, c = both hepatic and
    extrahepatic. Any M1* maps to Stage IV.

Stage Group Table (PDF p3):
  T1   + NX or N0 + M0 -> I
  T2/T3 + N0       + M0 -> II
  T4    + N0       + M0 -> III
  Any T + N1       + M0 -> III
  Any T + Any N    + M1 -> IV
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class StomachNetT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class StomachNetN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class StomachNetM(StrEnum):
    M0 = "M0"
    CM1 = "cM1"
    CM1A = "cM1a"
    CM1B = "cM1b"
    CM1C = "cM1c"
    PM1 = "pM1"
    PM1A = "pM1a"
    PM1B = "pM1b"
    PM1C = "pM1c"


class StomachNetState(NamedTuple):
    T: StomachNetT
    N: StomachNetN
    M: StomachNetM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="stomach_net",
    edition=Edition.AJCC_9,
    category="gi",
    state_cls=StomachNetState,
    columns={
        "T": StomachNetT,
        "N": StomachNetN,
        "M": StomachNetM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("T1 N0 M0 -- mucosa/submucosa <= 1 cm (I)",
         StomachNetState(StomachNetT.T1, StomachNetN.N0, StomachNetM.M0,
                         C, NO, NO, NO), "I"),
        ("T1 NX M0 -- NX allowed at T1 (I)",
         StomachNetState(StomachNetT.T1, StomachNetN.NX, StomachNetM.M0,
                         C, NO, NO, NO), "I"),
        ("T2 N0 M0 -- muscularis propria or > 1 cm (II)",
         StomachNetState(StomachNetT.T2, StomachNetN.N0, StomachNetM.M0,
                         P, NO, NO, NO), "II"),
        ("T3 N0 M0 -- subserosa (II)",
         StomachNetState(StomachNetT.T3, StomachNetN.N0, StomachNetM.M0,
                         P, NO, NO, NO), "II"),
        ("T4 N0 M0 -- serosa or adjacent organs (III)",
         StomachNetState(StomachNetT.T4, StomachNetN.N0, StomachNetM.M0,
                         P, NO, NO, NO), "III"),
        ("T2 N1 M0 -- regional node involvement (III)",
         StomachNetState(StomachNetT.T2, StomachNetN.N1, StomachNetM.M0,
                         P, NO, NO, NO), "III"),
        ("T1 N1 M0 -- N1 elevates T1 to III",
         StomachNetState(StomachNetT.T1, StomachNetN.N1, StomachNetM.M0,
                         P, NO, NO, NO), "III"),
        ("T1 N0 cM1a -- liver-only distant mets (IV)",
         StomachNetState(StomachNetT.T1, StomachNetN.N0, StomachNetM.CM1A,
                         C, NO, NO, NO), "IV"),
        ("T4 N1 pM1c -- hepatic + extrahepatic (IV)",
         StomachNetState(StomachNetT.T4, StomachNetN.N1, StomachNetM.PM1C,
                         P, NO, NO, NO), "IV"),
        ("T2 N0 cM1 -- unspecified distant mets (IV)",
         StomachNetState(StomachNetT.T2, StomachNetN.N0, StomachNetM.CM1,
                         C, NO, NO, NO), "IV"),
        ("synchronous primaries, T2 N1 M0 (III)",
         StomachNetState(StomachNetT.T2, StomachNetN.N1, StomachNetM.M0,
                         P, NO, NO, YES), "III"),
        ("post-neoadjuvant ypTNM: T3 N0 M0 (II)",
         StomachNetState(StomachNetT.T3, StomachNetN.N0, StomachNetM.M0,
                         P, YES, NO, NO), "II"),
        ("unstageable: TX with N0 M0",
         StomachNetState(StomachNetT.TX, StomachNetN.N0, StomachNetM.M0,
                         C, NO, NO, NO), "UNSTAGEABLE"),
        ("T2 NX M0 -- NX aliased to N0 in engine -> II",
         StomachNetState(StomachNetT.T2, StomachNetN.NX, StomachNetM.M0,
                         C, NO, NO, NO), "II"),
    ),
)
