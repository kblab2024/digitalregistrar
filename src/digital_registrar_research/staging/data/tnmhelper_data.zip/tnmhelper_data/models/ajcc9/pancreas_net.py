"""Pancreas neuroendocrine tumor (pNET), AJCC 9.

Source: pdfsource/_pages_pnetv9/. Covers well-differentiated pancreatic
neuroendocrine tumors. Distinct from exocrine pancreatic adenocarcinoma
(see ajcc8/pancreas.py).

T categories (AJCC 9 pNET):
  - TX: cannot be assessed
  - T1: limited to the pancreas, <= 2 cm
  - T2: limited to the pancreas, > 2 cm and <= 4 cm
  - T3: limited to the pancreas, > 4 cm; OR tumor invading the duodenum,
        ampulla of Vater, or common bile duct
  - T4: tumor invading adjacent organs (stomach, spleen, colon, adrenal
        gland) or the wall of large vessels (celiac axis, SMA/SMV,
        splenic artery/vein, gastroduodenal artery/vein, portal vein)

N categories:
  - NX: cannot be assessed
  - N0: no regional lymph node involvement
  - N1: tumor involvement of regional lymph node(s)

M categories:
  - M0: no distant metastasis
  - M1: distant metastasis (parent)
  - M1a: metastasis confined to liver
  - M1b: metastases in at least one extrahepatic site (e.g., lung,
         ovary, nonregional lymph node, peritoneum, bone)
  - M1c: both hepatic and extrahepatic metastases

Stage Group Table (from PDF):
  - T1 N0 M0      -> I
  - T2, T3 N0 M0  -> II
  - T4 N0 M0      -> III
  - Any T N1 M0   -> III
  - Any T Any N M1 -> IV  (M1, M1a, M1b, M1c all collapse to IV)

Bare M1 (parent) is allowed because M1/M1a/M1b/M1c all map to IV.
DescY/DescR/DescM and Classification (c/p) do not affect the stage
outcome -- recorded for context, ANY in every CSV rule.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class PancreasNetT(StrEnum):
    TX = "TX"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class PancreasNetN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class PancreasNetM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"


class PancreasNetState(NamedTuple):
    T: PancreasNetT
    N: PancreasNetN
    M: PancreasNetM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="pancreas_net",
    edition=Edition.AJCC_9,
    category="hepatobiliary",
    state_cls=PancreasNetState,
    columns={
        "T": PancreasNetT,
        "N": PancreasNetN,
        "M": PancreasNetM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "T1 N0 M0 -- <= 2 cm, intra-pancreatic (Stage I)",
            PancreasNetState(PancreasNetT.T1, PancreasNetN.N0, PancreasNetM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 -- 2-4 cm, intra-pancreatic (Stage II)",
            PancreasNetState(PancreasNetT.T2, PancreasNetN.N0, PancreasNetM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- > 4 cm or invades duodenum/ampulla/CBD (Stage II)",
            PancreasNetState(PancreasNetT.T3, PancreasNetN.N0, PancreasNetM.M0, P, NO, NO, NO),
            "II",
        ),
        (
            "T4 N0 M0 -- invades adjacent organs / major vessels (Stage III)",
            PancreasNetState(PancreasNetT.T4, PancreasNetN.N0, PancreasNetM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N1 M0 -- any T with regional nodes (Stage III)",
            PancreasNetState(PancreasNetT.T2, PancreasNetN.N1, PancreasNetM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T1 N1 M0 -- N1 trumps T (Stage III)",
            PancreasNetState(PancreasNetT.T1, PancreasNetN.N1, PancreasNetM.M0, C, NO, NO, NO),
            "III",
        ),
        (
            "T4 N1 M0 -- T4 + N1 still III",
            PancreasNetState(PancreasNetT.T4, PancreasNetN.N1, PancreasNetM.M0, P, NO, NO, NO),
            "III",
        ),
        (
            "T2 N0 M1a -- liver-only mets (Stage IV)",
            PancreasNetState(PancreasNetT.T2, PancreasNetN.N0, PancreasNetM.M1A, C, NO, NO, NO),
            "IV",
        ),
        (
            "T1 N0 M1b -- extrahepatic mets only (Stage IV)",
            PancreasNetState(PancreasNetT.T1, PancreasNetN.N0, PancreasNetM.M1B, C, NO, NO, NO),
            "IV",
        ),
        (
            "T3 N1 M1c -- hepatic + extrahepatic mets (Stage IV)",
            PancreasNetState(PancreasNetT.T3, PancreasNetN.N1, PancreasNetM.M1C, C, NO, NO, NO),
            "IV",
        ),
        (
            "T2 N0 M1 -- bare M1 parent still IV",
            PancreasNetState(PancreasNetT.T2, PancreasNetN.N0, PancreasNetM.M1, C, NO, NO, NO),
            "IV",
        ),
        (
            "ypTNM descriptors do not affect outcome",
            PancreasNetState(PancreasNetT.T1, PancreasNetN.N0, PancreasNetM.M0, P, YES, YES, YES),
            "I",
        ),
        (
            "unstageable: TX (no T1-T4 assignable)",
            PancreasNetState(PancreasNetT.TX, PancreasNetN.N0, PancreasNetM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
