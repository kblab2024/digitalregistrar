"""Lung AJCC 9 staging.

Source: pdfsource/lung.pdf. State shape parallels stomach:

- **Classification** (`c` / `p`): how the assessment was made.
  - `c` (Clinical)     -- pre-treatment, imaging/biopsy based
  - `p` (Pathological) -- based on the resected specimen with microscopic
                          confirmation
- **Descriptors** (independent Yes/No flags): `DescY`, `DescR`, `DescM`.

For lung, the AJCC 9 PDF defines a SINGLE stage group table that applies
identically to cTNM, pTNM, and ypTNM. Every rule in the CSV therefore
uses `ANY` for Classification and the three descriptor columns -- the
stage outcome does not depend on them. The fields are still part of
state for clinical record-keeping and to keep the GUI/data-entry shape
consistent across organs.

T-family conventions used in the PDF stage table:
  - "T1" alone means any T1-family member: T1, T1mi, T1a, T1b, T1c.
  - "T2" alone means any T2-family member: T2, T2a, T2b.
  - Ranges like "T1mi-T1a", "T2a-T2b", "T3-T4", "T1-T2", "T2-T3" are
    inclusive enumerations over the literal categories named.
The CSV expands every such row into the explicit subcategory rules
so the build pipeline can match by literal equality.

Special outcome: TX,N0,M0 maps to the named stage "Occult carcinoma"
(not a Roman numeral) -- AJCC's special case for malignant cells found
in sputum/bronchial washings without a visualizable primary.

M categories use the suffix only (M0, M1, M1a, M1b, M1c, M1c1, M1c2);
the c/p prefix lives in Classification. Bare M1 and bare M1c have no
stage-table entry, so they return UNSTAGEABLE -- staging requires the
specific subcategory.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class LungT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    T1 = "T1"
    T1MI = "T1mi"
    T1A = "T1a"
    T1B = "T1b"
    T1C = "T1c"
    T2 = "T2"
    T2A = "T2a"
    T2B = "T2b"
    T3 = "T3"
    T4 = "T4"


class LungN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"
    N2A = "N2a"
    N2B = "N2b"
    N3 = "N3"


class LungM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"
    M1C1 = "M1c1"
    M1C2 = "M1c2"


class LungState(NamedTuple):
    T: LungT
    N: LungN
    M: LungM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="lung",
    edition=Edition.AJCC_9,
    category="thoracic",
    state_cls=LungState,
    columns={
        "T": LungT,
        "N": LungN,
        "M": LungM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "TX,N0,M0 -- AJCC's named 'Occult carcinoma' stage",
            LungState(LungT.TX, LungN.N0, LungM.M0, C, NO, NO, NO),
            "Occult carcinoma",
        ),
        (
            "in-situ disease (Stage 0)",
            LungState(LungT.TIS, LungN.N0, LungM.M0, C, NO, NO, NO),
            "0",
        ),
        (
            "T1mi N0 -- minimally invasive adenocarcinoma (IA1)",
            LungState(LungT.T1MI, LungN.N0, LungM.M0, C, NO, NO, NO),
            "IA1",
        ),
        (
            "T1c N0 (Stage IA3)",
            LungState(LungT.T1C, LungN.N0, LungM.M0, C, NO, NO, NO),
            "IA3",
        ),
        (
            "T2a N0 (Stage IB)",
            LungState(LungT.T2A, LungN.N0, LungM.M0, C, NO, NO, NO),
            "IB",
        ),
        (
            "T1c N1 -- T1-family with N1 (Stage IIA)",
            LungState(LungT.T1C, LungN.N1, LungM.M0, C, NO, NO, NO),
            "IIA",
        ),
        (
            "T2a N1 -- T2a-T2b with N1 (Stage IIB)",
            LungState(LungT.T2A, LungN.N1, LungM.M0, C, NO, NO, NO),
            "IIB",
        ),
        (
            "T1a N2b -- T1-family with N2b (Stage IIIA)",
            LungState(LungT.T1A, LungN.N2B, LungM.M0, C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T4 N2a -- T4 with N2a-N2b (Stage IIIB)",
            LungState(LungT.T4, LungN.N2A, LungM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T2 N3 -- T1-T2 with N3 (Stage IIIB)",
            LungState(LungT.T2, LungN.N3, LungM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T3 N3 (Stage IIIC)",
            LungState(LungT.T3, LungN.N3, LungM.M0, C, NO, NO, NO),
            "IIIC",
        ),
        (
            "M1a -- intrathoracic metastasis (Stage IVA)",
            LungState(LungT.T2A, LungN.N0, LungM.M1A, C, NO, NO, NO),
            "IVA",
        ),
        (
            "M1c1 -- multiple metastases in single organ (Stage IVB)",
            LungState(LungT.T4, LungN.N3, LungM.M1C1, C, NO, NO, NO),
            "IVB",
        ),
        (
            "pTNM T1a N0 -- same stage as cTNM (lung doesn't distinguish)",
            LungState(LungT.T1A, LungN.N0, LungM.M0, P, NO, NO, NO),
            "IA1",
        ),
        (
            "ypTNM T1a -- descriptors ignored for lung (still IA1)",
            LungState(LungT.T1A, LungN.N0, LungM.M0, P, YES, YES, YES),
            "IA1",
        ),
        (
            "unstageable: bare M1 (no subcategory) has no stage table entry",
            LungState(LungT.T1A, LungN.N0, LungM.M1, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "unstageable: Tis with N1 (PDF only stages Tis at N0,M0)",
            LungState(LungT.TIS, LungN.N1, LungM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
