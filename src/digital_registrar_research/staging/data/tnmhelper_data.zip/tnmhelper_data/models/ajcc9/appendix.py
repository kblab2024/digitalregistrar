"""Appendiceal carcinoma (NON-neuroendocrine), AJCC 9.

Source: pdfsource/appendixv9.pdf. NET (neuroendocrine) appendiceal
tumors are staged separately under ajcc9/appendix_net.

T-family categories include Tis and Tis(LAMN) -- a low-grade
appendiceal mucinous neoplasm confined to the muscularis propria.
Bare T4 is a stage-table category that subsumes T4a/T4b for N1
disease.

N-family: N1 with subcategories N1a (one node), N1b (2-3 nodes), and
N1c (no positive nodes but tumor deposits in subserosa or mesentery).
"N1" in the stage table covers {N1, N1a, N1b, N1c}.

M-family: M0, M1a (acellular mucin, no identifiable tumor cells),
M1b (intraperitoneal mets with tumor cells), M1c (mets to sites other
than peritoneum).

Grade matters only for M1b: G1 -> IVA, G2/G3/GX -> IVB.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class AppendixT(StrEnum):
    TX = "TX"
    T0 = "T0"
    TIS = "Tis"
    TIS_LAMN = "Tis(LAMN)"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"
    T4A = "T4a"
    T4B = "T4b"


class AppendixN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N1A = "N1a"
    N1B = "N1b"
    N1C = "N1c"
    N2 = "N2"


class AppendixM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"


class AppendixGrade(StrEnum):
    GX = "GX"
    G1 = "G1"
    G2 = "G2"
    G3 = "G3"


class AppendixState(NamedTuple):
    T: AppendixT
    N: AppendixN
    M: AppendixM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo
    Grade: AppendixGrade


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL
GX = AppendixGrade.GX
G1 = AppendixGrade.G1
G2 = AppendixGrade.G2
G3 = AppendixGrade.G3

MODEL = StagingModel(
    name="appendix",
    edition=Edition.AJCC_9,
    category="gi",
    state_cls=AppendixState,
    columns={
        "T": AppendixT,
        "N": AppendixN,
        "M": AppendixM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
        "Grade": AppendixGrade,
    },
    examples=(
        ("Tis N0 M0 (0)",
         AppendixState(AppendixT.TIS, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, GX), "0"),
        ("Tis(LAMN) N0 M0 (0)",
         AppendixState(AppendixT.TIS_LAMN, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, GX), "0"),
        ("T1 N0 M0 (I)",
         AppendixState(AppendixT.T1, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, GX), "I"),
        ("T2 N0 M0 (I)",
         AppendixState(AppendixT.T2, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, G1), "I"),
        ("T3 N0 M0 (IIA)",
         AppendixState(AppendixT.T3, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, G2), "IIA"),
        ("T4a N0 M0 (IIB)",
         AppendixState(AppendixT.T4A, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, GX), "IIB"),
        ("T4b N0 M0 (IIC)",
         AppendixState(AppendixT.T4B, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, GX), "IIC"),
        ("T1 N1a M0 -- T1 with N1 family (IIIA)",
         AppendixState(AppendixT.T1, AppendixN.N1A, AppendixM.M0,
                       P, NO, NO, NO, GX), "IIIA"),
        ("T2 N1c M0 -- tumor deposit (IIIA)",
         AppendixState(AppendixT.T2, AppendixN.N1C, AppendixM.M0,
                       P, NO, NO, NO, GX), "IIIA"),
        ("T3 N1b M0 (IIIB)",
         AppendixState(AppendixT.T3, AppendixN.N1B, AppendixM.M0,
                       P, NO, NO, NO, G2), "IIIB"),
        ("T4a N1 M0 -- T4 with N1 family (IIIB)",
         AppendixState(AppendixT.T4A, AppendixN.N1, AppendixM.M0,
                       P, NO, NO, NO, GX), "IIIB"),
        ("T4b N1c M0 -- T4 with N1 family (IIIB)",
         AppendixState(AppendixT.T4B, AppendixN.N1C, AppendixM.M0,
                       P, NO, NO, NO, GX), "IIIB"),
        ("T3 N2 M0 -- any T with N2 (IIIC)",
         AppendixState(AppendixT.T3, AppendixN.N2, AppendixM.M0,
                       P, NO, NO, NO, G2), "IIIC"),
        ("T1 N2 M0 -- any T with N2 (IIIC)",
         AppendixState(AppendixT.T1, AppendixN.N2, AppendixM.M0,
                       P, NO, NO, NO, GX), "IIIC"),
        ("M1a -- acellular mucin (IVA)",
         AppendixState(AppendixT.T3, AppendixN.N0, AppendixM.M1A,
                       C, NO, NO, NO, G2), "IVA"),
        ("M1b G1 -- peritoneal with tumor cells, well diff (IVA)",
         AppendixState(AppendixT.T3, AppendixN.N1, AppendixM.M1B,
                       C, NO, NO, NO, G1), "IVA"),
        ("M1b G2 -- peritoneal with tumor cells, moderately diff (IVB)",
         AppendixState(AppendixT.T3, AppendixN.N1, AppendixM.M1B,
                       C, NO, NO, NO, G2), "IVB"),
        ("M1b GX -- peritoneal with tumor cells, grade unknown (IVB)",
         AppendixState(AppendixT.T3, AppendixN.N1, AppendixM.M1B,
                       C, NO, NO, NO, GX), "IVB"),
        ("M1c -- mets to non-peritoneal site (IVC)",
         AppendixState(AppendixT.T4B, AppendixN.N2, AppendixM.M1C,
                       C, NO, NO, NO, G3), "IVC"),
        ("unstageable: TX with N0",
         AppendixState(AppendixT.TX, AppendixN.N0, AppendixM.M0,
                       C, NO, NO, NO, GX), "UNSTAGEABLE"),
        ("T1 NX M0 -- NX aliased to N0 in engine -> I",
         AppendixState(AppendixT.T1, AppendixN.NX, AppendixM.M0,
                       C, NO, NO, NO, GX), "I"),
    ),
)
