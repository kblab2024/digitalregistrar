"""Cervix uteri carcinoma, AJCC 9.

Source: pdfsource/cervix.pdf. Aligned with FIGO 2018; T and N
categories carry FIGO equivalents. Single stage table; cTNM and pTNM
share rules. Every CSV rule uses `ANY` for Classification and
descriptors.

T family: T1 family includes T1, T1a, T1a1, T1a2, T1b, T1b1, T1b2, T1b3
each with distinct stage assignment. T2/T3 similar.

N family stages: N1 family (N1, N1mi, N1a) -> IIIC1; N2 family (N2, N2mi,
N2a) -> IIIC2; N0(i+) treated as N0 for staging.

Stage rows summarized:
  - I/IA/IA1/IA2/IB/IB1/IB2/IB3/II/IIA/IIA1/IIA2/IIB/III/IIIA/IIIB: T-only with N0 (or N0(i+))
  - IIIC1: any T (T1-T3) with N1 family
  - IIIC2: any T (T1-T3) with N2 family
  - IVA:   T4 any N M0
  - IVB:   any T any N M1
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class CervixT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T1A = "T1a"
    T1A1 = "T1a1"
    T1A2 = "T1a2"
    T1B = "T1b"
    T1B1 = "T1b1"
    T1B2 = "T1b2"
    T1B3 = "T1b3"
    T2 = "T2"
    T2A = "T2a"
    T2A1 = "T2a1"
    T2A2 = "T2a2"
    T2B = "T2b"
    T3 = "T3"
    T3A = "T3a"
    T3B = "T3b"
    T4 = "T4"


class CervixN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N0_I_PLUS = "N0(i+)"
    N1 = "N1"
    N1MI = "N1mi"
    N1A = "N1a"
    N2 = "N2"
    N2MI = "N2mi"
    N2A = "N2a"


class CervixM(StrEnum):
    M0 = "M0"
    M1 = "M1"


class CervixState(NamedTuple):
    T: CervixT
    N: CervixN
    M: CervixM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="cervix",
    edition=Edition.AJCC_9,
    category="gyn",
    state_cls=CervixState,
    columns={
        "T": CervixT,
        "N": CervixN,
        "M": CervixM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        ("T1a1 N0 M0 (IA1)",
         CervixState(CervixT.T1A1, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IA1"),
        ("T1b3 N0 M0 (IB3)",
         CervixState(CervixT.T1B3, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IB3"),
        ("T2a1 N0 M0 (IIA1)",
         CervixState(CervixT.T2A1, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IIA1"),
        ("T2b N0 M0 -- parametrial invasion (IIB)",
         CervixState(CervixT.T2B, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IIB"),
        ("T3a N0 M0 -- lower vagina (IIIA)",
         CervixState(CervixT.T3A, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IIIA"),
        ("T3b N0 M0 -- pelvic wall / hydronephrosis (IIIB)",
         CervixState(CervixT.T3B, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IIIB"),
        ("T1b1 N1 M0 -- pelvic node metastasis (IIIC1)",
         CervixState(CervixT.T1B1, CervixN.N1, CervixM.M0, P, NO, NO, NO), "IIIC1"),
        ("T2 N1a M0 -- N1 family (IIIC1)",
         CervixState(CervixT.T2, CervixN.N1A, CervixM.M0, P, NO, NO, NO), "IIIC1"),
        ("T1b1 N2 M0 -- para-aortic nodes (IIIC2)",
         CervixState(CervixT.T1B1, CervixN.N2, CervixM.M0, P, NO, NO, NO), "IIIC2"),
        ("T3a N2a M0 -- N2 family overrides T3a (IIIC2)",
         CervixState(CervixT.T3A, CervixN.N2A, CervixM.M0, P, NO, NO, NO), "IIIC2"),
        ("T4 N0 M0 -- bladder/rectum mucosa (IVA)",
         CervixState(CervixT.T4, CervixN.N0, CervixM.M0, C, NO, NO, NO), "IVA"),
        ("T4 N2 M0 -- T4 dominates over N family (IVA)",
         CervixState(CervixT.T4, CervixN.N2, CervixM.M0, C, NO, NO, NO), "IVA"),
        ("any T any N M1 (IVB)",
         CervixState(CervixT.T1A, CervixN.N0, CervixM.M1, C, NO, NO, NO), "IVB"),
        ("T1 N0(i+) M0 -- isolated tumor cells treated as N0 (I)",
         CervixState(CervixT.T1, CervixN.N0_I_PLUS, CervixM.M0, P, NO, NO, NO), "I"),
        ("unstageable: TX with N0",
         CervixState(CervixT.TX, CervixN.N0, CervixM.M0, C, NO, NO, NO), "UNSTAGEABLE"),
        ("T1 NX M0 -- NX aliased to N0 in engine -> I",
         CervixState(CervixT.T1, CervixN.NX, CervixM.M0, C, NO, NO, NO), "I"),
    ),
)
