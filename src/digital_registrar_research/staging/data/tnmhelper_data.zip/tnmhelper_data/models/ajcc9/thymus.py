"""Thymus AJCC 9 staging.

Covers thymic epithelial tumors (thymoma, thymic carcinoma, and thymic
neuroendocrine tumors). Source: pdfsource/_pages_thymusv9/.

State shape parallels lung:

- **Classification** (`c` / `p`): how the assessment was made. The PDF
  M-category table splits each metastasis tier into separate cM* and
  pM* entries (cM0, cM1, cM1a, cM1b, pM1, pM1a, pM1b). Following the
  lung/stomach pattern we store the suffix-only literal (M0, M1, M1a,
  M1b) in the M column and keep the c/p marker in `Classification`.
- **Descriptors** (independent Yes/No flags): `DescY`, `DescR`, `DescM`.
  The AJCC 9 thymus stage table is independent of Classification and
  these descriptors -- every row uses ANY for them.

T-family conventions used in the PDF stage table:
  - "T1a-T1b" is the only T-range row; expanded into the explicit
    T1a and T1b sub-rules in the CSV. T1 itself (the parent category,
    "tumor limited to the thymus") has no stage-table entry per the
    PDF -- treat as UNSTAGEABLE.

N-range conventions:
  - "N0-N1" enumerates N0 and N1 inclusively.

M-range conventions:
  - "M0-M1a" enumerates M0 and M1a inclusively.

Bare M1 (parent category) has no stage-table entry, so it returns
UNSTAGEABLE; staging requires the M1a/M1b subcategory.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class ThymusT(StrEnum):
    TX = "TX"
    T1 = "T1"
    T1A = "T1a"
    T1B = "T1b"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class ThymusN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"
    N2 = "N2"


class ThymusM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"


class ThymusState(NamedTuple):
    T: ThymusT
    N: ThymusN
    M: ThymusM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="thymus",
    edition=Edition.AJCC_9,
    category="thoracic",
    state_cls=ThymusState,
    columns={
        "T": ThymusT,
        "N": ThymusN,
        "M": ThymusM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "T1a N0 M0 -- early thymoma (Stage I)",
            ThymusState(ThymusT.T1A, ThymusN.N0, ThymusM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T1b N0 M0 -- T1b also Stage I",
            ThymusState(ThymusT.T1B, ThymusN.N0, ThymusM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 -- pericardial invasion (Stage II)",
            ThymusState(ThymusT.T2, ThymusN.N0, ThymusM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- invades brachiocephalic vein etc. (Stage IIIA)",
            ThymusState(ThymusT.T3, ThymusN.N0, ThymusM.M0, C, NO, NO, NO),
            "IIIA",
        ),
        (
            "T4 N0 M0 -- invades great vessels / aorta (Stage IIIB)",
            ThymusState(ThymusT.T4, ThymusN.N0, ThymusM.M0, C, NO, NO, NO),
            "IIIB",
        ),
        (
            "T1a N1 M0 -- anterior (perithymic) nodes (Stage IVA)",
            ThymusState(ThymusT.T1A, ThymusN.N1, ThymusM.M0, C, NO, NO, NO),
            "IVA",
        ),
        (
            "T2 N0 M1a -- pleural nodule, no nodes (Stage IVA)",
            ThymusState(ThymusT.T2, ThymusN.N0, ThymusM.M1A, C, NO, NO, NO),
            "IVA",
        ),
        (
            "T4 N1 M1a -- N0-N1 with M1a (Stage IVA)",
            ThymusState(ThymusT.T4, ThymusN.N1, ThymusM.M1A, C, NO, NO, NO),
            "IVA",
        ),
        (
            "T2 N2 M0 -- deep intrathoracic nodes (Stage IVB)",
            ThymusState(ThymusT.T2, ThymusN.N2, ThymusM.M0, C, NO, NO, NO),
            "IVB",
        ),
        (
            "T3 N2 M1a -- N2 with M0-M1a (Stage IVB)",
            ThymusState(ThymusT.T3, ThymusN.N2, ThymusM.M1A, C, NO, NO, NO),
            "IVB",
        ),
        (
            "T1a N0 M1b -- pulmonary parenchymal metastasis (Stage IVB)",
            ThymusState(ThymusT.T1A, ThymusN.N0, ThymusM.M1B, C, NO, NO, NO),
            "IVB",
        ),
        (
            "pTNM T1a N0 M0 -- same stage as cTNM (PDF table is identical)",
            ThymusState(ThymusT.T1A, ThymusN.N0, ThymusM.M0, P, NO, NO, NO),
            "I",
        ),
        (
            "ypTNM T1a -- descriptors do not affect thymus stage outcome",
            ThymusState(ThymusT.T1A, ThymusN.N0, ThymusM.M0, P, YES, YES, YES),
            "I",
        ),
        (
            "unstageable: bare T1 (parent category, no stage-table entry)",
            ThymusState(ThymusT.T1, ThymusN.N0, ThymusM.M0, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
        (
            "unstageable: bare M1 (no subcategory)",
            ThymusState(ThymusT.T1A, ThymusN.N0, ThymusM.M1, C, NO, NO, NO),
            "UNSTAGEABLE",
        ),
    ),
)
