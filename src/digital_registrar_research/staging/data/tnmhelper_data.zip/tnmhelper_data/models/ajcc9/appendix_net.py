"""Neuroendocrine Tumor of the Appendix AJCC 9 staging.

Source: pdfsource/appendnetv9.pdf. Distinct from the (non-NET)
appendiceal carcinoma model -- this file covers NETs only.

State shape parallels the GI models (colon AJCC 8, lung AJCC 9):

- **Classification** (`c` / `p`): how the assessment was made.
- **Descriptors** (independent Yes/No flags): `DescY`, `DescR`, `DescM`.

The AJCC 9 PDF for appendix NET defines a SINGLE stage group table that
applies identically to cTNM, pTNM, and ypTNM. Every rule in the CSV
therefore uses `ANY` for Classification and the three descriptor
columns -- the stage outcome does not depend on them. Fields remain in
state for clinical record-keeping and to keep the GUI/data-entry shape
consistent across organs.

T criteria (size + invasion):
  - T1: tumor <= 2 cm in greatest dimension
  - T2: tumor > 2 cm and <= 4 cm in greatest dimension
  - T3: tumor > 4 cm in greatest dimension, OR subserosal invasion, OR
    involvement of the mesoappendix
  - T4: tumor perforates the peritoneum or directly invades other
    adjacent organs/structures (excluding direct mural extension to
    adjacent subserosa of adjacent bowel), e.g., abdominal wall or
    skeletal muscle.

N criteria:
  - NX, N0, N1 (tumor involvement of regional lymph node(s)). The PDF
    does not define N1a/N1b subcategories for appendix NET.

M criteria (cM0/cM1/pM1 with site subcategories):
  - M0:  no distant metastasis
  - M1:  distant metastasis (parent)
  - M1a: hepatic metastasis only
  - M1b: extrahepatic metastasis only (e.g., lung, ovary, nonregional
        lymph node, peritoneum, bone)
  - M1c: both hepatic and extrahepatic metastases

Stage group table (from p3 of the PDF):
  T1, NX or N0, M0    -> I
  T2, NX or N0, M0    -> II
  T3, N0, M0          -> II
  T4, N0, M0          -> III
  Any T, N1, M0       -> III
  Any T, Any N, M1    -> IV

Note: the PDF allows NX for T1 and T2 but only lists N0 for T3 and T4.
A T3 or T4 with NX therefore has no stage-table entry and falls through
to UNSTAGEABLE. Bare M1 (parent, no subcategory) is allowed by the
stage table ("Any N, M1 -> IV"), so bare M1 maps to IV alongside
M1a/M1b/M1c.
"""

from enum import StrEnum
from typing import NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel, YesNo


class AppendixNetT(StrEnum):
    TX = "TX"
    T0 = "T0"
    T1 = "T1"
    T2 = "T2"
    T3 = "T3"
    T4 = "T4"


class AppendixNetN(StrEnum):
    NX = "NX"
    N0 = "N0"
    N1 = "N1"


class AppendixNetM(StrEnum):
    M0 = "M0"
    M1 = "M1"
    M1A = "M1a"
    M1B = "M1b"
    M1C = "M1c"


class AppendixNetState(NamedTuple):
    T: AppendixNetT
    N: AppendixNetN
    M: AppendixNetM
    Classification: Classification
    DescY: YesNo
    DescR: YesNo
    DescM: YesNo


YES = YesNo.YES
NO = YesNo.NO
C = Classification.CLINICAL
P = Classification.PATHOLOGICAL

MODEL = StagingModel(
    name="appendix_net",
    edition=Edition.AJCC_9,
    category="gi",
    state_cls=AppendixNetState,
    columns={
        "T": AppendixNetT,
        "N": AppendixNetN,
        "M": AppendixNetM,
        "Classification": Classification,
        "DescY": YesNo,
        "DescR": YesNo,
        "DescM": YesNo,
    },
    examples=(
        (
            "T1 N0 M0 -- small tumor, no nodes (Stage I)",
            AppendixNetState(AppendixNetT.T1, AppendixNetN.N0, AppendixNetM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T1 NX M0 -- nodes not assessed, still Stage I",
            AppendixNetState(AppendixNetT.T1, AppendixNetN.NX, AppendixNetM.M0, C, NO, NO, NO),
            "I",
        ),
        (
            "T2 N0 M0 -- 2-4 cm, no nodes (Stage II)",
            AppendixNetState(AppendixNetT.T2, AppendixNetN.N0, AppendixNetM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T2 NX M0 -- 2-4 cm, nodes not assessed (Stage II)",
            AppendixNetState(AppendixNetT.T2, AppendixNetN.NX, AppendixNetM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T3 N0 M0 -- >4 cm or subserosa/mesoappendix (Stage II)",
            AppendixNetState(AppendixNetT.T3, AppendixNetN.N0, AppendixNetM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T4 N0 M0 -- peritoneal perforation/adjacent organs (Stage III)",
            AppendixNetState(AppendixNetT.T4, AppendixNetN.N0, AppendixNetM.M0, C, NO, NO, NO),
            "III",
        ),
        (
            "T1 N1 M0 -- regional node positive (Stage III)",
            AppendixNetState(AppendixNetT.T1, AppendixNetN.N1, AppendixNetM.M0, C, NO, NO, NO),
            "III",
        ),
        (
            "T4 N1 M0 -- T4 with N1 (Stage III)",
            AppendixNetState(AppendixNetT.T4, AppendixNetN.N1, AppendixNetM.M0, C, NO, NO, NO),
            "III",
        ),
        (
            "M1a -- hepatic mets only (Stage IV)",
            AppendixNetState(AppendixNetT.T2, AppendixNetN.N0, AppendixNetM.M1A, C, NO, NO, NO),
            "IV",
        ),
        (
            "M1b -- extrahepatic mets only (Stage IV)",
            AppendixNetState(AppendixNetT.T3, AppendixNetN.N1, AppendixNetM.M1B, C, NO, NO, NO),
            "IV",
        ),
        (
            "M1c -- hepatic + extrahepatic mets (Stage IV)",
            AppendixNetState(AppendixNetT.T4, AppendixNetN.N1, AppendixNetM.M1C, P, NO, NO, NO),
            "IV",
        ),
        (
            "bare M1 (no subcategory) -- still Stage IV (Any T, Any N, M1)",
            AppendixNetState(AppendixNetT.T2, AppendixNetN.N0, AppendixNetM.M1, C, NO, NO, NO),
            "IV",
        ),
        (
            "ypTNM T2 N0 -- descriptors ignored for appendix NET (still II)",
            AppendixNetState(AppendixNetT.T2, AppendixNetN.N0, AppendixNetM.M0, P, YES, NO, NO),
            "II",
        ),
        (
            "T3 NX M0 -- NX aliased to N0 in engine -> II",
            AppendixNetState(AppendixNetT.T3, AppendixNetN.NX, AppendixNetM.M0, C, NO, NO, NO),
            "II",
        ),
        (
            "T4 NX M0 -- NX aliased to N0 in engine -> III",
            AppendixNetState(AppendixNetT.T4, AppendixNetN.NX, AppendixNetM.M0, C, NO, NO, NO),
            "III",
        ),
    ),
)
