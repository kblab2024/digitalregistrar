"""Pack `tnmhelper_data/` into a single zip bundle.

Layout inside the zip:

    manifest.json
    tnmhelper_data/models/<ed>/__init__.py
    tnmhelper_data/models/<ed>/<organ>.py
    tnmhelper_data/<ed>/<organ>/rules.csv
    tnmhelper_data/<ed>/<organ>/criteria.json
    tnmhelper_data/<ed>/<organ>/derivation.json

The inner root path (`tnmhelper_data/`) is preserved so the provider
can find files at deterministic locations and zipimport finds the .py
models at `<zip>/tnmhelper_data/models/`. PDFs and __pycache__ are
excluded.
"""
from __future__ import annotations

import hashlib
import json
import time
import zipfile
from pathlib import Path

SCHEMA_VERSION = 1
EXCLUDED_DIRS = frozenset({"__pycache__"})
EXCLUDED_SUFFIXES = frozenset({".pyc", ".pyo"})


def _sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def export_bundle(
    source: str | Path,
    output: str | Path,
    *,
    compress: bool = True,
    with_pyc: bool = False,
) -> Path:
    """Pack `source` (a tnmhelper_data/ directory) into `output` (a .zip).

    Returns the resolved output path on success. Existing output files
    are overwritten.

    `with_pyc` writes compiled .pyc next to each .py model so zipimport
    can skip the source->bytecode compile step on cold start (see
    plan §3). Off by default — the v1 bundle is .py-only.
    """
    src = Path(source).resolve()
    if not src.is_dir():
        raise NotADirectoryError(f"source must be a directory: {src}")
    out = Path(output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    manifest_files: list[dict] = []
    organs: list[dict] = []
    compression = zipfile.ZIP_DEFLATED if compress else zipfile.ZIP_STORED

    with zipfile.ZipFile(out, "w", compression=compression) as zf:
        for path in sorted(src.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(src.parent)
            parts = rel.parts
            if any(part in EXCLUDED_DIRS for part in parts):
                continue
            if path.suffix in EXCLUDED_SUFFIXES and not with_pyc:
                continue
            data = path.read_bytes()
            inner = "/".join(parts).replace("\\", "/")
            zf.writestr(inner, data)
            manifest_files.append({
                "path": inner,
                "size": len(data),
                "sha256": _sha256(data),
            })

        for ed_dir in sorted((src).iterdir()):
            if not ed_dir.is_dir() or ed_dir.name == "models":
                continue
            for organ_dir in sorted(ed_dir.iterdir()):
                if not organ_dir.is_dir():
                    continue
                organs.append({"organ": organ_dir.name, "edition_slug": ed_dir.name})

        manifest = {
            "schema_version": SCHEMA_VERSION,
            "build_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "source": str(src),
            "compress": compress,
            "with_pyc": with_pyc,
            "organs": organs,
            "files": manifest_files,
        }
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))

    return out


def verify_bundle(bundle_path: str | Path) -> dict:
    """Read manifest.json from `bundle_path` and verify every listed
    file's sha256 against the actual archive contents. Returns the
    manifest on success; raises ValueError on mismatch.
    """
    bp = Path(bundle_path).resolve()
    if not bp.is_file():
        raise FileNotFoundError(str(bp))
    with zipfile.ZipFile(bp, "r") as zf:
        manifest_raw = zf.read("manifest.json").decode("utf-8")
        manifest = json.loads(manifest_raw)
        bad: list[tuple[str, str, str]] = []
        for entry in manifest["files"]:
            data = zf.read(entry["path"])
            actual = _sha256(data)
            if actual != entry["sha256"]:
                bad.append((entry["path"], entry["sha256"], actual))
        if bad:
            details = "\n".join(f"  {p}: expected {exp}, got {got}" for p, exp, got in bad)
            raise ValueError(f"bundle integrity check failed:\n{details}")
    return manifest
