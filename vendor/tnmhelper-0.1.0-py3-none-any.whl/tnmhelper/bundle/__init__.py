"""Bundle: export the in-tree data layer as a single zip for shipping.

The exported zip contains the entire `tnmhelper_data/` tree (model
`.py` files + rules.csv + criteria.json + derivation.json triples)
plus a `manifest.json` with per-file sha256 hashes.

Consumers install `tnmhelper` (the Python package) and ship the bundle
separately; they call `tnmhelper.set_data_source(<bundle>.zip)` to
load it.
"""
