"""CLI entry: `python -m tnmhelper.bundle ...`.

Subcommands:
  export  - pack tnmhelper_data/ into a single zip
  verify  - re-check sha256 hashes from manifest.json against archive contents
"""
from __future__ import annotations

import argparse
import sys

from tnmhelper.bundle.exporter import export_bundle, verify_bundle


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="tnmhelper.bundle", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd")

    pe = sub.add_parser("export", help="pack tnmhelper_data/ into a zip")
    pe.add_argument("--out", required=True, help="output .zip path")
    pe.add_argument("--source", default="tnmhelper_data",
                    help="source directory (default: tnmhelper_data)")
    pe.add_argument("--no-compress", action="store_true",
                    help="store uncompressed (ZIP_STORED) for slightly faster reads")
    pe.add_argument("--with-pyc", action="store_true",
                    help="include compiled .pyc files (faster cold start)")
    pe.add_argument("--verify", action="store_true",
                    help="after exporting, run round-trip stage check via tests/smoke.py")

    pv = sub.add_parser("verify", help="check sha256 hashes in an existing bundle")
    pv.add_argument("bundle", help="path to a .zip bundle")

    # Back-compat flat form: `python -m tnmhelper.bundle --out X.zip`
    p.add_argument("--out", help=argparse.SUPPRESS)
    p.add_argument("--source", help=argparse.SUPPRESS)
    p.add_argument("--no-compress", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--with-pyc", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--verify", action="store_true", help=argparse.SUPPRESS)

    args = p.parse_args(argv)

    cmd = args.cmd
    if cmd is None and args.out:
        cmd = "export"
    if cmd == "export":
        out = export_bundle(
            args.source or "tnmhelper_data",
            args.out,
            compress=not args.no_compress,
            with_pyc=args.with_pyc,
        )
        print(f"wrote bundle: {out}")
        manifest = verify_bundle(out)
        print(
            f"manifest: schema_version={manifest['schema_version']} "
            f"organs={len(manifest['organs'])} files={len(manifest['files'])}"
        )
        if args.verify:
            return _round_trip_check(out)
        return 0
    if cmd == "verify":
        manifest = verify_bundle(args.bundle)
        print(
            f"OK: {args.bundle} (schema_version={manifest['schema_version']}, "
            f"organs={len(manifest['organs'])}, files={len(manifest['files'])})"
        )
        return 0
    p.print_help()
    return 2


def _round_trip_check(bundle_path) -> int:
    """Load the bundle and run the smoke test against it. Must produce
    identical pass counts as a filesystem run.
    """
    import importlib
    import tnmhelper

    tnmhelper.set_data_source(str(bundle_path))

    from tests import smoke  # noqa: WPS433 (intentional late import)
    importlib.reload(smoke)
    rc = smoke.main()
    if rc == 0:
        print("round-trip verify: PASS")
    else:
        print("round-trip verify: FAIL", file=sys.stderr)
    return rc


if __name__ == "__main__":
    sys.exit(main())
