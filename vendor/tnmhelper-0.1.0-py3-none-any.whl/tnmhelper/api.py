"""Public Python API (Layer 3).

The stable surface a downstream consumer imports. The dspy-based
extraction system uses (a) list organs/editions, (b) get the observable
schema for an (organ, edition) to construct an LM prompt, and (c)
submit observations and get a stage.

Common invocation:

    >>> import tnmhelper
    >>> tnmhelper.set_data_source(None)  # autodetect
    >>> tnmhelper.stage_from_observations(
    ...     "lung", "AJCC 9",
    ...     {"size_cm": 1.5},
    ...     Classification="c", DescY="No", DescR="No", DescM="No",
    ... )
    DerivedStage(organ='lung', edition='AJCC 9', T='T1a', N='N0', ...)
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from tnmhelper.backend._shared import Edition
from tnmhelper.schema import DerivedStage, ModelSpec, ObservableSpec

_INITIALIZED = False
_DATA_SOURCE: str | None = None


def _coerce_edition(edition: Edition | str) -> Edition:
    if isinstance(edition, Edition):
        return edition
    return Edition(edition)


def set_data_source(path_or_zip: str | Path | None) -> None:
    """Configure the data layer.

    Pass an explicit path (directory or .zip), or None to autodetect:
      1. TNMHELPER_DATA env var
      2. Packaged resource `tnmhelper/default-data.zip`
      3. ./tnmhelper_data/ relative to cwd

    Lazy: engine + derivation initialization happen on first call to
    a function that needs them.
    """
    from tnmhelper import data_provider
    from tnmhelper import models as models_pkg
    from tnmhelper.backend import derive as derive_mod, engine as engine_mod

    global _INITIALIZED, _DATA_SOURCE
    resolved = _resolve_data_source(path_or_zip)

    if resolved.is_file() and resolved.suffix.lower() == ".zip":
        from tnmhelper.data_provider.zipbundle import ZipBundleProvider

        sys.path.insert(0, str(resolved))
        provider = ZipBundleProvider(resolved)
    else:
        from tnmhelper.data_provider.filesystem import FilesystemProvider

        provider = FilesystemProvider(resolved)

    data_provider.set_provider(provider)
    models_pkg.install_models_path(provider.models_root())
    models_pkg.discover()

    engine_mod._INITIALIZED = False
    derive_mod._INITIALIZED = False
    engine_mod.STAGING_RULES.clear()
    derive_mod.DERIVATIONS.clear()

    _DATA_SOURCE = str(resolved)
    _INITIALIZED = False


def _resolve_data_source(path_or_zip: str | Path | None) -> Path:
    if path_or_zip is not None:
        p = Path(path_or_zip)
        if not p.exists():
            raise FileNotFoundError(f"data source not found: {p}")
        return p

    env = os.environ.get("TNMHELPER_DATA")
    if env:
        p = Path(env)
        if not p.exists():
            raise FileNotFoundError(
                f"TNMHELPER_DATA={env!r} but path does not exist"
            )
        return p

    try:
        import importlib.resources as ilr

        candidate = ilr.files("tnmhelper").joinpath("default-data.zip")
        if candidate.is_file():
            return Path(str(candidate))
    except (ModuleNotFoundError, AttributeError, FileNotFoundError):
        pass

    local = Path("tnmhelper_data")
    if local.is_dir():
        return local.resolve()

    raise RuntimeError(
        "no data source configured; pass tnmhelper.set_data_source(path) "
        "or set TNMHELPER_DATA, or run from a directory containing "
        "tnmhelper_data/"
    )


def _ensure_initialized() -> None:
    from tnmhelper.backend import derive as derive_mod, engine as engine_mod

    global _INITIALIZED
    if _INITIALIZED:
        return
    if _DATA_SOURCE is None:
        set_data_source(None)
    engine_mod.initialize()
    derive_mod.initialize()
    _INITIALIZED = True


# ---------------------------------------------------------------------------
# Discovery / schema
# ---------------------------------------------------------------------------


def organs() -> list[str]:
    """Sorted list of organ names registered in the active data source.

    Examples:
        >>> tnmhelper.set_data_source(None)
        >>> tnmhelper.organs()[:3]
        ['ampulla', 'breast', 'cervix']

    Raises:
        RuntimeError: if no data source is configured.
    """
    _ensure_initialized()
    from tnmhelper.models import organs as _organs
    return _organs()


def editions_for(organ: str) -> list[Edition]:
    """Sorted list of editions for which `organ` has a registered model.

    Examples:
        >>> tnmhelper.editions_for('lung')
        [<Edition.AJCC_9: 'AJCC 9'>]
        >>> tnmhelper.editions_for('breast')
        [<Edition.AJCC_8: 'AJCC 8'>]
        >>> tnmhelper.editions_for('nonexistent')   # empty list, not error
        []
    """
    _ensure_initialized()
    from tnmhelper.models import editions_for as _editions_for
    return _editions_for(organ)


def model_spec(organ: str, edition: Edition | str) -> ModelSpec:
    """Schema for an (organ, edition): columns + valid enum values per column.

    Use this to build a stage() call: every column listed must be
    passed as a kwarg with a string from its `values` tuple.

    Examples:
        >>> spec = tnmhelper.model_spec('lung', 'AJCC 9')
        >>> list(spec.columns)
        ['T', 'N', 'M', 'Classification', 'DescY', 'DescR', 'DescM']
        >>> spec.columns['T'][:3]
        ('TX', 'T0', 'Tis')

    Raises:
        KeyError: if no model is registered for (organ, edition).
    """
    _ensure_initialized()
    from tnmhelper.models import MODEL_REGISTRY
    ed = _coerce_edition(edition)
    model = MODEL_REGISTRY.get((organ, ed))
    if model is None:
        raise KeyError(f"no model for ({organ!r}, {ed.value!r})")
    return ModelSpec(
        organ=organ,
        edition=ed.value,
        category=model.category,
        columns={col: tuple(e.value for e in cls) for col, cls in model.columns.items()},
    )


def observable_schema(
    organ: str, edition: Edition | str
) -> dict[str, ObservableSpec]:
    """Per-observable schema for the derivation layer.

    Returns name -> ObservableSpec with type/unit/values/default/
    description/label/choices. This is the canonical input for an LM
    prompt that needs to ask "what observations should I extract?".

    Examples:
        >>> schema = tnmhelper.observable_schema('lung', 'AJCC 9')
        >>> list(schema)[:3]
        ['size_cm', 'histology', 'visceral_pleura_invasion']
        >>> schema['size_cm'].type, schema['size_cm'].unit
        ('number', 'cm')
        >>> schema['histology'].values[:2]
        ('squamous_in_situ', 'adeno_in_situ')

    Raises:
        KeyError: if no derivation is registered for (organ, edition).
    """
    _ensure_initialized()
    from tnmhelper.backend import derive as derive_mod
    ed = _coerce_edition(edition)
    deriv = derive_mod.DERIVATIONS.get((organ, ed))
    if deriv is None:
        raise KeyError(f"no derivation for ({organ!r}, {ed.value!r})")
    out: dict[str, ObservableSpec] = {}
    for name, obs in deriv.observables.items():
        out[name] = ObservableSpec(
            name=obs.name,
            type=obs.type_,
            unit=obs.unit,
            description=obs.description,
            values=obs.values,
            default=obs.default if obs.has_default else None,
            has_default=obs.has_default,
            label=derive_mod.observable_label(obs),
            choices=(
                {v: derive_mod.choice_label(obs, v) for v in obs.values}
                if obs.values is not None
                else None
            ),
        )
    return out


# ---------------------------------------------------------------------------
# Compute
# ---------------------------------------------------------------------------


def stage(organ: str, edition: Edition | str, **column_values: str) -> DerivedStage:
    """Direct TNM-state -> Stage (wraps engine.explain_stage).

    Every column from `model_spec(organ, edition).columns` must be
    passed as a string keyword argument from that column's `values`
    tuple. Returns a DerivedStage with full state + stage + source.

    Examples:
        >>> out = tnmhelper.stage('lung', 'AJCC 9',
        ...     T='T1a', N='N0', M='M0',
        ...     Classification='c', DescY='No', DescR='No', DescM='No')
        >>> out.stage
        'IA1'
        >>> out.source
        'ajcc9/lung/rules.csv:row5'

    Raises:
        KeyError: if no model is registered for (organ, edition).
        ValueError: if any column is missing, extra, or has an invalid literal.
    """
    _ensure_initialized()
    from tnmhelper.backend import engine as engine_mod
    from tnmhelper.models import MODEL_REGISTRY
    ed = _coerce_edition(edition)
    model = MODEL_REGISTRY.get((organ, ed))
    if model is None:
        raise KeyError(f"no model for ({organ!r}, {ed.value!r})")
    missing = sorted(set(model.columns) - set(column_values))
    extra = sorted(set(column_values) - set(model.columns))
    if missing or extra:
        raise ValueError(
            f"field mismatch: missing={missing} extra={extra} "
            f"expected={list(model.columns)}"
        )
    state = model.state_cls(**{
        col: model.columns[col](column_values[col]) for col in model.columns
    })
    stage_value, source = engine_mod.explain_stage(organ, ed, state)
    return DerivedStage(
        organ=organ,
        edition=ed.value,
        T=column_values.get("T", ""),
        N=column_values.get("N", ""),
        M=column_values.get("M", ""),
        stage=stage_value,
        source=source,
        state={col: getattr(state, col).value for col in model.columns},
    )


def derive_tnm(
    organ: str,
    edition: Edition | str,
    observations: dict[str, Any],
    *,
    pass_through: dict[str, Any] | None = None,
) -> dict[str, str]:
    """Observations -> {'T', 'N', 'M'}. No staging step.

    Useful when you want just the derived TNM codes (e.g. to fill a
    structured report field) without computing the AJCC stage group.

    Examples:
        >>> tnmhelper.derive_tnm('lung', 'AJCC 9', {'size_cm': 1.5})
        {'T': 'T1b', 'N': 'N0', 'M': 'M0'}
        >>> tnmhelper.derive_tnm('stomach', 'AJCC 8',
        ...     {'depth_of_invasion': 'submucosa', 'positive_node_count': 1})
        {'T': 'T1b', 'N': 'N1', 'M': 'M0'}

    Args:
        observations: observable name -> value (string for enums,
            number for numerics, bool for bools).
        pass_through: optional dict of pass-through column values used
            by derivation rules that branch on `$Classification` etc.
    """
    _ensure_initialized()
    from tnmhelper.backend import derive as derive_mod
    ed = _coerce_edition(edition)
    return derive_mod.derive_tnm(organ, ed, observations, pass_through=pass_through)


def stage_from_observations(
    organ: str,
    edition: Edition | str,
    observations: dict[str, Any],
    **pass_through: Any,
) -> DerivedStage:
    """Observations -> T/N/M -> Stage. The end-to-end hot path.

    `observations` is a dict of observable name -> value (string for
    enums, number for numerics, bool for bools). `pass_through` kwargs
    cover the non-derived columns (Classification, descriptors,
    biomarkers, etc.).

    Examples:
        >>> out = tnmhelper.stage_from_observations(
        ...     'lung', 'AJCC 9',
        ...     {'size_cm': 1.5},
        ...     Classification='c', DescY='No', DescR='No', DescM='No')
        >>> out.T, out.N, out.M, out.stage
        ('T1b', 'N0', 'M0', 'IA2')

        >>> # Missing pass-through field raises:
        >>> tnmhelper.stage_from_observations('lung', 'AJCC 9', {'size_cm': 1.5})
        Traceback (most recent call last):
        ...
        tnmhelper.backend.derive.DerivationError: ...missing pass-through field 'Classification'...

    Raises:
        DerivationError: if observations / pass_through are insufficient.
    """
    _ensure_initialized()
    from tnmhelper.backend import derive as derive_mod
    from tnmhelper.models import MODEL_REGISTRY
    ed = _coerce_edition(edition)
    stage_value, source, state = derive_mod.stage_from_observations(
        organ, ed, observations, **pass_through
    )
    model = MODEL_REGISTRY[(organ, ed)]
    state_dict = {col: getattr(state, col).value for col in model.columns}
    return DerivedStage(
        organ=organ,
        edition=ed.value,
        T=state_dict.get("T", ""),
        N=state_dict.get("N", ""),
        M=state_dict.get("M", ""),
        stage=stage_value,
        source=source,
        state=state_dict,
    )


def explain(organ: str, edition: Edition | str, **column_values: str) -> tuple[str, str]:
    """Wraps engine.explain_stage: returns (stage, source).

    Convenience for callers who want just the stage string and the
    matching CSV row reference, without the full DerivedStage payload.

    Examples:
        >>> tnmhelper.explain('lung', 'AJCC 9',
        ...     T='T1a', N='N0', M='M0',
        ...     Classification='c', DescY='No', DescR='No', DescM='No')
        ('IA1', 'ajcc9/lung/rules.csv:row5')
    """
    s = stage(organ, edition, **column_values)
    return s.stage, s.source


# ---------------------------------------------------------------------------
# Display helpers (kept public; useful for any UI)
# ---------------------------------------------------------------------------


def observable_label(obs: ObservableSpec) -> str:
    return obs.label


def choice_label(obs: ObservableSpec, value: str) -> str:
    if obs.choices is not None and value in obs.choices:
        return obs.choices[value]
    from tnmhelper.backend import derive as derive_mod
    return derive_mod.humanize(value)


PASSTHROUGH_DEFAULTS = {
    "Classification": "p",
    "DescY": "No",
    "DescR": "No",
    "DescM": "No",
}


__all__ = [
    "PASSTHROUGH_DEFAULTS",
    "choice_label",
    "derive_tnm",
    "editions_for",
    "explain",
    "model_spec",
    "observable_label",
    "observable_schema",
    "organs",
    "set_data_source",
    "stage",
    "stage_from_observations",
]
