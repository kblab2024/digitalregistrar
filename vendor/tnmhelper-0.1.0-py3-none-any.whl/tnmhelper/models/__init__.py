"""Auto-discovering registry of staging models.

The per-organ `.py` model files live in the data layer (tnmhelper_data/
models/<edition_slug>/<organ>.py), not inside this package. At
runtime, `tnmhelper.set_data_source(...)` calls `install_models_path()`
to inject the active data source's models directory into this package's
`__path__`, so `pkgutil.iter_modules` finds the organ files via Python's
standard import machinery (filesystem or zipimport).

Drop a new `models/<edition>/<organ>.py` in the data tree and it shows
up in MODEL_REGISTRY with zero edits here.
"""
from __future__ import annotations

import importlib
import pkgutil

from tnmhelper.backend._shared import Biomarker, Edition, StagingModel

MODEL_REGISTRY: dict[tuple[str, Edition], StagingModel] = {}
_DISCOVERED = False


def install_models_path(path: str) -> None:
    """Point this package at the data source's models/ directory.

    Idempotent: setting the same path twice does nothing. A different
    path resets the discovery state so the next `discover()` call
    re-walks.
    """
    global _DISCOVERED, __path__
    if __path__ == [path]:
        return
    __path__ = [path]
    MODEL_REGISTRY.clear()
    _DISCOVERED = False


def discover() -> None:
    """Walk the configured `__path__`, importing every
    tnmhelper.models.<edition>.<organ> submodule and registering the
    MODEL it exports.

    Re-import-safe: if already discovered, returns immediately.
    """
    global _DISCOVERED
    if _DISCOVERED:
        return
    for _ed_info in pkgutil.iter_modules(__path__):
        if _ed_info.name.startswith("_") or not _ed_info.ispkg:
            continue
        _ed_pkg = importlib.import_module(f"{__name__}.{_ed_info.name}")
        for _info in pkgutil.iter_modules(_ed_pkg.__path__):
            if _info.name.startswith("_"):
                continue
            _mod = importlib.import_module(f"{__name__}.{_ed_info.name}.{_info.name}")
            _model = getattr(_mod, "MODEL", None)
            if _model is None:
                continue
            if not isinstance(_model, StagingModel):
                raise TypeError(
                    f"models/{_ed_info.name}/{_info.name}.py: MODEL must be a "
                    f"StagingModel, got {type(_model).__name__}"
                )
            if _model.name != _info.name:
                raise ValueError(
                    f"models/{_ed_info.name}/{_info.name}.py: MODEL.name "
                    f"{_model.name!r} must equal module filename stem "
                    f"{_info.name!r}"
                )
            if _model.edition_slug != _ed_info.name:
                raise ValueError(
                    f"models/{_ed_info.name}/{_info.name}.py: edition slug "
                    f"{_model.edition_slug!r} (from MODEL.edition "
                    f"{_model.edition.value!r}) does not match parent directory "
                    f"{_ed_info.name!r}"
                )
            _key = (_model.name, _model.edition)
            if _key in MODEL_REGISTRY:
                raise ValueError(f"duplicate StagingModel for {_key}")
            MODEL_REGISTRY[_key] = _model
    _DISCOVERED = True


def organs() -> list[str]:
    return sorted({n for (n, _) in MODEL_REGISTRY})


def editions_for(organ: str) -> list[Edition]:
    return sorted(
        (e for (n, e) in MODEL_REGISTRY if n == organ),
        key=lambda e: e.value,
    )


__all__ = [
    "Biomarker",
    "Edition",
    "MODEL_REGISTRY",
    "StagingModel",
    "discover",
    "editions_for",
    "install_models_path",
    "organs",
]
