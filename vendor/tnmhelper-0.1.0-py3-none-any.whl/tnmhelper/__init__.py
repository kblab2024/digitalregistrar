"""tnmhelper - AJCC TNM cancer staging engine.

Top-level public surface. Most consumers import from here:

    >>> import tnmhelper
    >>> tnmhelper.set_data_source(None)
    >>> tnmhelper.organs()
    ['ampulla', 'breast', ...]
    >>> tnmhelper.stage_from_observations("lung", "AJCC 9", {"size_cm": 1.5},
    ...     Classification="c", DescY="No", DescR="No", DescM="No")
"""
from __future__ import annotations

from tnmhelper.api import (
    PASSTHROUGH_DEFAULTS,
    choice_label,
    derive_tnm,
    editions_for,
    explain,
    model_spec,
    observable_label,
    observable_schema,
    organs,
    set_data_source,
    stage,
    stage_from_observations,
)
from tnmhelper.backend._shared import Biomarker, Classification, Edition, YesNo
from tnmhelper.schema import AxisRule, DerivedStage, ModelSpec, ObservableSpec

__all__ = [
    "AxisRule",
    "Biomarker",
    "Classification",
    "DerivedStage",
    "Edition",
    "ModelSpec",
    "ObservableSpec",
    "PASSTHROUGH_DEFAULTS",
    "YesNo",
    "choice_label",
    "derive_tnm",
    "editions_for",
    "explain",
    "model_spec",
    "observable_label",
    "observable_schema",
    "organs",
    "set_data_source",
    "stage",
    "stage_from_observations",
]
