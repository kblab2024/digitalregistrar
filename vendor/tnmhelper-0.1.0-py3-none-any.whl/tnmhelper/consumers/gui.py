"""TNM staging GUI (Layer 4 consumer; built on tnmhelper).

Run:
  tnmhelper-gui [--port 8080] [--host 127.0.0.1] [--data <path>]
  python -m tnmhelper.consumers.gui

Reads the observable schema for the picked (organ, edition) and renders
a form. Submit calls tnmhelper.stage_from_observations.

Install GUI deps first:
  pip install -r requirements-gui.txt
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from typing import Any

from nicegui import ui

import tnmhelper

CATEGORY_LABELS = {
    "breast": "Breast",
    "thoracic": "Thoracic",
    "head_neck": "Head & Neck",
    "gi": "Gastrointestinal",
    "hepatobiliary": "Hepatobiliary",
    "gyn": "Gynecologic",
    "urologic": "Urologic",
}


def _organs_by_category() -> dict[str, list[tuple[str, tnmhelper.Edition]]]:
    out: dict[str, list[tuple[str, tnmhelper.Edition]]] = defaultdict(list)
    for organ in tnmhelper.organs():
        for ed in tnmhelper.editions_for(organ):
            spec = tnmhelper.model_spec(organ, ed)
            out[spec.category].append((organ, ed))
    for k in out:
        out[k].sort(key=lambda t: (t[0], t[1].value))
    return dict(sorted(out.items()))


class StagingPage:
    def __init__(self) -> None:
        self.organ: str | None = None
        self.edition: tnmhelper.Edition | None = None
        self.obs_widgets: dict[str, Any] = {}
        self.pt_widgets: dict[str, Any] = {}
        self.form_container: ui.column | None = None
        self.result_container: ui.column | None = None
        self.category_buttons: dict[str, ui.button] = {}
        self.organ_picker_container: ui.column | None = None
        self.current_category: str | None = None

    def build(self) -> None:
        ui.label("TNM staging").classes("text-xl font-bold q-mb-sm")
        with ui.row().classes("w-full no-wrap items-start q-gutter-sm"):
            with ui.column().classes("w-56"):
                ui.label("Category").classes("text-lg q-mb-sm")
                for cat in _organs_by_category():
                    btn = ui.button(
                        CATEGORY_LABELS.get(cat, cat),
                        on_click=lambda _e=None, c=cat: self._pick_category(c),
                    ).props("flat align=left").classes("w-full")
                    self.category_buttons[cat] = btn
                ui.separator().classes("q-my-md")
                ui.label("Organ").classes("text-lg q-mb-sm")
                self.organ_picker_container = ui.column().classes("w-full")
                with self.organ_picker_container:
                    ui.label("(pick a category)").classes("text-grey")

            with ui.column().classes("flex-grow").style("min-width: 360px"):
                self.form_container = ui.column().classes("w-full")
                with self.form_container:
                    ui.label("Pick an organ on the left to begin staging.").classes(
                        "text-grey italic"
                    )

            with ui.column().classes("w-96"):
                ui.label("Result").classes("text-lg q-mb-sm")
                self.result_container = ui.column().classes("w-full")
                with self.result_container:
                    ui.label("Stage will appear here.").classes(
                        "text-grey italic"
                    )

    def _pick_category(self, category: str) -> None:
        self.current_category = category
        for cat, btn in self.category_buttons.items():
            if cat == category:
                btn.props("color=primary")
            else:
                btn.props(remove="color=primary").props("flat")
        assert self.organ_picker_container is not None
        self.organ_picker_container.clear()
        with self.organ_picker_container:
            organs = _organs_by_category().get(category, [])
            for organ, edition in organs:
                label = organ
                if len(tnmhelper.editions_for(organ)) > 1:
                    label = f"{organ} ({edition.value})"
                ui.button(
                    label,
                    on_click=lambda _e=None, o=organ, e=edition: self._pick_organ(o, e),
                ).props("flat align=left").classes("w-full")

    def _pick_organ(self, organ: str, edition: tnmhelper.Edition) -> None:
        self.organ = organ
        self.edition = edition
        self.obs_widgets.clear()
        self.pt_widgets.clear()
        self._render_form()

    def _render_form(self) -> None:
        assert self.form_container is not None and self.result_container is not None
        self.form_container.clear()
        self.result_container.clear()
        with self.result_container:
            ui.label("Stage will appear here.").classes("text-grey italic")
        if self.organ is None or self.edition is None:
            return
        try:
            schema = tnmhelper.observable_schema(self.organ, self.edition)
            spec = tnmhelper.model_spec(self.organ, self.edition)
        except KeyError:
            with self.form_container:
                ui.label("No derivation file for this (organ, edition).").classes("text-negative")
            return

        with self.form_container:
            ui.label(f"{self.organ} ({self.edition.value})").classes("text-xl font-bold")
            with ui.card().classes("w-full").style("padding:8px; gap:4px"):
                ui.label("Observations").classes("text-lg font-bold")
                for name, obs in schema.items():
                    self._render_observable(name, obs)

            pt_cols = [c for c in spec.columns if c not in ("T", "N", "M")]
            if pt_cols:
                with ui.card().classes("w-full q-mt-xs").style("padding:8px; gap:4px"):
                    ui.label("Classification + descriptors").classes("text-lg font-bold")
                    desc_present = [c for c in ("DescY", "DescM", "DescR") if c in pt_cols]
                    for col in pt_cols:
                        if col in desc_present:
                            continue
                        self._render_passthrough(col, spec.columns[col])
                    if desc_present:
                        self._render_descriptors(desc_present)

        self._recompute()

    def _render_observable(self, name: str, obs: tnmhelper.ObservableSpec) -> None:
        tooltip = obs.description or ""
        if obs.type == "bool":
            default = bool(obs.default) if obs.has_default else False
            w = ui.checkbox(obs.label, value=default, on_change=self._recompute).props("dense")
        else:
            self._field_label(obs.label)
            if obs.type == "number":
                default = obs.default if obs.has_default else None
                w = ui.number(value=default, on_change=self._recompute).props("dense").classes("w-full")
            elif obs.type == "enum":
                options = obs.choices or {v: v for v in (obs.values or ())}
                default = obs.default if obs.has_default else None
                w = ui.select(options=options, value=default, on_change=self._recompute).props("dense options-dense").classes("w-full")
            else:
                default = obs.default if obs.has_default else ""
                w = ui.input(value=default, on_change=self._recompute).props("dense").classes("w-full")
        if tooltip:
            w.tooltip(tooltip)
        self.obs_widgets[name] = (obs, w)

    def _render_passthrough(self, col: str, values: tuple[str, ...]) -> None:
        vlist = list(values)
        default = tnmhelper.PASSTHROUGH_DEFAULTS.get(col)
        if default not in vlist:
            default = vlist[0]
        self._field_label(col)
        w = ui.select(options=vlist, value=default, on_change=self._recompute).props("dense options-dense").classes("w-full")
        self.pt_widgets[col] = w

    @staticmethod
    def _field_label(text: str) -> None:
        ui.label(text).classes("text-base text-primary").style("margin-bottom:-4px")

    def _render_descriptors(self, cols: list[str]) -> None:
        with ui.row().classes("items-center q-gutter-sm"):
            ui.label("TNM descriptors:")
            for col in cols:
                letter = col[-1].lower()  # DescY -> y, DescM -> m, DescR -> r
                default = tnmhelper.PASSTHROUGH_DEFAULTS.get(col, "No") == "Yes"
                w = ui.checkbox(letter, value=default, on_change=self._recompute).props("dense")
                self.pt_widgets[col] = w

    def _collect_observations(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for name, (obs, w) in self.obs_widgets.items():
            v = w.value
            if v is None or v == "":
                continue
            if obs.type == "number":
                out[name] = float(v)
            else:
                out[name] = v
        return out

    def _recompute(self, _event: Any = None) -> None:
        if self.organ is None or self.edition is None or self.result_container is None:
            return
        observations = self._collect_observations()
        pass_through: dict[str, Any] = {}
        for col, w in self.pt_widgets.items():
            v = w.value
            if isinstance(v, bool):
                v = "Yes" if v else "No"
            pass_through[col] = v
        try:
            variants = self._stage_variants(observations, pass_through)
        except Exception:
            self._show_pending()
            return
        self._show_result(variants)

    def _stage_variants(
        self,
        observations: dict[str, Any],
        pass_through: dict[str, Any],
    ) -> list[tuple[str | None, tnmhelper.DerivedStage]]:
        assert self.organ is not None and self.edition is not None
        if pass_through.get("HER2") == "Equivocal":
            out: list[tuple[str | None, tnmhelper.DerivedStage]] = []
            for assumption in ("Positive", "Negative"):
                pt = {**pass_through, "HER2": assumption}
                r = tnmhelper.stage_from_observations(
                    self.organ, self.edition, observations, **pt
                )
                out.append((f"if HER2 {assumption.lower()}", r))
            return out
        r = tnmhelper.stage_from_observations(
            self.organ, self.edition, observations, **pass_through
        )
        return [(None, r)]

    def _show_pending(self) -> None:
        assert self.result_container is not None
        self.result_container.clear()
        with self.result_container:
            ui.label("Provide more inputs to compute stage.").classes("text-grey italic")

    def _show_result(
        self,
        variants: list[tuple[str | None, tnmhelper.DerivedStage]],
    ) -> None:
        assert self.result_container is not None
        self.result_container.clear()
        # Group variants that yield the same stage so we don't show identical cards.
        grouped: dict[str, tuple[tnmhelper.DerivedStage, list[str | None]]] = {}
        for label, r in variants:
            entry = grouped.setdefault(r.stage, (r, []))
            entry[1].append(label)
        with self.result_container:
            for r, labels in grouped.values():
                merged_label = ", ".join(l for l in labels if l) or None
                self._show_one_result(r, merged_label)

    def _show_one_result(
        self,
        result: tnmhelper.DerivedStage,
        assumption: str | None,
    ) -> None:
        with ui.card().classes("w-full").style("padding:8px; gap:4px"):
            if assumption:
                ui.label(assumption).classes("text-xs text-grey italic")
            ui.label(f"Stage {result.stage}").classes("text-2xl font-bold")
            with ui.row().classes("q-gutter-sm items-center"):
                for axis in ("T", "N", "M"):
                    v = result.state.get(axis, "")
                    if v:
                        ui.label(v).classes(
                            "text-lg q-px-sm q-py-xs bg-primary text-white rounded-borders"
                        )
            others = {c: v for c, v in result.state.items() if c not in ("T", "N", "M")}
            classification = others.pop("Classification", None)
            if classification:
                ui.label(f"Classification: {classification}")
            desc_letters = [
                col[-1].lower()
                for col in ("DescY", "DescM", "DescR")
                if str(others.pop(col, "No")).lower() == "yes"
            ]
            if desc_letters:
                ui.label(f"Descriptors: {' '.join(desc_letters)}")
            for c, v in others.items():
                ui.label(f"{c}: {v}")
            ui.label(result.source).classes("text-xs text-grey italic")


def _build_page() -> None:
    page = StagingPage()
    page.build()


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8080)
    p.add_argument("--show", action="store_true")
    p.add_argument("--data", default=None,
                   help="explicit data source path (dir or .zip)")
    args = p.parse_args(argv)

    tnmhelper.set_data_source(args.data)

    ui.page("/")(_build_page)
    # When frozen, auto-open the user's default browser so the .exe behaves
    # like a "double-click to launch" app. show=True triggers webbrowser.open
    # on the local URL; no pywebview / WebView2 runtime required.
    show = True if getattr(sys, "frozen", False) else args.show
    ui.run(host=args.host, port=args.port, reload=False,
           show=show, title="TNM staging")
    return 0


if __name__ in {"__main__", "__mp_main__"}:
    sys.exit(main())
