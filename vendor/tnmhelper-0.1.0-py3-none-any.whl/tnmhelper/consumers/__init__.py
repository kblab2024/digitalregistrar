"""Thin Layer-4 consumers: CLI, HTTP server, GUI.

All three are presentation layers built on top of `tnmhelper.api`.
None of them reach into the backend (engine/derive) directly.
"""
