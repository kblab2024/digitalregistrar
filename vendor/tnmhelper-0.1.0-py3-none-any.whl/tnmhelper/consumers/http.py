"""TNM staging HTTP API (Layer 4 consumer; stdlib-only).

Run:
  tnmhelper-http [--port 8000] [--host 127.0.0.1] [--data <path>]
  python -m tnmhelper.consumers.http [--port 8000]

Endpoints:
  GET  /models                                  -> {organ: {edition: {col: [values]}}}
  GET  /models/<organ>                          -> [{"edition","slug"}, ...]
  GET  /models/<organ>/<edition-slug>           -> {col: [valid values, ...]}
  GET  /observables/<organ>/<edition-slug>      -> derivation schema
  POST /stage/<organ>/<edition-slug>            -> {"stage","source"}
                                                   body: JSON {col: value}
  POST /derive/<organ>/<edition-slug>           -> {"T","N","M"}
                                                   body: {"observations":{...},
                                                          "classification":...}
  POST /stage_from_observations/<organ>/<edition-slug>
                                                -> {"T","N","M","stage","source"}
                                                   body: {"observations":{...},
                                                          "pass_through":{...}}
"""
from __future__ import annotations

import argparse
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import tnmhelper
from tnmhelper.backend._shared import _edition_slug


def _slug_to_edition(slug: str) -> tnmhelper.Edition | None:
    for e in tnmhelper.Edition:
        if _edition_slug(e) == slug:
            return e
    return None


def _models_schema() -> dict:
    out: dict[str, dict] = {}
    for organ in tnmhelper.organs():
        for ed in tnmhelper.editions_for(organ):
            spec = tnmhelper.model_spec(organ, ed)
            out.setdefault(organ, {})[ed.value] = {
                col: list(values) for col, values in spec.columns.items()
            }
    return out


def _organ_editions(organ: str) -> list[dict[str, str]]:
    return [
        {"edition": e.value, "slug": _edition_slug(e)}
        for e in tnmhelper.editions_for(organ)
    ]


def _observables_payload(organ: str, edition: tnmhelper.Edition) -> tuple[int, dict]:
    try:
        schema = tnmhelper.observable_schema(organ, edition)
    except KeyError as e:
        return 404, {"error": str(e)}
    return 200, {
        "organ": organ,
        "edition": edition.value,
        "observables": {
            name: {
                "type": o.type,
                "unit": o.unit,
                "description": o.description,
                "values": list(o.values) if o.values is not None else None,
                "default": o.default,
                "has_default": o.has_default,
                "label": o.label,
                "choices": o.choices,
            }
            for name, o in schema.items()
        },
    }


def _stage_one(organ: str, edition: tnmhelper.Edition, body: dict) -> tuple[int, dict]:
    if not isinstance(body, dict):
        return 400, {"error": "request body must be a JSON object"}
    try:
        out = tnmhelper.stage(organ, edition, **body)
    except KeyError as e:
        return 404, {"error": str(e)}
    except ValueError as e:
        return 422, {"error": str(e)}
    return 200, {"stage": out.stage, "source": out.source}


def _derive_one(organ: str, edition: tnmhelper.Edition, body: dict) -> tuple[int, dict]:
    if not isinstance(body, dict):
        return 400, {"error": "request body must be a JSON object"}
    observations = body.get("observations") or {}
    if not isinstance(observations, dict):
        return 422, {"error": "'observations' must be an object"}
    classification = body.get("classification")
    pass_through = dict(body.get("pass_through") or {})
    if classification is not None and "Classification" not in pass_through:
        pass_through["Classification"] = classification
    try:
        out = tnmhelper.derive_tnm(organ, edition, observations, pass_through=pass_through)
    except Exception as e:
        return 422, {"error": str(e)}
    return 200, out


def _stage_from_obs_one(organ: str, edition: tnmhelper.Edition, body: dict) -> tuple[int, dict]:
    if not isinstance(body, dict):
        return 400, {"error": "request body must be a JSON object"}
    observations = body.get("observations") or {}
    pass_through = body.get("pass_through") or {}
    if not isinstance(observations, dict) or not isinstance(pass_through, dict):
        return 422, {"error": "'observations' and 'pass_through' must be objects"}
    try:
        out = tnmhelper.stage_from_observations(
            organ, edition, observations, **pass_through
        )
    except Exception as e:
        return 422, {"error": str(e)}
    return 200, {"T": out.T, "N": out.N, "M": out.M, "stage": out.stage, "source": out.source}


class Handler(BaseHTTPRequestHandler):
    def _send_json(self, status: int, payload) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args) -> None:
        sys.stderr.write(f"{self.address_string()} - {fmt % args}\n")

    def _resolve_organ_edition(self, tail: str):
        parts = tail.split("/", 1)
        if len(parts) != 2:
            return 400, {"error": "URL must be /<route>/<organ>/<edition-slug>"}
        organ, slug = parts
        edition = _slug_to_edition(slug)
        if edition is None:
            return 404, {
                "error": f"unknown edition slug: {slug!r}",
                "known_slugs": [_edition_slug(e) for e in tnmhelper.Edition],
            }
        return organ, edition

    def do_GET(self) -> None:
        if self.path == "/models":
            self._send_json(200, _models_schema())
            return
        if self.path.startswith("/observables/"):
            resolved = self._resolve_organ_edition(self.path[len("/observables/"):])
            if isinstance(resolved[0], int):
                self._send_json(*resolved)
                return
            organ, edition = resolved
            status, payload = _observables_payload(organ, edition)
            self._send_json(status, payload)
            return
        if self.path.startswith("/models/"):
            tail = self.path[len("/models/"):]
            parts = tail.split("/", 1)
            organ = parts[0]
            editions = tnmhelper.editions_for(organ)
            if not editions:
                self._send_json(404, {"error": f"unknown organ: {organ!r}"})
                return
            if len(parts) == 1:
                self._send_json(200, _organ_editions(organ))
                return
            slug = parts[1]
            edition = _slug_to_edition(slug)
            if edition is None or edition not in editions:
                self._send_json(404, {
                    "error": f"unknown edition {slug!r} for organ {organ!r}",
                    "available_editions": [e.value for e in editions],
                })
                return
            spec = tnmhelper.model_spec(organ, edition)
            self._send_json(200, {col: list(values) for col, values in spec.columns.items()})
            return
        self._send_json(404, {
            "error": "not found",
            "routes": [
                "GET /models",
                "GET /models/<organ>",
                "GET /models/<organ>/<edition-slug>",
                "GET /observables/<organ>/<edition-slug>",
                "POST /stage/<organ>/<edition-slug>",
                "POST /derive/<organ>/<edition-slug>",
                "POST /stage_from_observations/<organ>/<edition-slug>",
            ],
        })

    def do_POST(self) -> None:
        handlers = {
            "/stage/": _stage_one,
            "/derive/": _derive_one,
            "/stage_from_observations/": _stage_from_obs_one,
        }
        for prefix, handler in handlers.items():
            if self.path.startswith(prefix):
                resolved = self._resolve_organ_edition(self.path[len(prefix):])
                if isinstance(resolved[0], int):
                    self._send_json(*resolved)
                    return
                organ, edition = resolved
                length = int(self.headers.get("content-length") or 0)
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw) if raw else {}
                except json.JSONDecodeError as e:
                    self._send_json(400, {"error": f"invalid JSON: {e}"})
                    return
                status, payload = handler(organ, edition, body)
                self._send_json(status, payload)
                return
        self._send_json(404, {"error": "not found"})


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--data", default=None,
                   help="explicit data source path (dir or .zip)")
    args = p.parse_args(argv)

    tnmhelper.set_data_source(args.data)

    n_organs = sum(1 for _ in tnmhelper.organs())
    print(f"Loaded {n_organs} organs from {tnmhelper.api._DATA_SOURCE}")
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Listening on http://{args.host}:{args.port}", file=sys.stderr)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nshutting down", file=sys.stderr)
        server.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
