"""TNM staging CLI (Layer 4 consumer; routes through tnmhelper).

Subcommands:
  list                                     list registered (organ, edition) pairs
  editions <organ>                         list editions for one organ
  describe <organ> --edition "AJCC 8"      show column schema
  stage <organ> --edition ... --T T1 ...   TNM -> stage (optional --explain)
  observables <organ> --edition ...        show derivation observables
  derive <organ> --edition ... --obs-json '{...}'           observations -> T/N/M
  stage-from-obs <organ> --edition ... --obs-json '{...}'   observations -> stage
                          --Classification c --DescY No ...
  interactive [organ] [--edition]          prompted form-fill loop

Entry point: `tnmhelper` (via pyproject) or `python -m tnmhelper.consumers.cli`.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import tnmhelper


def _resolve_edition(value: str) -> tnmhelper.Edition | None:
    try:
        return tnmhelper.Edition(value)
    except ValueError:
        print(f"unknown edition: {value!r}. Known: {[e.value for e in tnmhelper.Edition]}",
              file=sys.stderr)
        return None


def cmd_list() -> int:
    for organ in tnmhelper.organs():
        for ed in tnmhelper.editions_for(organ):
            print(f"{organ}\t{ed.value}")
    return 0


def cmd_editions(organ: str) -> int:
    eds = tnmhelper.editions_for(organ)
    if not eds:
        print(f"unknown organ: {organ!r}", file=sys.stderr)
        return 2
    for e in eds:
        print(e.value)
    return 0


def cmd_describe(organ: str, edition_value: str) -> int:
    edition = _resolve_edition(edition_value)
    if edition is None:
        return 2
    try:
        spec = tnmhelper.model_spec(organ, edition)
    except KeyError as e:
        print(str(e), file=sys.stderr)
        return 2
    print(f"{organ} ({spec.edition}) [{spec.category}]: {len(spec.columns)} columns")
    for col, values in spec.columns.items():
        print(f"  --{col:<14}: {', '.join(values)}")
    return 0


def cmd_observables(organ: str, edition_value: str) -> int:
    edition = _resolve_edition(edition_value)
    if edition is None:
        return 2
    try:
        schema = tnmhelper.observable_schema(organ, edition)
    except KeyError as e:
        print(str(e), file=sys.stderr)
        return 2
    print(f"{organ} ({edition.value}): {len(schema)} observables")
    for name, obs in schema.items():
        bits = [obs.type]
        if obs.unit:
            bits.append(f"unit={obs.unit}")
        if obs.has_default:
            bits.append(f"default={obs.default!r}")
        print(f"  {obs.label}  [{name}]: {', '.join(bits)}")
        if obs.description:
            print(f"      {obs.description}")
        if obs.values is not None:
            for v in obs.values:
                clabel = obs.choices.get(v, v) if obs.choices else v
                marker = " (default)" if obs.has_default and v == obs.default else ""
                if clabel == v:
                    print(f"        - {v}{marker}")
                else:
                    print(f"        - {clabel} [{v}]{marker}")
    return 0


def _load_obs_arg(obs_json: str | None, obs_file: str | None) -> dict:
    if obs_json and obs_file:
        raise ValueError("use only one of --obs-json / --obs-file")
    if obs_json:
        return json.loads(obs_json)
    if obs_file:
        return json.loads(Path(obs_file).read_text(encoding="utf-8"))
    return {}


def cmd_derive(organ: str, edition_value: str, obs_json: str | None,
               obs_file: str | None, classification: str | None) -> int:
    edition = _resolve_edition(edition_value)
    if edition is None:
        return 2
    try:
        observations = _load_obs_arg(obs_json, obs_file)
    except (ValueError, json.JSONDecodeError) as e:
        print(f"invalid observations: {e}", file=sys.stderr)
        return 2
    pass_through = {"Classification": classification} if classification else None
    out = tnmhelper.derive_tnm(organ, edition, observations, pass_through=pass_through)
    print(f"{out['T']}\t{out['N']}\t{out['M']}")
    return 0


def cmd_stage_from_obs(organ: str, edition_value: str, obs_json: str | None,
                       obs_file: str | None, rest: list[str]) -> int:
    edition = _resolve_edition(edition_value)
    if edition is None:
        return 2
    try:
        observations = _load_obs_arg(obs_json, obs_file)
    except (ValueError, json.JSONDecodeError) as e:
        print(f"invalid observations: {e}", file=sys.stderr)
        return 2
    try:
        spec = tnmhelper.model_spec(organ, edition)
    except KeyError as e:
        print(str(e), file=sys.stderr)
        return 2

    pass_cols = [c for c in spec.columns if c not in ("T", "N", "M")]
    p = argparse.ArgumentParser(
        prog=f"tnmhelper stage-from-obs {organ} --edition {edition_value!r}",
        add_help=False,
    )
    for col in pass_cols:
        p.add_argument(f"--{col}", required=True, choices=list(spec.columns[col]))
    args = p.parse_args(rest)
    pass_through = {col: getattr(args, col) for col in pass_cols}

    try:
        out = tnmhelper.stage_from_observations(
            organ, edition, observations, **pass_through
        )
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    derived = "\t".join(f"{c}={out.state[c]}" for c in ("T", "N", "M") if c in spec.columns)
    print(f"{derived}\tstage={out.stage}\tsource={out.source}")
    return 0


def cmd_stage(organ: str, edition_value: str, rest: list[str], explain: bool) -> int:
    edition = _resolve_edition(edition_value)
    if edition is None:
        return 2
    try:
        spec = tnmhelper.model_spec(organ, edition)
    except KeyError as e:
        print(str(e), file=sys.stderr)
        return 2

    p = argparse.ArgumentParser(
        prog=f"tnmhelper stage {organ} --edition {edition_value!r}", add_help=False
    )
    for col, values in spec.columns.items():
        p.add_argument(f"--{col}", required=True, choices=list(values))
    args = p.parse_args(rest)

    kwargs = {col: getattr(args, col) for col in spec.columns}
    out = tnmhelper.stage(organ, edition, **kwargs)
    if explain:
        print(f"{out.stage}\t{out.source}")
    else:
        print(out.stage)
    return 0


def _prompt(text: str) -> str:
    try:
        return input(text)
    except (EOFError, KeyboardInterrupt):
        print()
        return "q"


def _pick_organ_edition() -> tuple[str, tnmhelper.Edition] | None:
    pairs = [
        (o, e) for o in tnmhelper.organs() for e in tnmhelper.editions_for(o)
    ]
    print()
    print("Available (organ, edition):")
    for i, (organ, edition) in enumerate(pairs, start=1):
        print(f"  {i:>2}. {organ} ({edition.value})")
    while True:
        raw = _prompt("Pick number or organ name (or 'q' to quit): ").strip()
        if not raw or raw.lower() in ("q", "quit", "exit"):
            return None
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(pairs):
                return pairs[idx]
        matches = [(o, e) for (o, e) in pairs if o == raw or f"{o} ({e.value})" == raw]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            print(f"  '{raw}' matches multiple editions; pick a number.")
            continue
        print(f"  no match for {raw!r}; try again.")


def _prompt_observable(obs):
    header = f"  {obs.label}  [{obs.name}] ({obs.type}"
    if obs.has_default:
        header += f", default={obs.default!r}"
    header += ")"
    print(header)
    if obs.description:
        print(f"      {obs.description}")
    if obs.type == "enum":
        choices = list(obs.values or ())
        print("      choices:")
        for i, v in enumerate(choices, start=1):
            mark = " (default)" if obs.has_default and v == obs.default else ""
            clabel = obs.choices.get(v, v) if obs.choices else v
            if clabel == v:
                print(f"        {i:>2}. {v}{mark}")
            else:
                print(f"        {i:>2}. {clabel} [{v}]{mark}")
    while True:
        suffix = "[Enter to skip] " if obs.has_default or obs.type != "number" else ""
        raw = _prompt(f"      > {suffix}").strip()
        if not raw:
            return False, None
        if raw.lower() in ("q", "quit"):
            raise KeyboardInterrupt
        try:
            if obs.type == "number":
                return True, float(raw)
            if obs.type == "bool":
                if raw.lower() in ("y", "yes", "true", "1"):
                    return True, True
                if raw.lower() in ("n", "no", "false", "0"):
                    return True, False
                print(f"      expected y/n; got {raw!r}")
                continue
            if obs.type == "enum":
                values = list(obs.values or ())
                if raw.isdigit():
                    idx = int(raw) - 1
                    if 0 <= idx < len(values):
                        return True, values[idx]
                if raw in values:
                    return True, raw
                print(f"      expected one of {values} or 1..{len(values)}")
                continue
            return True, raw
        except ValueError as e:
            print(f"      invalid {obs.type}: {e}")


def _prompt_passthrough(col: str, values: tuple[str, ...]) -> str | None:
    default = tnmhelper.PASSTHROUGH_DEFAULTS.get(col)
    if default is not None and default not in values:
        default = None
    header = f"  {col}"
    if default is not None:
        header += f" (default={default!r})"
    print(header)
    for i, v in enumerate(values, start=1):
        mark = " (default)" if v == default else ""
        print(f"        {i:>2}. {v}{mark}")
    while True:
        suffix = "[Enter to accept default] " if default is not None else ""
        raw = _prompt(f"      > {suffix}").strip()
        if not raw:
            if default is not None:
                return default
            print("      pass-through fields are required; type a number or value.")
            continue
        if raw.lower() in ("q", "quit"):
            return None
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(values):
                return values[idx]
        if raw in values:
            return raw
        print(f"      expected one of {list(values)} or 1..{len(values)}")


def cmd_interactive(organ: str | None, edition_value: str | None) -> int:
    if organ and edition_value:
        edition = _resolve_edition(edition_value)
        if edition is None:
            return 2
        try:
            tnmhelper.model_spec(organ, edition)
        except KeyError as e:
            print(str(e), file=sys.stderr)
            return 2
        choice: tuple[str, tnmhelper.Edition] | None = (organ, edition)
    else:
        choice = _pick_organ_edition()
        if choice is None:
            return 0

    organ, edition = choice
    try:
        schema = tnmhelper.observable_schema(organ, edition)
        spec = tnmhelper.model_spec(organ, edition)
    except KeyError as e:
        print(str(e), file=sys.stderr)
        return 2

    print()
    print(f"=== {organ} ({edition.value}) ===")
    case_num = 0
    while True:
        case_num += 1
        print()
        print(f"--- case #{case_num}: enter observations (Enter to skip) ---")
        observations: dict[str, object] = {}
        try:
            for obs in schema.values():
                provided, value = _prompt_observable(obs)
                if provided:
                    observations[obs.name] = value
        except KeyboardInterrupt:
            print("\nquit.")
            return 0

        pass_cols = [c for c in spec.columns if c not in ("T", "N", "M")]
        pass_through: dict[str, str] = {}
        if pass_cols:
            print()
            print(f"--- case #{case_num}: pass-through fields ---")
            for col in pass_cols:
                value = _prompt_passthrough(col, spec.columns[col])
                if value is None:
                    print("quit.")
                    return 0
                pass_through[col] = value

        try:
            out = tnmhelper.stage_from_observations(
                organ, edition, observations, **pass_through
            )
        except Exception as e:
            print(f"\nerror: {e}")
            print("(try again -- case not staged)")
            continue

        print()
        print(f"--- case #{case_num}: result ---")
        derived_summary = ", ".join(f"{c}={out.state[c]}" for c in spec.columns)
        print(f"  derived:  {derived_summary}")
        print(f"  stage:    {out.stage}")
        print(f"  source:   {out.source}")

        print()
        again = _prompt("Stage another case? [Y/n/o (other organ)/q]: ").strip().lower()
        if again in ("q", "quit", "exit", "n", "no"):
            return 0
        if again in ("o", "other"):
            return cmd_interactive(None, None)


def main(argv: list[str] | None = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    argv = sys.argv[1:] if argv is None else argv

    top = argparse.ArgumentParser(prog="tnmhelper", description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    top.add_argument("--data", default=None,
                     help="explicit data source path (dir or .zip); "
                          "defaults to TNMHELPER_DATA env, packaged bundle, or ./tnmhelper_data/")
    sub = top.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list")
    p_eds = sub.add_parser("editions")
    p_eds.add_argument("organ")
    p_d = sub.add_parser("describe")
    p_d.add_argument("organ")
    p_d.add_argument("--edition", required=True)
    p_s = sub.add_parser("stage")
    p_s.add_argument("organ")
    p_s.add_argument("--edition", required=True)
    p_s.add_argument("--explain", action="store_true")
    p_o = sub.add_parser("observables")
    p_o.add_argument("organ")
    p_o.add_argument("--edition", required=True)
    p_dv = sub.add_parser("derive")
    p_dv.add_argument("organ")
    p_dv.add_argument("--edition", required=True)
    p_dv.add_argument("--obs-json")
    p_dv.add_argument("--obs-file")
    p_dv.add_argument("--classification", default=None)
    p_sfo = sub.add_parser("stage-from-obs")
    p_sfo.add_argument("organ")
    p_sfo.add_argument("--edition", required=True)
    p_sfo.add_argument("--obs-json")
    p_sfo.add_argument("--obs-file")
    p_int = sub.add_parser("interactive")
    p_int.add_argument("organ", nargs="?", default=None)
    p_int.add_argument("--edition", default=None)

    args, rest = top.parse_known_args(argv)
    tnmhelper.set_data_source(args.data)

    if args.cmd == "list":
        return cmd_list()
    if args.cmd == "editions":
        return cmd_editions(args.organ)
    if args.cmd == "describe":
        return cmd_describe(args.organ, args.edition)
    if args.cmd == "stage":
        return cmd_stage(args.organ, args.edition, rest, args.explain)
    if args.cmd == "observables":
        return cmd_observables(args.organ, args.edition)
    if args.cmd == "derive":
        return cmd_derive(args.organ, args.edition, args.obs_json,
                          args.obs_file, args.classification)
    if args.cmd == "stage-from-obs":
        return cmd_stage_from_obs(args.organ, args.edition, args.obs_json,
                                  args.obs_file, rest)
    if args.cmd == "interactive":
        return cmd_interactive(args.organ, args.edition)
    return 1


if __name__ == "__main__":
    sys.exit(main())
