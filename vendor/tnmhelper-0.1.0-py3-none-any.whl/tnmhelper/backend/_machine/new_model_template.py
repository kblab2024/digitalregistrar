"""Copy this file to models/<edition_slug>/<name>.py and edit. Do NOT
leave it in _machine/.

Steps:
  1. Copy to models/<edition_slug>/<name>.py (e.g. models/ajcc8/colon.py).
     - filename stem MUST equal MODEL.name below
     - parent directory MUST equal MODEL.edition_slug (e.g. "ajcc8")
  2. Replace every TODO: marker.
  3. Create the matching data/<edition_slug>/<name>_rules_human.csv
     (header = columns + Stage).
  4. Create the matching criteria/<edition_slug>/<name>.json with
     "edition" set to MODEL.edition.value (e.g. "AJCC 8").
  5. Create the matching derivations/<edition_slug>/<name>.json with
     observables and per-axis rules. See ../derivations/README.md.
  6. Run: python build_pipeline.py && python main.py

See ../models/README.md for the full contract and
../models/ajcc9/lung.py for a minimal working reference.
"""

from enum import StrEnum
from typing import NamedTuple

from .._shared import Edition, StagingModel
# from .._shared import Biomarker   # TODO: uncomment if you need IHC/molecular axes


# TODO: rename TodoT/N/M, list the actual TNM literals from the staging guideline
class TodoT(StrEnum):
    TX = "TX"
    T0 = "T0"
    # ...


class TodoN(StrEnum):
    NX = "NX"
    N0 = "N0"
    # ...


class TodoM(StrEnum):
    M0 = "M0"
    M1 = "M1"


# TODO: rename TodoState; add organ-specific extras (Grade, biomarkers, ...) AFTER T/N/M
class TodoState(NamedTuple):
    T: TodoT
    N: TodoN
    M: TodoM


MODEL = StagingModel(
    name="todo",                                       # TODO: replace with the organ name (lowercase, matches filename stem)
    edition=Edition.AJCC_8,                            # TODO: pick the AJCC edition; MUST match parent dir slug (ajcc7/ajcc8/ajcc9)
    state_cls=TodoState,                               # TODO: rename
    columns={                                          # TODO: keys MUST equal TodoState._fields in the same order
        "T": TodoT,
        "N": TodoN,
        "M": TodoM,
    },
    examples=(                                         # TODO: at least one (label, state, expected_stage) smoke test
        # ("early-stage example",
        #  TodoState(TodoT.T1, TodoN.N0, TodoM.M0), "IA"),
    ),
)
