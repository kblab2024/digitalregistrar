"""Sanity-check that each criteria/<edition_slug>/<organ>.json:
  - top-level organ matches MODEL.name
  - top-level edition matches MODEL.edition.value
  - $schema_version == 1
  - every category code exists as a .value on the matching StrEnum
  - every footnote ref resolves; every defined note is referenced

Run from repo root: `python _machine/_validate_criteria.py`

Note: the criteria<->model edition consistency check is ALSO enforced
by build_pipeline.validate_all() (and will hard-fail there). This
script is the standalone equivalent that only inspects criteria/ and
its matching MODEL_REGISTRY entries.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models import MODEL_REGISTRY  # noqa: E402
from models._shared import Edition, _edition_slug  # noqa: E402

CRITERIA_DIR = Path("criteria")
SCHEMA_VERSION = 1


def _slug_to_edition(slug: str) -> Edition | None:
    for e in Edition:
        if _edition_slug(e) == slug:
            return e
    return None


def validate_one(path: Path) -> list[str]:
    errors: list[str] = []
    edition_slug = path.parent.name
    organ = path.stem

    edition = _slug_to_edition(edition_slug)
    if edition is None:
        return [
            f"{path}: parent directory {edition_slug!r} is not a known "
            f"edition slug (expected one of: "
            f"{[_edition_slug(e) for e in Edition]})"
        ]

    model = MODEL_REGISTRY.get((organ, edition))
    if model is None:
        return [
            f"{path}: no model registered for ({organ!r}, "
            f"{edition.value!r})"
        ]

    doc = json.loads(path.read_text(encoding="utf-8"))
    if doc.get("$schema_version") != SCHEMA_VERSION:
        errors.append(f"{path}: $schema_version != {SCHEMA_VERSION}")
    if doc.get("organ") != model.name:
        errors.append(
            f"{path}: organ {doc.get('organ')!r} != model name {model.name!r}"
        )
    if doc.get("edition") != model.edition.value:
        errors.append(
            f"{path}: edition {doc.get('edition')!r} != model edition "
            f"{model.edition.value!r}"
        )

    json_axes = set(doc["axes"].keys())
    model_axes = set(model.columns.keys())
    for missing in model_axes - json_axes:
        errors.append(
            f"{path}: model defines column {missing!r} but criteria JSON "
            f"has no axis entry"
        )
    for extra in json_axes - model_axes:
        errors.append(
            f"{path}: criteria JSON has axis {extra!r} but model has no "
            f"such column"
        )

    for axis_key in sorted(json_axes & model_axes):
        enum_cls = model.columns[axis_key]
        axis = doc["axes"][axis_key]
        valid = {e.value for e in enum_cls}
        codes = [c["code"] for c in axis["categories"]]
        for c in codes:
            if c not in valid:
                errors.append(
                    f"{path}:{axis_key}: code {c!r} not in {enum_cls.__name__}"
                )
        ref_keys = {r for c in axis["categories"] for r in c["notes"]}
        note_keys = set(axis["notes"].keys())
        for r in ref_keys - note_keys:
            errors.append(
                f"{path}:{axis_key}: footnote ref {r!r} has no matching "
                f"note text"
            )
    return errors


def main() -> int:
    files = sorted(CRITERIA_DIR.glob("*/*.json"))
    if not files:
        print("no criteria/<edition>/*.json files found")
        return 0
    total_errors = 0
    for path in files:
        errors = validate_one(path)
        if errors:
            total_errors += len(errors)
            print(f"[FAIL] {path}")
            for e in errors:
                print(f"  {e}")
        else:
            print(f"[OK]   {path}")
    return 1 if total_errors else 0


if __name__ == "__main__":
    sys.exit(main())
