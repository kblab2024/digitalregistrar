"""Lint each rules.csv + criteria.json + derivation.json triple through
the active DataProvider:
  - header matches MODEL.columns + ["Stage"]
  - every non-ANY cell is a valid StrEnum literal for its column
  - no equal-specificity rules disagree on Stage (conflict check)
  - matching criteria.json exists; its `edition` agrees with MODEL.edition
  - matching derivation.json exists and is schema-valid; all derivation
    examples pass against the loaded rules

Run: `python -m tnmhelper.backend.lint` (uses the configured data source).
"""
from __future__ import annotations

import io
import json
import math
import sys
from enum import StrEnum

import pandas as pd

from tnmhelper.backend import derive
from tnmhelper.backend._shared import KNOWN_CATEGORIES, StagingModel

MAX_ROW_EXPANSION = 2_000_000
WILDCARD = "ANY"


class ConflictError(Exception):
    pass


def _expand_row(
    row: pd.Series,
    columns: dict[str, type[StrEnum]],
    source_label: str,
) -> pd.DataFrame:
    source = f"{source_label}:row{int(row['_row'])}"
    expansion: dict[str, list[str]] = {}
    for col, enum_cls in columns.items():
        cell = row[col]
        if cell == WILDCARD:
            expansion[col] = [e.value for e in enum_cls]
        else:
            try:
                enum_cls(cell)
            except ValueError as e:
                valid = ", ".join(e.value for e in enum_cls)
                raise ValueError(
                    f"{source}: column {col!r} has invalid literal {cell!r}. "
                    f"Valid values for {enum_cls.__name__}: {valid}"
                ) from e
            expansion[col] = [cell]

    size = math.prod(len(v) for v in expansion.values())
    if size > MAX_ROW_EXPANSION:
        raise ValueError(
            f"{source}: expansion size {size:,} exceeds MAX_ROW_EXPANSION "
            f"({MAX_ROW_EXPANSION:,}). Tighten the wildcards in this row."
        )

    frame = pd.MultiIndex.from_product(
        list(expansion.values()), names=list(expansion.keys())
    ).to_frame(index=False)
    frame["Stage"] = row["Stage"]
    frame["_specificity"] = sum(1 for col in columns if row[col] != WILDCARD)
    frame["_source"] = source
    frame["_row"] = int(row["_row"])
    return frame


def _check_criteria_edition(model: StagingModel, provider) -> None:
    try:
        text = provider.read_criteria(model.name, model.edition)
    except FileNotFoundError:
        raise FileNotFoundError(
            f"Missing criteria for {model.name} {model.edition.value} "
            f"(provider: {provider!r})"
        )
    declared = json.loads(text).get("edition")
    if declared != model.edition.value:
        raise ValueError(
            f"criteria for {model.edition_slug}/{model.name}: edition {declared!r} "
            f"disagrees with MODEL.edition {model.edition.value!r}"
        )


def _validate_model(model: StagingModel, provider) -> int:
    try:
        text = provider.read_rules_csv(model.name, model.edition)
    except FileNotFoundError:
        raise FileNotFoundError(
            f"Missing rules.csv for {model.name} ({model.edition.value})"
        )

    columns = model.columns
    source_label = f"{model.edition_slug}/{model.name}/rules.csv"
    df_src = pd.read_csv(io.StringIO(text), dtype=str, keep_default_na=False)
    df_src.columns = df_src.columns.str.strip()

    required = set(columns.keys()) | {"Stage"}
    actual = set(df_src.columns)
    missing = required - actual
    extra = actual - required
    if missing or extra:
        raise ValueError(
            f"{source_label}: header mismatch. Missing: {sorted(missing)} Extra: {sorted(extra)}"
        )
    if (df_src["Stage"].str.strip() == "").any():
        bad = df_src.index[df_src["Stage"].str.strip() == ""].tolist()
        raise ValueError(f"{source_label}: empty Stage cell in source rows {[i + 2 for i in bad]}")

    df_src = df_src.copy()
    df_src["_row"] = df_src.index + 2

    parts = [_expand_row(df_src.iloc[i], columns, source_label) for i in range(len(df_src))]
    full = pd.concat(parts, ignore_index=True)

    key_cols = list(columns.keys())

    full = full.sort_values(["_specificity", "_row"], ascending=[False, True]).reset_index(
        drop=True
    )

    max_spec = full.groupby(key_cols)["_specificity"].transform("max")
    top = full[full["_specificity"] == max_spec]
    conflict_groups = top.groupby(key_cols)["Stage"].nunique()
    conflicts = conflict_groups[conflict_groups > 1]
    if not conflicts.empty:
        details = []
        for key in conflicts.index[:5]:
            key_tuple = key if isinstance(key, tuple) else (key,)
            mask = (top[key_cols] == pd.Series(dict(zip(key_cols, key_tuple)))).all(axis=1)
            offenders = top[mask][["_source", "Stage"]].drop_duplicates().to_dict("records")
            details.append(f"  key={key_tuple} -> {offenders}")
        raise ConflictError(
            f"{source_label}: equal-specificity conflicts ({len(conflicts)} key(s)):\n"
            + "\n".join(details)
        )

    return len(df_src)


def _validate_derivation(model: StagingModel, provider) -> tuple[int, int, int]:
    deriv_obj = derive.load_for_lint(model, provider)
    if deriv_obj is None:
        raise FileNotFoundError(
            f"Missing derivation for {model.name} {model.edition.value}. "
            f"Author the file or remove this check if the organ legitimately "
            f"has no measurement-based derivation."
        )

    rule_count = sum(len(rules) for rules in deriv_obj.axes.values())

    derive.DERIVATIONS[(model.name, model.edition)] = deriv_obj
    derive._INITIALIZED = True  # type: ignore[attr-defined]

    passes = fails = 0
    for idx, ex in enumerate(deriv_obj.examples):
        if not isinstance(ex, dict):
            raise ValueError(f"derivation for {model.name}: examples[{idx}] must be an object")
        observations = ex.get("observations") or {}
        expect = ex.get("expect") or {}
        label = ex.get("label", f"example[{idx}]")
        classification = ex.get("classification")
        pass_through = dict(ex.get("pass_through") or {})
        if classification is not None and "Classification" not in pass_through:
            pass_through["Classification"] = classification
        actual = derive.derive_tnm(
            model.name, model.edition, observations,
            pass_through=pass_through,
        )
        mismatches = [
            (axis, expect[axis], actual.get(axis))
            for axis in expect
            if expect[axis] != actual.get(axis)
        ]
        if mismatches:
            fails += 1
            details = "; ".join(
                f"{axis}: expected {exp!r}, got {got!r}"
                for axis, exp, got in mismatches
            )
            print(
                f"  [FAIL] {model.name} ({model.edition.value}) "
                f"derivation example: {label} -- {details}",
                file=sys.stderr,
            )
        else:
            passes += 1
    return rule_count, passes, fails


def validate_all(provider=None) -> dict[tuple[str, str], int]:
    from tnmhelper.models import MODEL_REGISTRY
    from tnmhelper.data_provider import get_provider

    if provider is None:
        provider = get_provider()

    counts: dict[tuple[str, str], int] = {}
    deriv_rule_total = 0
    deriv_pass_total = 0
    deriv_fail_total = 0
    unknown_categories: list[tuple[str, str, str]] = []
    for (organ, edition), model in sorted(
        MODEL_REGISTRY.items(), key=lambda kv: (kv[0][0], kv[0][1].value)
    ):
        _check_criteria_edition(model, provider)
        n = _validate_model(model, provider)
        counts[(organ, edition.value)] = n
        d_rules, d_pass, d_fail = _validate_derivation(model, provider)
        deriv_rule_total += d_rules
        deriv_pass_total += d_pass
        deriv_fail_total += d_fail
        if model.category not in KNOWN_CATEGORIES:
            unknown_categories.append((organ, edition.value, model.category))
        print(
            f"Validated {organ} ({edition.value}) [{model.category}]: {n:,} stage rules, "
            f"{d_rules} derivation rules, {d_pass}/{d_pass + d_fail} examples PASS"
        )

    if unknown_categories:
        print(
            f"WARN: {len(unknown_categories)} model(s) declare a category "
            f"not in KNOWN_CATEGORIES (typo? new vocabulary?): "
            f"{unknown_categories}"
        )

    print(
        f"Derivations validated: {len(MODEL_REGISTRY)}/{len(MODEL_REGISTRY)}. "
        f"Total derivation rules: {deriv_rule_total}. "
        f"Examples: {deriv_pass_total} PASS, {deriv_fail_total} FAIL."
    )
    if deriv_fail_total:
        raise ValueError(f"{deriv_fail_total} derivation example(s) failed")
    return counts


def main() -> int:
    import tnmhelper
    tnmhelper.set_data_source(None)
    try:
        validate_all()
    except (ValueError, ConflictError, FileNotFoundError, derive.DerivationError) as e:
        print(f"VALIDATION FAILED: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
