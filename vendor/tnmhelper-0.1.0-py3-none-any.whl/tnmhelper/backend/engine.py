"""Rule-walker engine: TNM state -> Stage.

Reads rules.csv through a DataProvider (filesystem dir or zip bundle).
The provider abstracts the data source so engine.py never opens a Path
directly.
"""
from __future__ import annotations

import csv
import io
from typing import NamedTuple, NamedTuple as _NamedTuple

from tnmhelper.backend._shared import Edition

WILDCARD = "ANY"

# State-side aliases: when the state cell is the key, it also matches
# rule cells equal to the value. Used so that an unknown nodal status
# (NX, the derivation sentinel) still stages as if it were N0, which is
# the clinical convention for AJCC stage groupings.
STATE_ALIASES: dict[str, str] = {"NX": "N0"}


def _cell_matches(rule_cell: str, state_cell: str) -> bool:
    if rule_cell == WILDCARD or rule_cell == state_cell:
        return True
    aliased = STATE_ALIASES.get(state_cell)
    return aliased is not None and rule_cell == aliased


class Rule(_NamedTuple):
    specificity: int
    cells: tuple[str, ...]
    stage: str
    source: str
    row_idx: int


STAGING_RULES: dict[tuple[str, Edition], list[Rule]] = {}
_INITIALIZED = False


def initialize(provider=None) -> None:
    """Load every registered model's rules.csv through the provider.

    `provider` defaults to the currently-configured global DataProvider
    (set via tnmhelper.set_data_source). Imported lazily to avoid a
    cycle with tnmhelper.models (which the provider may need to
    populate first via __path__ injection).
    """
    from tnmhelper.models import MODEL_REGISTRY
    from tnmhelper.data_provider import get_provider

    global _INITIALIZED
    if provider is None:
        provider = get_provider()
    STAGING_RULES.clear()

    for (organ, edition), model in MODEL_REGISTRY.items():
        csv_text = provider.read_rules_csv(organ, edition)
        reader = csv.reader(io.StringIO(csv_text))
        try:
            header = [h.strip() for h in next(reader)]
        except StopIteration:
            raise ValueError(
                f"{model.edition_slug}/{model.name}/rules.csv: empty file"
            )
        rows = [[(c or "") for c in row] for row in reader if row]

        required = set(model.columns) | {"Stage"}
        actual = set(header)
        missing = required - actual
        extra = actual - required
        if missing or extra:
            raise ValueError(
                f"{model.edition_slug}/{model.name}/rules.csv: header mismatch. "
                f"Missing: {sorted(missing)} Extra: {sorted(extra)}"
            )

        idx = {name: header.index(name) for name in header}
        stage_idx = idx["Stage"]
        col_order = list(model.columns)
        col_idx = [idx[c] for c in col_order]

        bad_empty = [i for i, r in enumerate(rows) if r[stage_idx].strip() == ""]
        if bad_empty:
            raise ValueError(
                f"{model.edition_slug}/{model.name}/rules.csv: empty Stage cell "
                f"in source rows {[i + 2 for i in bad_empty]}"
            )

        for col, enum_cls in model.columns.items():
            valid = {e.value for e in enum_cls}
            ci = idx[col]
            for offset, r in enumerate(rows):
                cell = r[ci]
                if cell == WILDCARD or cell in valid:
                    continue
                raise ValueError(
                    f"{model.edition_slug}/{model.name}/rules.csv:row{offset + 2}: "
                    f"column {col!r} has invalid literal {cell!r}. Valid values "
                    f"for {enum_cls.__name__}: {', '.join(sorted(valid))}"
                )

        rules: list[Rule] = []
        for offset, r in enumerate(rows):
            row_idx = offset + 2
            cells = tuple(r[i] for i in col_idx)
            spec = sum(1 for c in cells if c != WILDCARD)
            rules.append(Rule(
                specificity=spec,
                cells=cells,
                stage=r[stage_idx],
                source=f"{model.edition_slug}/{model.name}/rules.csv:row{row_idx}",
                row_idx=row_idx,
            ))
        rules.sort(key=lambda r: (-r.specificity, r.row_idx))
        STAGING_RULES[(organ, edition)] = rules

    _INITIALIZED = True


def _missing_source(organ: str, edition: Edition) -> str:
    from tnmhelper.models import editions_for
    known = [e.value for e in editions_for(organ)]
    if known:
        return f"no model for ({organ!r}, {edition.value!r}); known editions for {organ}: {known}"
    return f"no model for ({organ!r}, {edition.value!r}); no models registered for {organ!r}"


def calculate_stage(organ: str, edition: Edition, state: NamedTuple) -> str:
    if not _INITIALIZED:
        raise RuntimeError("engine.initialize() not called")
    rules = STAGING_RULES.get((organ, edition))
    if rules is None:
        return "UNKNOWN_MODEL"
    state_cells = tuple(str(c) for c in state)
    for rule in rules:
        if all(_cell_matches(rc, sc) for rc, sc in zip(rule.cells, state_cells)):
            return rule.stage
    return "UNSTAGEABLE"


def explain_stage(organ: str, edition: Edition, state: NamedTuple) -> tuple[str, str]:
    if not _INITIALIZED:
        raise RuntimeError("engine.initialize() not called")
    rules = STAGING_RULES.get((organ, edition))
    if rules is None:
        return "UNKNOWN_MODEL", _missing_source(organ, edition)
    state_cells = tuple(str(c) for c in state)
    for rule in rules:
        if all(_cell_matches(rc, sc) for rc, sc in zip(rule.cells, state_cells)):
            return rule.stage, rule.source
    return "UNSTAGEABLE", "no matching rule"
