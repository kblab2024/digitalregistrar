"""Observation -> TNM derivation layer.

Each registered model may have a sibling derivation.json describing how
to compute T/N/M from clinical observations. This module loads those
through the DataProvider, validates them against the model's StrEnums,
and exposes a small evaluation API.

Strict partial-information policy: a rule whose `when` clause references
an observable that is neither supplied by the caller nor declared with a
`default` in the file is treated as "rule does not match"; the walker
continues. If no rule matches, the axis result is the sentinel:
TX / NX / M0 (no MX exists in any organ's M enum).
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, NamedTuple

from tnmhelper.backend._shared import Classification, Edition, StagingModel

CLASSIFICATION_REF = "$classification"
PSEUDO_OBSERVABLE_PREFIX = "$"

NEVER_DERIVED = frozenset({
    "Classification", "DescY", "DescR", "DescM",
    "HER2", "ER", "PR",
})

NUMERIC_COMPARATORS = frozenset({"lt", "lte", "gt", "gte", "eq", "neq", "in", "not_in"})
BOOL_COMPARATORS = frozenset({"eq", "neq"})
ENUM_COMPARATORS = frozenset({"eq", "neq", "in", "not_in"})
STRING_COMPARATORS = frozenset({"eq", "neq", "in", "not_in"})

PASSTHROUGH_DEFAULTS: dict[str, str] = {
    "Classification": "p",
    "DescY": "No",
    "DescR": "No",
    "DescM": "No",
}


_HUMANIZE_WORD_FIXUPS: dict[str, str] = {
    "ene": "ENE",
    "doi": "depth of invasion",
    "psa": "PSA",
    "her2": "HER2",
    "er": "ER",
    "pr": "PR",
    "sma": "SMA",
    "cha": "CHA",
    "sln": "SLN",
    "ipsi": "ipsilateral",
    "contra": "contralateral",
    "le": "≤",
    "ge": "≥",
    "lt": "<",
    "gt": ">",
    "cm": "cm",
    "mm": "mm",
    "ml": "mL",
    "le3cm": "≤ 3 cm",
    "le6cm": "≤ 6 cm",
    "gt3cm": "> 3 cm",
    "gt6cm": "> 6 cm",
    "3_to_6cm": "3–6 cm",
    "neg": "negative",
    "pos": "positive",
    "fixation": "fixation",
}


def humanize_token(token: str) -> str:
    if not token:
        return token
    fixup = _HUMANIZE_WORD_FIXUPS.get(token.lower())
    if fixup is not None:
        return fixup
    return token


def humanize(name: str) -> str:
    if not name:
        return name
    tokens = name.split("_")
    pieces = [humanize_token(t) for t in tokens]
    for i, p in enumerate(pieces):
        if p and p[0].isalpha():
            pieces[i] = p[0].upper() + p[1:]
            break
    return " ".join(pieces)


def observable_label(obs: "Observable") -> str:
    if obs.display_label is not None:
        return obs.display_label
    name = obs.name
    if obs.unit:
        suffix = "_" + obs.unit.lower()
        if name.lower().endswith(suffix):
            name = name[: -len(suffix)]
    base = humanize(name)
    if obs.unit:
        return f"{base} ({obs.unit})"
    return base


def choice_label(obs: "Observable", value: str) -> str:
    if obs.display_choices is not None and value in obs.display_choices:
        return obs.display_choices[value]
    return humanize(value)


_AXIS_DEFAULT_PREFERENCES: dict[str, tuple[str, ...]] = {
    "T": ("TX", "T0"),
    "N": ("NX", "N0"),
    "M": ("M0",),
}


def _axis_default(axis: str, enum_cls: type[StrEnum]) -> str | None:
    members = [e.value for e in enum_cls]
    members_set = set(members)
    for pref in _AXIS_DEFAULT_PREFERENCES.get(axis, ()):
        if pref in members_set:
            return pref
    suffixes: tuple[str, ...] = ()
    if axis == "T":
        suffixes = ("TX", "T0")
    elif axis == "N":
        suffixes = ("NX", "N0")
    elif axis == "M":
        suffixes = ("M0",)
    for suf in suffixes:
        for v in members:
            if v.endswith(suf):
                return v
    return None


class DerivationError(Exception):
    pass


@dataclass(frozen=True)
class Observable:
    name: str
    type_: str
    unit: str | None
    description: str | None
    values: tuple[str, ...] | None
    has_default: bool
    default: Any
    display_label: str | None = None
    display_choices: dict[str, str] | None = None


@dataclass(frozen=True)
class Constraint:
    observable: str
    comparator: str
    value: Any


@dataclass(frozen=True)
class RuleClause:
    constraints: tuple[Constraint, ...]


@dataclass(frozen=True)
class Rule:
    label: str
    all_clause: RuleClause
    any_of: tuple[RuleClause, ...]
    then: str
    source: str


@dataclass(frozen=True)
class Derivation:
    organ: str
    edition: Edition
    source_path: str
    observables: dict[str, Observable]
    axes: dict[str, tuple[Rule, ...]]
    examples: tuple[dict[str, Any], ...]


DERIVATIONS: dict[tuple[str, Edition], Derivation] = {}
_INITIALIZED = False


def initialize(provider=None) -> None:
    """Discover and validate every derivation.json through the provider.

    Soft-skip files missing for registered models: a note is printed and
    that (organ, edition) simply has no derivation. Hard-fail on schema
    errors when a file IS present. Lint is the gate for "all 19 present".
    """
    from tnmhelper.models import MODEL_REGISTRY
    from tnmhelper.data_provider import get_provider

    global _INITIALIZED
    if provider is None:
        provider = get_provider()
    DERIVATIONS.clear()

    missing: list[tuple[str, Edition]] = []
    for (organ, edition), model in MODEL_REGISTRY.items():
        try:
            text = provider.read_derivation(organ, edition)
        except FileNotFoundError:
            missing.append((organ, edition))
            continue
        DERIVATIONS[(organ, edition)] = _load_one(model, text, provider.derivation_source(organ, edition))

    if missing:
        names = ", ".join(f"{o} ({e.value})" for o, e in missing)
        print(f"[derive] note: no derivation file for: {names}")

    _INITIALIZED = True


def _load_one(model: StagingModel, text: str, source_label: str) -> Derivation:
    raw = json.loads(text)

    declared_organ = raw.get("organ")
    declared_edition = raw.get("edition")
    if declared_organ != model.name:
        raise DerivationError(
            f"{source_label}: organ {declared_organ!r} disagrees with "
            f"MODEL.name {model.name!r}"
        )
    if declared_edition != model.edition.value:
        raise DerivationError(
            f"{source_label}: edition {declared_edition!r} disagrees with "
            f"MODEL.edition {model.edition.value!r}"
        )

    observables_raw = raw.get("observables") or {}
    if not isinstance(observables_raw, dict):
        raise DerivationError(f"{source_label}: 'observables' must be an object")
    observables = _compile_observables(source_label, observables_raw)

    axes_raw = raw.get("axes") or {}
    if not isinstance(axes_raw, dict):
        raise DerivationError(f"{source_label}: 'axes' must be an object")
    axes: dict[str, tuple[Rule, ...]] = {}
    for axis_name, axis_rules in axes_raw.items():
        if axis_name in NEVER_DERIVED:
            raise DerivationError(
                f"{source_label}: axis {axis_name!r} is a pass-through field "
                f"and must not be derived"
            )
        if axis_name not in model.columns:
            raise DerivationError(
                f"{source_label}: axis {axis_name!r} is not a column of MODEL "
                f"(columns: {list(model.columns)})"
            )
        enum_cls = model.columns[axis_name]
        if not isinstance(axis_rules, list):
            raise DerivationError(
                f"{source_label}: axes.{axis_name} must be a list of rules"
            )
        compiled = tuple(
            _compile_rule(source_label, axis_name, idx, rule, observables, enum_cls, model)
            for idx, rule in enumerate(axis_rules)
        )
        axes[axis_name] = compiled

    examples_raw = raw.get("examples") or []
    if not isinstance(examples_raw, list):
        raise DerivationError(f"{source_label}: 'examples' must be a list")

    return Derivation(
        organ=model.name,
        edition=model.edition,
        source_path=source_label,
        observables=observables,
        axes=axes,
        examples=tuple(examples_raw),
    )


def _compile_observables(
    source_label: str, raw: dict[str, Any]
) -> dict[str, Observable]:
    out: dict[str, Observable] = {}
    for name, spec in raw.items():
        if not isinstance(name, str) or not name:
            raise DerivationError(f"{source_label}: observable name must be a non-empty string")
        if name.startswith("$"):
            raise DerivationError(
                f"{source_label}: observable name {name!r} cannot start with '$' "
                f"(reserved for pseudo-observables)"
            )
        if not isinstance(spec, dict):
            raise DerivationError(f"{source_label}: observables.{name} must be an object")
        type_ = spec.get("type")
        if type_ not in {"number", "bool", "enum", "string"}:
            raise DerivationError(
                f"{source_label}: observables.{name}.type must be one of "
                f"number|bool|enum|string; got {type_!r}"
            )
        values: tuple[str, ...] | None = None
        if type_ == "enum":
            raw_values = spec.get("values")
            if not isinstance(raw_values, list) or not raw_values:
                raise DerivationError(
                    f"{source_label}: observables.{name} (enum) must declare non-empty 'values'"
                )
            if not all(isinstance(v, str) for v in raw_values):
                raise DerivationError(
                    f"{source_label}: observables.{name}.values must be strings"
                )
            values = tuple(raw_values)

        has_default = "default" in spec
        default = spec.get("default")
        if has_default:
            _check_value_type(source_label, f"observables.{name}.default", default, type_, values)

        display = spec.get("display")
        display_label: str | None = None
        display_choices: dict[str, str] | None = None
        if display is not None:
            if not isinstance(display, dict):
                raise DerivationError(
                    f"{source_label}: observables.{name}.display must be an object"
                )
            display_label = display.get("label")
            if display_label is not None and not isinstance(display_label, str):
                raise DerivationError(
                    f"{source_label}: observables.{name}.display.label must be a string"
                )
            raw_choices = display.get("choices")
            if raw_choices is not None:
                if type_ != "enum":
                    raise DerivationError(
                        f"{source_label}: observables.{name}.display.choices is only "
                        f"valid for enum observables; this one is {type_!r}"
                    )
                if not isinstance(raw_choices, dict):
                    raise DerivationError(
                        f"{source_label}: observables.{name}.display.choices must be an object"
                    )
                for k, v in raw_choices.items():
                    if k not in (values or ()):
                        raise DerivationError(
                            f"{source_label}: observables.{name}.display.choices key "
                            f"{k!r} is not a declared value of this enum"
                        )
                    if not isinstance(v, str):
                        raise DerivationError(
                            f"{source_label}: observables.{name}.display.choices[{k!r}] "
                            f"must be a string"
                        )
                display_choices = dict(raw_choices)

        out[name] = Observable(
            name=name,
            type_=type_,
            unit=spec.get("unit"),
            description=spec.get("description"),
            values=values,
            has_default=has_default,
            default=default,
            display_label=display_label,
            display_choices=display_choices,
        )
    return out


def _check_value_type(
    source_label: str, ctx: str, value: Any, type_: str, enum_values: tuple[str, ...] | None
) -> None:
    if type_ == "number":
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise DerivationError(f"{source_label}: {ctx} must be a number; got {value!r}")
    elif type_ == "bool":
        if not isinstance(value, bool):
            raise DerivationError(f"{source_label}: {ctx} must be a bool; got {value!r}")
    elif type_ == "enum":
        if not isinstance(value, str) or value not in (enum_values or ()):
            raise DerivationError(
                f"{source_label}: {ctx} must be one of {list(enum_values or ())}; got {value!r}"
            )
    elif type_ == "string":
        if not isinstance(value, str):
            raise DerivationError(f"{source_label}: {ctx} must be a string; got {value!r}")


def _compile_rule(
    source_label: str,
    axis: str,
    idx: int,
    raw: Any,
    observables: dict[str, Observable],
    enum_cls: type[StrEnum],
    model: StagingModel,
) -> Rule:
    if not isinstance(raw, dict):
        raise DerivationError(f"{source_label}: axes.{axis}[{idx}] must be an object")
    label = raw.get("label") or f"{axis}[{idx}]"
    then = raw.get("then")
    valid_thens = {e.value for e in enum_cls}
    if then not in valid_thens:
        raise DerivationError(
            f"{source_label}: axes.{axis}[{idx}].then = {then!r} is not a valid "
            f"value for {enum_cls.__name__}; valid: {sorted(valid_thens)}"
        )

    when = raw.get("when")
    if when is None:
        raise DerivationError(
            f"{source_label}: axes.{axis}[{idx}] missing 'when' clause"
        )
    all_clause, any_of = _compile_when(
        source_label, f"axes.{axis}[{idx}].when", when, observables, model
    )

    if not all_clause.constraints and not any_of:
        raise DerivationError(
            f"{source_label}: axes.{axis}[{idx}].when has both empty 'all' and "
            f"empty 'any_of' -- a rule must have at least one constraint"
        )

    source = f"{source_label}:axes.{axis}[{idx}] '{label}'"
    return Rule(
        label=label,
        all_clause=all_clause,
        any_of=any_of,
        then=then,
        source=source,
    )


def _compile_when(
    source_label: str,
    ctx: str,
    raw: Any,
    observables: dict[str, Observable],
    model: StagingModel,
) -> tuple[RuleClause, tuple[RuleClause, ...]]:
    if not isinstance(raw, dict):
        raise DerivationError(f"{source_label}: {ctx} must be an object")

    has_all = "all" in raw
    has_any = "any_of" in raw
    if has_all or has_any:
        unknown = set(raw) - {"all", "any_of"}
        if unknown:
            raise DerivationError(
                f"{source_label}: {ctx} has unknown keys {sorted(unknown)}; "
                f"only 'all' and 'any_of' are allowed at this level"
            )
        all_raw = raw.get("all", {})
        any_raw = raw.get("any_of", [])
    else:
        all_raw = raw
        any_raw = []

    if not isinstance(all_raw, dict):
        raise DerivationError(f"{source_label}: {ctx}.all must be an object")
    all_clause = RuleClause(constraints=_compile_clause_constraints(
        source_label, f"{ctx}.all", all_raw, observables, model
    ))

    if not isinstance(any_raw, list):
        raise DerivationError(f"{source_label}: {ctx}.any_of must be a list")
    if "any_of" in raw and len(any_raw) == 0:
        raise DerivationError(
            f"{source_label}: {ctx}.any_of is present but empty; remove it or add branches"
        )
    any_of: list[RuleClause] = []
    for i, branch in enumerate(any_raw):
        if not isinstance(branch, dict):
            raise DerivationError(f"{source_label}: {ctx}.any_of[{i}] must be an object")
        any_of.append(RuleClause(constraints=_compile_clause_constraints(
            source_label, f"{ctx}.any_of[{i}]", branch, observables, model
        )))

    return all_clause, tuple(any_of)


def _compile_clause_constraints(
    source_label: str,
    ctx: str,
    raw: dict[str, Any],
    observables: dict[str, Observable],
    model: StagingModel,
) -> tuple[Constraint, ...]:
    out: list[Constraint] = []
    for name, spec in raw.items():
        canonical = _canonical_pseudo_name(name)
        type_, enum_values = _resolve_obs_type(source_label, ctx, canonical, observables, model)
        if not isinstance(spec, dict):
            _check_value_type(source_label, f"{ctx}.{name}", spec, type_, enum_values)
            out.append(Constraint(observable=canonical, comparator="eq", value=spec))
            continue
        legal = _legal_comparators(type_)
        for cmp_, val in spec.items():
            if cmp_ not in legal:
                raise DerivationError(
                    f"{source_label}: {ctx}.{name}: comparator {cmp_!r} is not legal "
                    f"for type {type_!r}; legal: {sorted(legal)}"
                )
            if cmp_ in ("in", "not_in"):
                if not isinstance(val, list) or not val:
                    raise DerivationError(
                        f"{source_label}: {ctx}.{name}.{cmp_} must be a non-empty list"
                    )
                for item in val:
                    _check_value_type(source_label, f"{ctx}.{name}.{cmp_}[]", item, type_, enum_values)
                out.append(Constraint(observable=canonical, comparator=cmp_, value=tuple(val)))
            else:
                _check_value_type(source_label, f"{ctx}.{name}.{cmp_}", val, type_, enum_values)
                if type_ == "number":
                    val = float(val)
                out.append(Constraint(observable=canonical, comparator=cmp_, value=val))
    return tuple(out)


def _canonical_pseudo_name(name: str) -> str:
    if name == CLASSIFICATION_REF:
        return PSEUDO_OBSERVABLE_PREFIX + "Classification"
    return name


def _resolve_obs_type(
    source_label: str,
    ctx: str,
    name: str,
    observables: dict[str, Observable],
    model: StagingModel,
) -> tuple[str, tuple[str, ...] | None]:
    if name.startswith(PSEUDO_OBSERVABLE_PREFIX):
        col = name[len(PSEUDO_OBSERVABLE_PREFIX):]
        if col not in model.columns:
            raise DerivationError(
                f"{source_label}: {ctx} references pseudo-observable {name!r}, "
                f"but {col!r} is not a column of MODEL "
                f"(columns: {sorted(model.columns)})"
            )
        enum_cls = model.columns[col]
        return "enum", tuple(e.value for e in enum_cls)
    if name not in observables:
        raise DerivationError(
            f"{source_label}: {ctx} references unknown observable {name!r}; "
            f"declared: {sorted(observables)} (or use $<Column> -- e.g. "
            f"$Classification, $DescY -- to reference a pass-through field)"
        )
    obs = observables[name]
    return obs.type_, obs.values


def _legal_comparators(type_: str) -> frozenset[str]:
    return {
        "number": NUMERIC_COMPARATORS,
        "bool": BOOL_COMPARATORS,
        "enum": ENUM_COMPARATORS,
        "string": STRING_COMPARATORS,
    }[type_]


_UNRESOLVED = object()


def _resolve_observation(
    name: str,
    observations: dict[str, Any],
    deriv: Derivation,
    pass_through: dict[str, Any],
) -> Any:
    if name.startswith(PSEUDO_OBSERVABLE_PREFIX):
        col = name[len(PSEUDO_OBSERVABLE_PREFIX):]
        v = pass_through.get(col, _UNRESOLVED)
        if v is _UNRESOLVED or v is None:
            return _UNRESOLVED
        return v.value if hasattr(v, "value") else str(v)
    if name in observations:
        return observations[name]
    obs = deriv.observables.get(name)
    if obs is not None and obs.has_default:
        return obs.default
    return _UNRESOLVED


def _eval_constraint(constraint: Constraint, value: Any) -> bool:
    cmp_ = constraint.comparator
    target = constraint.value
    if cmp_ == "eq":
        return value == target
    if cmp_ == "neq":
        return value != target
    if cmp_ == "in":
        return value in target
    if cmp_ == "not_in":
        return value not in target
    if cmp_ == "lt":
        return value < target
    if cmp_ == "lte":
        return value <= target
    if cmp_ == "gt":
        return value > target
    if cmp_ == "gte":
        return value >= target
    raise DerivationError(f"unknown comparator: {cmp_!r}")


def _eval_clause(
    clause: RuleClause,
    observations: dict[str, Any],
    deriv: Derivation,
    pass_through: dict[str, Any],
) -> bool:
    for c in clause.constraints:
        v = _resolve_observation(c.observable, observations, deriv, pass_through)
        if v is _UNRESOLVED:
            return False
        if not _eval_constraint(c, v):
            return False
    return True


def _eval_rule(
    rule: Rule,
    observations: dict[str, Any],
    deriv: Derivation,
    pass_through: dict[str, Any],
) -> bool:
    if rule.all_clause.constraints:
        if not _eval_clause(rule.all_clause, observations, deriv, pass_through):
            return False
    if rule.any_of:
        return any(
            _eval_clause(branch, observations, deriv, pass_through)
            for branch in rule.any_of
        )
    return True


def _ensure_initialized() -> None:
    if not _INITIALIZED:
        raise RuntimeError("derive.initialize() not called")


def _default_for(organ: str, edition: Edition, axis: str) -> str:
    from tnmhelper.models import MODEL_REGISTRY
    model = MODEL_REGISTRY.get((organ, edition))
    if model is None or axis not in model.columns:
        return "UNKNOWN"
    sentinel = _axis_default(axis, model.columns[axis])
    return sentinel if sentinel is not None else "UNKNOWN"


def _normalize_pass_through(pass_through: dict[str, Any] | None) -> dict[str, Any]:
    if not pass_through:
        return {}
    out: dict[str, Any] = {}
    for k, v in pass_through.items():
        if v is None:
            continue
        out[k] = v.value if hasattr(v, "value") else str(v)
    return out


def derive_axis(
    organ: str,
    edition: Edition,
    axis: str,
    observations: dict[str, Any],
    classification: str | None = None,
    pass_through: dict[str, Any] | None = None,
) -> tuple[str, str | None]:
    _ensure_initialized()
    deriv = DERIVATIONS.get((organ, edition))
    if deriv is None:
        return _default_for(organ, edition, axis), None
    rules = deriv.axes.get(axis)
    if not rules:
        return _default_for(organ, edition, axis), None
    pt = _normalize_pass_through(pass_through)
    if classification is not None and "Classification" not in pt:
        pt["Classification"] = (
            classification.value if hasattr(classification, "value") else str(classification)
        )
    for rule in rules:
        if _eval_rule(rule, observations, deriv, pt):
            return rule.then, rule.source
    return _default_for(organ, edition, axis), None


def derive_tnm(
    organ: str,
    edition: Edition,
    observations: dict[str, Any],
    classification: str | None = None,
    pass_through: dict[str, Any] | None = None,
) -> dict[str, str]:
    return {
        axis: derive_axis(
            organ, edition, axis, observations, classification, pass_through
        )[0]
        for axis in ("T", "N", "M")
    }


def derive_state(
    organ: str,
    edition: Edition,
    observations: dict[str, Any],
    **pass_through: Any,
) -> NamedTuple:
    from tnmhelper.models import MODEL_REGISTRY

    _ensure_initialized()
    model = MODEL_REGISTRY.get((organ, edition))
    if model is None:
        raise DerivationError(
            f"no model for ({organ!r}, {edition.value!r}); "
            f"register a StagingModel first"
        )

    deriv = DERIVATIONS.get((organ, edition))
    derived_axes = set(deriv.axes) if deriv is not None else set()

    fields: dict[str, Any] = {}
    for col, enum_cls in model.columns.items():
        if col in derived_axes:
            value, _ = derive_axis(
                organ, edition, col, observations, pass_through=pass_through
            )
            fields[col] = enum_cls(value)
            continue
        if col in ("T", "N", "M"):
            value, _ = derive_axis(
                organ, edition, col, observations, pass_through=pass_through
            )
            if value != "UNKNOWN":
                fields[col] = enum_cls(value)
                continue
        if col not in pass_through:
            raise DerivationError(
                f"derive_state({organ!r}, {edition.value!r}): missing "
                f"pass-through field {col!r}; supply it as a keyword argument"
            )
        raw = pass_through[col]
        fields[col] = raw if isinstance(raw, enum_cls) else enum_cls(raw)

    return model.state_cls(**fields)


def stage_from_observations(
    organ: str,
    edition: Edition,
    observations: dict[str, Any],
    **pass_through: Any,
) -> tuple[str, str, NamedTuple]:
    """Returns (stage, source, state). Initializes the engine lazily
    if the caller forgot."""
    from tnmhelper.backend import engine
    if not engine._INITIALIZED:
        engine.initialize()
    state = derive_state(organ, edition, observations, **pass_through)
    stage, source = engine.explain_stage(organ, edition, state)
    return stage, source, state


def load_for_lint(model: StagingModel, provider) -> Derivation | None:
    """Used by lint: load one derivation through the provider, returning
    None if the file is missing (so lint can decide whether to fail)."""
    try:
        text = provider.read_derivation(model.name, model.edition)
    except FileNotFoundError:
        return None
    return _load_one(model, text, provider.derivation_source(model.name, model.edition))


__all__ = [
    "CLASSIFICATION_REF",
    "DERIVATIONS",
    "Derivation",
    "DerivationError",
    "NEVER_DERIVED",
    "Observable",
    "PASSTHROUGH_DEFAULTS",
    "choice_label",
    "derive_axis",
    "derive_state",
    "derive_tnm",
    "humanize",
    "initialize",
    "observable_label",
    "load_for_lint",
    "stage_from_observations",
]
