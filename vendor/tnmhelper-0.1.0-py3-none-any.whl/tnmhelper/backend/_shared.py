from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, NamedTuple


class Biomarker(StrEnum):
    POSITIVE = "Positive"
    NEGATIVE = "Negative"
    EQUIVOCAL = "Equivocal"
    UNKNOWN = "Unknown"


class YesNo(StrEnum):
    YES = "Yes"
    NO = "No"


class Classification(StrEnum):
    """Universal AJCC staging classification.

    - ANATOMIC     ('a') -- TNM-only stage group (no biomarkers/grade)
    - CLINICAL     ('c') -- pre-treatment, imaging/biopsy based
    - PATHOLOGICAL ('p') -- based on the resected specimen
    """
    ANATOMIC = "a"
    CLINICAL = "c"
    PATHOLOGICAL = "p"


class Edition(StrEnum):
    """AJCC staging manual edition.

    The .value is the canonical human-readable string used in criteria
    JSON files (`"AJCC 8"`). The edition_slug derived from it
    (`ajcc8`) is the directory name under models/, data/, criteria/.
    """
    AJCC_7 = "AJCC 7"
    AJCC_8 = "AJCC 8"
    AJCC_9 = "AJCC 9"


def _edition_slug(edition: Edition) -> str:
    return edition.value.lower().replace(" ", "")


# Canonical organ-category vocabulary. New StagingModel files SHOULD use
# one of these strings for `category` so the GUI groups them consistently.
# A free-string typo (e.g. "head-neck" vs "head_neck") would otherwise
# split the GUI group; build_pipeline.py soft-warns on unknown values.
KNOWN_CATEGORIES: frozenset[str] = frozenset({
    "breast",
    "thoracic",
    "head_neck",
    "gi",
    "hepatobiliary",
    "gyn",
    "urologic",
})


@dataclass(frozen=True)
class StagingModel:
    name: str
    edition: Edition
    category: str
    state_cls: type[NamedTuple]
    columns: dict[str, type[StrEnum]]
    examples: tuple[tuple[str, NamedTuple, str], ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        # Coerce string -> Edition for ergonomic call sites; raises ValueError
        # naming the offending literal if it's not a known edition.
        if not isinstance(self.edition, Edition):
            object.__setattr__(self, "edition", Edition(self.edition))

        if not isinstance(self.category, str) or not self.category:
            raise ValueError(
                f"StagingModel({self.name!r}): category must be a non-empty string"
            )

        fields_ = tuple(self.state_cls._fields)
        cols = tuple(self.columns.keys())
        if cols != fields_:
            raise ValueError(
                f"StagingModel({self.name!r}): columns {cols} "
                f"must equal state_cls._fields {fields_} in the same order"
            )

    @property
    def edition_slug(self) -> str:
        # "AJCC 8" -> "ajcc8"; matches the parent directory name under
        # models/, data/, criteria/.
        return _edition_slug(self.edition)

    @property
    def csv_path(self) -> str:
        # Path RELATIVE to the data/ root: "ajcc8/breast_rules_human.csv".
        return f"{self.edition_slug}/{self.name}_rules_human.csv"

    def __hash__(self) -> int:
        return hash((self.name, self.edition))
