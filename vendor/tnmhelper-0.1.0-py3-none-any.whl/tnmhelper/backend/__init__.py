"""Backend layer: rule walker, derivation engine, lint.

This package is pure logic. It reads data through a DataProvider (see
tnmhelper.data_provider); it does not open files directly.
"""
