"""Data source abstraction.

A DataProvider answers four questions about the data layer:
- `read_rules_csv(organ, edition)` -> CSV text for that triple
- `read_criteria(organ, edition)` -> criteria JSON text
- `read_derivation(organ, edition)` -> derivation JSON text
- `models_root()` -> directory string suitable for sys.path injection so
   tnmhelper.models.<edition>.<organ> resolves via Python's import machinery

Two implementations ship:
- FilesystemProvider (in filesystem.py) reads a tnmhelper_data/ directory
- ZipBundleProvider (in zipbundle.py) reads a .zip exported by tnmhelper.bundle

The global provider is set by `tnmhelper.set_data_source(...)`. Callers
inside the backend reach it via `get_provider()`; they should not import
either implementation directly.
"""
from __future__ import annotations

from typing import Protocol

from tnmhelper.backend._shared import Edition


class DataProvider(Protocol):
    def read_rules_csv(self, organ: str, edition: Edition) -> str: ...
    def read_criteria(self, organ: str, edition: Edition) -> str: ...
    def read_derivation(self, organ: str, edition: Edition) -> str: ...
    def derivation_source(self, organ: str, edition: Edition) -> str: ...
    def models_root(self) -> str: ...
    def iter_organ_editions(self) -> list[tuple[str, str]]: ...
    def describe(self) -> str: ...


_CURRENT: DataProvider | None = None


def set_provider(provider: DataProvider) -> None:
    global _CURRENT
    _CURRENT = provider


def get_provider() -> DataProvider:
    if _CURRENT is None:
        raise RuntimeError(
            "no data source configured; call tnmhelper.set_data_source(...) first"
        )
    return _CURRENT


__all__ = ["DataProvider", "get_provider", "set_provider"]
