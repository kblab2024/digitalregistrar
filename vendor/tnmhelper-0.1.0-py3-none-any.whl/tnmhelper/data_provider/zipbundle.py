"""Zip-bundle-backed DataProvider.

Reads a `.zip` archive exported by `python -m tnmhelper.bundle`. The
archive contains:

    manifest.json
    tnmhelper_data/models/<ed>/*.py            (Python source)
    tnmhelper_data/<ed>/<organ>/rules.csv
    tnmhelper_data/<ed>/<organ>/criteria.json
    tnmhelper_data/<ed>/<organ>/derivation.json

The `.py` model files are imported through Python's stdlib `zipimport`:
calling `tnmhelper.set_data_source(<zip_path>)` adds the archive to
`sys.path`, after which `tnmhelper.models.<ed>.<organ>` resolves
naturally via the import machinery. This provider only handles reading
the non-Python data files.
"""
from __future__ import annotations

import zipfile
from pathlib import Path

from tnmhelper.backend._shared import Edition, _edition_slug

BUNDLE_INNER_ROOT = "tnmhelper_data"


class ZipBundleProvider:
    def __init__(self, zip_path: str | Path) -> None:
        self.zip_path = Path(zip_path).resolve()
        if not self.zip_path.is_file():
            raise FileNotFoundError(str(self.zip_path))
        self._zf = zipfile.ZipFile(self.zip_path, "r")

    def _read(self, inner: str) -> str:
        try:
            data = self._zf.read(inner)
        except KeyError as e:
            raise FileNotFoundError(f"{self.zip_path}!/{inner}") from e
        return data.decode("utf-8")

    def _triple_path(self, organ: str, edition: Edition, name: str) -> str:
        return f"{BUNDLE_INNER_ROOT}/{_edition_slug(edition)}/{organ}/{name}"

    def read_rules_csv(self, organ: str, edition: Edition) -> str:
        return self._read(self._triple_path(organ, edition, "rules.csv"))

    def read_criteria(self, organ: str, edition: Edition) -> str:
        return self._read(self._triple_path(organ, edition, "criteria.json"))

    def read_derivation(self, organ: str, edition: Edition) -> str:
        return self._read(self._triple_path(organ, edition, "derivation.json"))

    def derivation_source(self, organ: str, edition: Edition) -> str:
        return f"{_edition_slug(edition)}/{organ}/derivation.json"

    def models_root(self) -> str:
        return f"{self.zip_path}{f'/{BUNDLE_INNER_ROOT}/models'}"

    def iter_organ_editions(self) -> list[tuple[str, str]]:
        seen: set[tuple[str, str]] = set()
        prefix = f"{BUNDLE_INNER_ROOT}/"
        for name in self._zf.namelist():
            if not name.startswith(prefix):
                continue
            tail = name[len(prefix):]
            parts = tail.split("/")
            if len(parts) < 3 or parts[0] == "models":
                continue
            seen.add((parts[1], parts[0]))
        return sorted(seen)

    def describe(self) -> str:
        return f"ZipBundleProvider({self.zip_path})"

    def __repr__(self) -> str:
        return self.describe()


def make_models_path_from_zip(zip_path: Path) -> str:
    """Build the path string Python's import system uses to resolve
    `tnmhelper.models.<edition>.<organ>` inside a zip via zipimport.

    The result is suitable to assign to `tnmhelper.models.__path__`
    (after the zip itself has been added to sys.path).
    """
    return f"{zip_path}{f'/{BUNDLE_INNER_ROOT}/models'}"
