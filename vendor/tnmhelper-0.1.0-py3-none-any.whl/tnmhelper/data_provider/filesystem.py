"""Filesystem-backed DataProvider.

Reads the in-repo `tnmhelper_data/` tree directly. This is what dev
workflows and the smoke test use.
"""
from __future__ import annotations

from pathlib import Path

from tnmhelper.backend._shared import Edition, _edition_slug


class FilesystemProvider:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise NotADirectoryError(
                f"tnmhelper_data root not found: {self.root}"
            )

    def _triple_dir(self, organ: str, edition: Edition) -> Path:
        return self.root / _edition_slug(edition) / organ

    def read_rules_csv(self, organ: str, edition: Edition) -> str:
        p = self._triple_dir(organ, edition) / "rules.csv"
        if not p.exists():
            raise FileNotFoundError(str(p))
        return p.read_text(encoding="utf-8")

    def read_criteria(self, organ: str, edition: Edition) -> str:
        p = self._triple_dir(organ, edition) / "criteria.json"
        if not p.exists():
            raise FileNotFoundError(str(p))
        return p.read_text(encoding="utf-8")

    def read_derivation(self, organ: str, edition: Edition) -> str:
        p = self._triple_dir(organ, edition) / "derivation.json"
        if not p.exists():
            raise FileNotFoundError(str(p))
        return p.read_text(encoding="utf-8")

    def derivation_source(self, organ: str, edition: Edition) -> str:
        return f"{_edition_slug(edition)}/{organ}/derivation.json"

    def models_root(self) -> str:
        return str(self.root / "models")

    def iter_organ_editions(self) -> list[tuple[str, str]]:
        out: list[tuple[str, str]] = []
        for ed_dir in self.root.iterdir():
            if not ed_dir.is_dir() or ed_dir.name == "models":
                continue
            for organ_dir in ed_dir.iterdir():
                if not organ_dir.is_dir():
                    continue
                out.append((organ_dir.name, ed_dir.name))
        return sorted(out)

    def describe(self) -> str:
        return f"FilesystemProvider({self.root})"

    def __repr__(self) -> str:
        return self.describe()
