"""Plain dataclasses for the public Python API surface.

These are deliberately string/list/dict-only (no enum class objects) so
downstream consumers (e.g. a dspy-based extractor) can import them
without dragging in the model registry's type graph.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ObservableSpec:
    name: str
    type: str
    unit: str | None
    description: str | None
    values: tuple[str, ...] | None
    default: Any
    has_default: bool
    label: str
    choices: dict[str, str] | None


@dataclass(frozen=True)
class AxisRule:
    label: str
    then: str


@dataclass(frozen=True)
class ModelSpec:
    organ: str
    edition: str
    category: str
    columns: dict[str, tuple[str, ...]]


@dataclass(frozen=True)
class DerivedStage:
    organ: str
    edition: str
    T: str
    N: str
    M: str
    stage: str
    source: str
    state: dict[str, str]


__all__ = ["ObservableSpec", "AxisRule", "ModelSpec", "DerivedStage"]
